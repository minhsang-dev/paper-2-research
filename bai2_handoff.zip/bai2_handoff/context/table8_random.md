# Table 8. DEV-013 — random split (future-informed) vs chronological replay, same evaluation rows (descriptive)

Paired (dataset, day, seed) triples used: 41; excluded: NF-CICIDS2018-v3|2018-02-28|s123; days: 14.

## (a) Mean AUPRC_w over days

| Protocol | TabFM | LightGBM |
|---|---|---|
| Random split | 0.831 | 0.799 |
| Chronological | 0.640 | 0.540 |

## (b) Day-level quantities

| Quantity | HL | Nominal one-sided 95 % LB | Nominal two-sided 95 % interval | Mean | Days > 0 |
|---|---|---|---|---|---|
| d = TabFM − LightGBM, random split | +0.0093 | +0.0047 | [+0.0030, +0.0177] | +0.0322 | 14 / 14 |
| d = TabFM − LightGBM, chronological | +0.0339 | +0.0030 | [+0.0011, +0.1656] | +0.1000 | 11 / 14 |
| Protocol effect on d (random − chronological) | -0.0051 | -0.1221 | [-0.1421, +0.0398] | -0.0678 | 7 / 14 |
| Protocol effect on AUPRC_w, TabFM | +0.1175 | +0.0180 | [+0.0116, +0.3720] | +0.1916 | 11 / 14 |
| Protocol effect on AUPRC_w, LightGBM | +0.2075 | +0.0969 | [+0.0761, +0.4164] | +0.2594 | 13 / 14 |

## (c) Per day (mean over the seeds valid under both protocols)

| Dataset | Day | Seeds | Random TabFM | Random LightGBM | Chrono TabFM | Chrono LightGBM | d random | d chrono |
|---|---|---|---|---|---|---|---|---|
| CIC | 2018-02-15 | 3 | 0.977 | 0.962 | 0.978 | 0.674 | +0.015 | +0.304 |
| CIC | 2018-02-16 | 3 | 1.000 | 1.000 | 0.999 | 0.988 | +0.000 | +0.011 |
| CIC | 2018-02-20 | 3 | 0.993 | 0.993 | 0.958 | 0.237 | +0.000 | +0.721 |
| CIC | 2018-02-21 | 3 | 1.000 | 1.000 | 1.000 | 0.770 | +0.000 | +0.230 |
| CIC | 2018-02-22 | 3 | 0.487 | 0.152 | 0.195 | 0.008 | +0.335 | +0.187 |
| CIC | 2018-02-28 | 2 | 0.132 | 0.119 | 0.077 | 0.042 | +0.013 | +0.035 |
| CIC | 2018-03-01 | 3 | 0.413 | 0.381 | 0.428 | 0.401 | +0.032 | +0.028 |
| CIC | 2018-03-02 | 3 | 1.000 | 0.994 | 0.123 | 0.193 | +0.006 | -0.070 |
| ToN | 2019-04-24 | 3 | 0.690 | 0.670 | 0.491 | 0.457 | +0.020 | +0.034 |
| ToN | 2019-04-25 | 3 | 0.997 | 0.996 | 0.516 | 0.602 | +0.001 | -0.086 |
| ToN | 2019-04-26 | 3 | 0.991 | 0.991 | 0.991 | 0.988 | +0.000 | +0.002 |
| ToN | 2019-04-27 | 3 | 0.965 | 0.961 | 0.953 | 0.953 | +0.004 | +0.000 |
| ToN | 2019-04-28 | 3 | 0.996 | 0.985 | 0.287 | 0.281 | +0.011 | +0.006 |
| ToN | 2019-04-29 | 3 | 0.997 | 0.982 | 0.960 | 0.961 | +0.014 | -0.000 |

The random split draws the k = 2,000 context rows uniformly from all flows of the dataset, including days after the evaluated day: a future-informed evaluation, not a deployable setting. Intervals are nominal (independent days assumed); no test, no p-value.
