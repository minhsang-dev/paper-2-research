# DEV-H2-001 (exploratory, descriptive; H2 stays INSUFFICIENT_DATA)

## 1. Untrainable contexts (one class) per day — seeds out of 3

| Day | Attack in evaluation sample | chrono | random_all | random_past |
|---|---|---|---|---|
| 2017-03-16 | yes | 0/3 | 0/3 | 0/3 |
| 2017-03-17 | yes | 0/3 | 0/3 | 0/3 |
| 2017-03-18 | no | 0/3 | 0/3 | 0/3 |
| 2017-03-19 | no | 0/3 | 0/3 | 0/3 |
| 2017-03-20 | yes | 3/3 | 0/3 | 0/3 |
| 2017-03-21 | yes | 0/3 | 0/3 | 0/3 |
| 2017-03-22 | no | 0/3 | 0/3 | 0/3 |
| 2017-03-23 | yes | 1/3 | 0/3 | 0/3 |
| 2017-03-24 | yes | 0/3 | 0/3 | 0/3 |
| 2017-03-25 | no | 0/3 | 0/3 | 0/3 |
| 2017-03-26 | no | 0/3 | 0/3 | 0/3 |
| 2017-03-27 | yes | 3/3 | 0/3 | 0/3 |
| 2017-03-28 | yes | 0/3 | 0/3 | 0/3 |
| 2017-04-05 | no | 0/3 | 0/3 | 0/3 |
| 2017-04-06 | no | 1/3 | 0/3 | 0/3 |
| 2017-04-07 | no | 3/3 | 0/3 | 0/3 |
| 2017-04-08 | no | 3/3 | 0/3 | 0/3 |
| 2017-04-09 | no | 3/3 | 0/3 | 0/3 |
| 2017-04-10 | no | 3/3 | 0/3 | 0/3 |
| 2017-04-11 | no | 3/3 | 0/3 | 0/3 |
| 2017-04-12 | no | 3/3 | 0/3 | 0/3 |
| 2017-04-13 | no | 3/3 | 0/3 | 0/3 |
| 2017-04-14 | no | 3/3 | 0/3 | 0/3 |
| 2017-04-15 | no | 3/3 | 0/3 | 0/3 |
| 2017-04-16 | no | 3/3 | 0/3 | 0/3 |
| 2017-04-17 | no | 3/3 | 0/3 | 0/3 |
| 2017-04-18 | no | 3/3 | 0/3 | 0/3 |

## 2. Attack days on which chrono was untrainable: what the other arms reported (LightGBM AUPRC_w)

| Day | Seed | chrono | random_all | random_past | Constant-score reference (hypothetical) |
|---|---|---|---|---|---|
| 2017-03-20 | s42 | untrainable (one-class context) | 0.999 | 0.999 | 0.216 |
| 2017-03-20 | s123 | untrainable (one-class context) | 0.998 | 0.997 | 0.216 |
| 2017-03-20 | s2026 | untrainable (one-class context) | 0.998 | 0.999 | 0.216 |
| 2017-03-23 | s42 | untrainable (one-class context) | 0.999 | 0.999 | 0.266 |
| 2017-03-23 | s123 | 0.970 | 0.999 | 0.999 | 0.266 |
| 2017-03-23 | s2026 | 0.970 | 0.999 | 0.999 | 0.266 |
| 2017-03-27 | s42 | untrainable (one-class context) | 0.858 | 0.742 | 0.006 |
| 2017-03-27 | s123 | untrainable (one-class context) | 0.759 | 0.723 | 0.006 |
| 2017-03-27 | s2026 | untrainable (one-class context) | 0.735 | 0.779 | 0.006 |

Untrainable: the locked LightGBM could not be trained because its context held one class; under the protocol no valid predictor exists for that day. The constant-score column is a hypothetical reference (AUPRC_w of a scorer that ranks all rows equally = weighted attack prevalence), not a LightGBM result. Post hoc and exploratory: an observation in this setting, not a general law.
