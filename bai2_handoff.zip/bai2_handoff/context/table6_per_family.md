# Table 6. Per-family AUPRC_w, policy FIFO (descriptive, DEV-010)

| Dataset | Family | Root days / days | Median (IQR) root-day TabFM − LightGBM | Mean AUPRC_w TabFM | Mean AUPRC_w LightGBM |
|---|---|---|---|---|---|
| CIC | DDOS_attack-LOIC-UDP | 1 / 11 | +0.4046 (+0.4046 to +0.4046) | 0.776 | 0.371 |
| CIC | DoS_attacks-Slowloris | 1 / 14 | +0.0487 (+0.0487 to +0.0487) | 0.983 | 0.934 |
| CIC | DoS_attacks-GoldenEye | 1 / 11 | +0.0224 (+0.0224 to +0.0224) | 0.992 | 0.970 |
| CIC | Infilteration | 2 / 16 | +0.0202 (+0.0184 to +0.0219) | 0.276 | 0.256 |
| CIC | FTP-BruteForce | 1 / 11 | +0.0076 (+0.0076 to +0.0076) | 0.985 | 0.977 |
| CIC | DoS_attacks-SlowHTTPTest | 1 / 11 | -0.0033 (-0.0033 to -0.0033) | 0.996 | 0.999 |
| CIC | Bot | 1 / 8 | +0.0028 (+0.0028 to +0.0028) | 1.000 | 0.997 |
| CIC | DDoS_attacks-LOIC-HTTP | 1 / 8 | +0.0017 (+0.0017 to +0.0017) | 1.000 | 0.998 |
| CIC | DoS_attacks-Hulk | 1 / 14 | +0.0003 (+0.0003 to +0.0003) | 1.000 | 1.000 |
| CIC | SSH-Bruteforce | 1 / 14 | +0.0001 (+0.0001 to +0.0001) | 1.000 | 1.000 |
| CIC | DDOS_attack-HOIC | 1 / 14 | +0.0000 (+0.0000 to +0.0000) | 1.000 | 1.000 |
| ToN | mitm | 1 / 14 | +0.0976 (+0.0976 to +0.0976) | 0.784 | 0.686 |
| ToN | ransomware | 1 / 11 | +0.0870 (+0.0870 to +0.0870) | 0.636 | 0.549 |
| ToN | dos | 2 / 25 | +0.0804 (+0.0543 to +0.1064) | 0.802 | 0.721 |
| ToN | Backdoor | 2 / 25 | +0.0242 (+0.0122 to +0.0361) | 0.993 | 0.968 |
| ToN | injection | 1 / 14 | +0.0145 (+0.0145 to +0.0145) | 0.968 | 0.954 |
| ToN | scanning | 2 / 19 | +0.0128 (+0.0120 to +0.0136) | 0.486 | 0.473 |
| ToN | xss | 1 / 14 | +0.0076 (+0.0076 to +0.0076) | 0.924 | 0.916 |
| ToN | ddos | 2 / 25 | +0.0033 (+0.0028 to +0.0038) | 0.990 | 0.987 |
| ToN | password | 2 / 25 | +0.0013 (-0.0005 to +0.0030) | 0.945 | 0.944 |

Benign rows plus rows of one family, label 1 = that family, locked weights; same rows for both models. A (day, family) pair with < 10 family rows or < 10 benign rows is not evaluable. No test, no p-value. Sorted by |median difference| within dataset.

Families never evaluable (all policies): CIC Brute_Force_-Web; CIC Brute_Force_-XSS; CIC SQL_Injection.
Not-evaluable (day, family) pairs per policy: CBRS 12, CURE 12, DualFIFO 12, FIFO 18.
