# Table 3. Outcome of every root day

| Dataset | Root day | Outcome x | d (feature) | d (prior) | d (recurring) | Beyond 5 MAD |
|---|---|---|---|---|---|---|
| NF-CICIDS2018-v3 | 2018-02-14 | +0.0024 | +0.0000 | +0.0000 | +0.0072 | no |
| NF-CICIDS2018-v3 | 2018-02-15 | +0.0263 | +0.0001 | +0.0645 | +0.0143 | no |
| NF-CICIDS2018-v3 | 2018-02-16 | -0.0004 | +0.0000 | -0.0000 | -0.0012 | no |
| NF-CICIDS2018-v3 | 2018-02-20 | +0.0017 | +0.0019 | +0.0015 | — | no |
| NF-CICIDS2018-v3 | 2018-02-21 | +0.0018 | +0.0025 | +0.0024 | +0.0005 | no |
| NF-CICIDS2018-v3 | 2018-02-22 | +0.2126 | +0.2874 | +0.1377 | — | **yes** |
| NF-CICIDS2018-v3 | 2018-02-28 | +0.0237 | +0.0303 | +0.0170 | — | no |
| NF-CICIDS2018-v3 | 2018-03-01 | +0.0166 | +0.0164 | +0.0169 | — | no |
| NF-CICIDS2018-v3 | 2018-03-02 | +0.0028 | +0.0011 | +0.0044 | — | no |
| NF-ToN-IoT-v3 | 2019-04-23 | +0.0112 | +0.0246 | -0.0022 | — | no |
| NF-ToN-IoT-v3 | 2019-04-24 | +0.0143 | +0.0089 | +0.0019 | +0.0320 | no |
| NF-ToN-IoT-v3 | 2019-04-25 | +0.0039 | +0.0013 | +0.0095 | +0.0009 | no |
| NF-ToN-IoT-v3 | 2019-04-26 | +0.0033 | +0.0009 | +0.0064 | +0.0026 | no |
| NF-ToN-IoT-v3 | 2019-04-27 | +0.0058 | +0.0020 | +0.0104 | +0.0050 | no |
| NF-ToN-IoT-v3 | 2019-04-28 | +0.0023 | +0.0003 | +0.0051 | +0.0015 | no |
| NF-ToN-IoT-v3 | 2019-04-29 | +0.0441 | +0.0019 | +0.0158 | +0.1146 | **yes** |

Root-day outcome = mean over its chains of the chain mean of d (policy FIFO). — = kind not evaluated for this root day. Beyond 5 MAD: |x − median| > 5 × 1.4826 × MAD (listed in out_h1.json secondary.root_days_beyond_5_mad; 2 root day(s)).
