"""Replay stream of one generator-v2 scenario (production adapter).

Builds the synthetic days of a scenario from its root day with drift_generator_v2.materialize and exposes them
through the stream interface of the replay, including the hooks `roles(t)` (disjoint eval / policy / cal parts of day
t) and `n_flows(t)` (nominal flow count = flows of the REAL root day, so alpha = A_FP / N-hat uses the root day's
volume). Rows are read lazily from the root day. `expected_pool_sha256` (from the manifest) is checked against the pools
rebuilt here, so a stream can only be built on the pools the manifest was locked with.
"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import drift_generator_v2 as gen  # noqa: E402


class ScenarioStream:
    def __init__(self, root, scn, expected_pool_sha256=None):
        i = scn["root_index"]
        self.root, self.i, self.scenario = root, i, scn
        self.dataset, self.n_features, self.attack_names = root.dataset, root.n_features, root.attack_names
        y, fam = root.labels(i), root.families(i)
        pools = gen.split_root_day(root.dataset, root.names[i], y, fam)
        if expected_pool_sha256 is not None:
            got = {k: gen._sha(v) for k, v in pools.items()}
            if got != expected_pool_sha256:
                raise ValueError("pools rebuilt from the data differ from the manifest")
        cols = {}

        def col(j):
            if j not in cols:
                cols[j] = root.column(i, j)
            return cols[j]

        days = gen.materialize(scn, y, fam, col, pools)
        self._pos = [np.concatenate([d["eval"], d["policy"], d["cal"]]) for d in days]
        self._roles = []
        for d in days:
            off = np.cumsum([0, len(d["eval"]), len(d["policy"]), len(d["cal"])])
            self._roles.append({k: np.arange(off[a], off[a + 1]) for a, k in enumerate(("eval", "policy", "cal"))})
        self._y = [y[p] for p in self._pos]
        self._fam = [fam[p] for p in self._pos]
        self.names = [f"{scn['id']}#{j}" for j in range(len(days))]
        self.rows = [np.arange(len(p)) for p in self._pos]
        self._n_flows = len(root.rows[i])

    def labels(self, t): return self._y[t]
    def families(self, t): return self._fam[t]
    def roles(self, t): return self._roles[t]
    def n_flows(self, t): return self._n_flows

    def get(self, t, pos):
        return self.root.get(self.i, self._pos[t][np.asarray(pos)])
