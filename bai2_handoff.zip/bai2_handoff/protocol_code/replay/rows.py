"""Row container shared by policies, models and the harness."""
from dataclasses import dataclass

import numpy as np


@dataclass
class Rows:
    X: np.ndarray    # (n, f) float32
    y: np.ndarray    # (n,) uint8, 0 benign / 1 attack
    fam: np.ndarray  # (n,) int16 attack-family id (0 = benign)
    rid: np.ndarray  # (n,) int64 row identity (global row index of the source flow); used by the isolation checks
    h: np.ndarray = None   # optional (n,) float64: normalised entropy of the prediction made on the day the row was
    #                        queried (set by the replay for policies that ask for it, NaN = no prediction)

    def __len__(self):
        return int(self.y.shape[0])

    @staticmethod
    def empty(n_features):
        return Rows(np.zeros((0, n_features), np.float32), np.zeros(0, np.uint8), np.zeros(0, np.int16),
                    np.zeros(0, np.int64))

    def take(self, idx):
        idx = np.asarray(idx)
        return Rows(self.X[idx], self.y[idx], self.fam[idx], self.rid[idx], None if self.h is None else self.h[idx])

    @staticmethod
    def concat(a, b):
        h = None
        if a.h is not None or b.h is not None:
            h = np.concatenate([np.full(len(a), np.nan) if a.h is None else a.h,
                                np.full(len(b), np.nan) if b.h is None else b.h])
        return Rows(np.concatenate([a.X, b.X]), np.concatenate([a.y, b.y]), np.concatenate([a.fam, b.fam]),
                    np.concatenate([a.rid, b.rid]), h)
