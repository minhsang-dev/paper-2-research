"""Valid-day count per development dataset (rule: UTC day with >= 100,000 flows). Output: out/day_counts.json."""
import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from data import DEV_DATASETS, DayStream  # noqa: E402


def main():
    out = {}
    for ds in DEV_DATASETS:
        s = DayStream(ds)
        days = []
        for i, name in enumerate(s.names):
            fam = s.families(i)
            y = s.labels(i)
            att = fam[y == 1]
            fids, cnt = np.unique(att, return_counts=True)
            days.append({"day": name, "flows": int(len(y)), "attack_flows": int(att.size),
                         "families": {s.attack_names[int(f)]: int(c) for f, c in zip(fids, cnt)}})
        out[ds] = {"n_valid_days": len(s), "days": days}
    (HERE / "out").mkdir(exist_ok=True)
    (HERE / "out" / "day_counts.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    print({k: v["n_valid_days"] for k, v in out.items()})


if __name__ == "__main__":
    main()
