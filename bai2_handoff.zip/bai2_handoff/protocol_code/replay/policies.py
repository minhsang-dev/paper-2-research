"""Context policies. Interface: update(context, new_labelled_rows, unlabelled_stream) -> context, |context| <= k.

Sources
- FIFO: written here.
- DualFIFO: Lee et al. 2026 (arXiv:2606.18677v1, Appendix B.1 and Sec. 4), re-implemented from the paper's text
  (no code release used). Short bank = sliding window of the newest B_S = round(rho*k) rows (rho = 0.75 as in the paper's
  protocol); short-bank overflow is inserted into the long bank (B_L = k - B_S); when the long bank exceeds B_L the
  oldest long-bank item of the most represented class (candidate counted, as in the paper's Algorithm 1) is removed.
  The paper gives no tie rule; ties go to the largest label (as in the reference code of cure_ref/). Classes are the
  stream's labels (binary). The tie rule (largest label value) is the one of the reference code shipped in
  cure_ref/ (dualfifo.py), which this class is cross-checked against in the unit tests.
- CBRS: re-implementation of Alg. 1 of Chrysakis & Moens 2020 (class-balanced reservoir sampling), class = binary
  label as in the original; slot-by-slot identical to the reference cbrs_ref/cbrs.py (checked with
  cbrs_crosscheck.py, see PROGRESS.md). CBRS-family: same algorithm with class = attack family (stronger comparator,
  reported separately).
CURE is Task 2 and is not provided here.
"""
import bisect
from collections import deque

import numpy as np

from rows import Rows


class Policy:
    name = "policy"

    def __init__(self, k, seed=0):
        self.k = int(k)
        self.rng = np.random.default_rng(seed)

    def update(self, context, new_labelled_rows, unlabelled_stream):
        raise NotImplementedError


class FIFO(Policy):
    name = "FIFO"

    def update(self, context, new_labelled_rows, unlabelled_stream):
        both = Rows.concat(context, new_labelled_rows)
        n = len(both)
        return both.take(np.arange(max(0, n - self.k), n))


class DualFIFO(Policy):
    """Short bank (FIFO window) + long bank (class-aware FIFO removal), as in Lee et al. 2026, App. B.1.
    The banks are policy state; `context` is only checked for consistency with them."""
    name = "DualFIFO"

    def __init__(self, k, seed=0, rho=0.75):
        super().__init__(k, seed)
        self.b_short = int(round(self.k * rho))
        self.b_long = self.k - self.b_short
        self.short = deque()                 # (x, y, fam, rid), oldest first
        self.long = {}                       # class -> deque of (seq, x, y, fam, rid), oldest first
        self._seq = 0

    def _long_size(self):
        return sum(len(d) for d in self.long.values())

    def _insert_long(self, item):
        y = int(item[1])
        self.long.setdefault(y, deque()).append((self._seq, *item))
        self._seq += 1
        if self._long_size() > self.b_long:
            counts = {c: len(d) for c, d in self.long.items() if d}
            top = max(counts.values())
            victim = max(c for c, n in counts.items() if n == top)   # tie: largest label (reference code)
            self.long[victim].popleft()

    def update(self, context, new_labelled_rows, unlabelled_stream):
        for j in range(len(new_labelled_rows)):
            self.short.append((new_labelled_rows.X[j], new_labelled_rows.y[j], new_labelled_rows.fam[j],
                               new_labelled_rows.rid[j]))
            if len(self.short) > self.b_short:
                old = self.short.popleft()
                if self.b_long > 0:
                    self._insert_long(old)
        longs = sorted((it for d in self.long.values() for it in d), key=lambda it: it[0])
        items = [it[1:] for it in longs] + list(self.short)
        if not items:
            return Rows.empty(context.X.shape[1])
        return Rows(np.asarray([i[0] for i in items], np.float32), np.asarray([i[1] for i in items], np.uint8),
                    np.asarray([i[2] for i in items], np.int16), np.asarray([i[3] for i in items], np.int64))


class CBRS(Policy):
    """Class-balancing reservoir sampling, Chrysakis & Moens 2020, Algorithm 1; behaviour and random-number order
    identical to the reference implementation in cbrs_ref/cbrs.py (cbrs_spec.md, 'after_fill' fullness):
      - memory not full: store the row in the next slot (nothing is evaluated, nothing is drawn);
      - memory full: at the start of every step, the classes that are currently the largest (all tied ones) become
        FULL for good ('is, or has been, the largest class'); then
          class not full -> overwrite, in place, an instance drawn uniformly (rng.integers over the slots, ascending)
                            from the largest class(es);
          class full     -> u = rng.random(); if u <= m_c / n_c overwrite an instance of the same class, drawn with
                            rng.integers over that class's slots (ascending); otherwise ignore the row.
    n_c counts every stream instance of the class seen so far (fill phase and current row included). Policy state:
    n_c and the set of full classes; the memory is the passed context (slot order = row order). Class = binary label
    (original CBRS) for `CBRS`, attack family for `CBRSFamily`."""
    name = "CBRS"
    class_by = "label"

    def __init__(self, k, seed=0):
        super().__init__(k, seed)
        self.seen = {}
        self.full = set()

    def _cls(self, rows):
        return rows.y if self.class_by == "label" else rows.fam

    def update(self, context, new_labelled_rows, unlabelled_stream):
        n0, nf = len(context), new_labelled_rows.X.shape[1]
        X = np.zeros((self.k, nf), np.float32)
        y = np.zeros(self.k, np.uint8)
        fam = np.zeros(self.k, np.int16)
        rid = np.zeros(self.k, np.int64)
        X[:n0], y[:n0], fam[:n0], rid[:n0] = context.X, context.y, context.fam, context.rid
        labels = [int(c) for c in self._cls(context).tolist()]
        slots = {}
        for i, c in enumerate(labels):
            slots.setdefault(c, []).append(i)
        new_cls = self._cls(new_labelled_rows)
        size = n0
        for j in range(len(new_labelled_rows)):
            c = int(new_cls[j])
            self.seen[c] = self.seen.get(c, 0) + 1
            if size < self.k:
                target = size
                slots.setdefault(c, []).append(size)
                labels.append(c)
                size += 1
            else:
                counts = {cl: len(v) for cl, v in slots.items() if v}
                top = max(counts.values())
                largest = [cl for cl, v in counts.items() if v == top]
                self.full.update(largest)
                if c not in self.full:
                    cand = slots[largest[0]] if len(largest) == 1 else sorted(s for cl in largest for s in slots[cl])
                    target = cand[int(self.rng.integers(0, len(cand)))]
                    old = labels[target]
                    del slots[old][bisect.bisect_left(slots[old], target)]
                    bisect.insort(slots.setdefault(c, []), target)
                    labels[target] = c
                else:
                    mine = slots.get(c, [])
                    u = self.rng.random()
                    if not (len(mine) > 0 and u <= len(mine) / self.seen[c]):
                        continue   # ignore the row
                    target = mine[int(self.rng.integers(0, len(mine)))]
            X[target], y[target] = new_labelled_rows.X[j], new_labelled_rows.y[j]
            fam[target], rid[target] = new_labelled_rows.fam[j], new_labelled_rows.rid[j]
        return Rows(X[:size].copy(), y[:size].copy(), fam[:size].copy(), rid[:size].copy())


class CBRSFamily(CBRS):
    name = "CBRS-family"
    class_by = "family"


POLICIES = {"FIFO": FIFO, "DualFIFO": DualFIFO, "CBRS": CBRS, "CBRS-family": CBRSFamily}
