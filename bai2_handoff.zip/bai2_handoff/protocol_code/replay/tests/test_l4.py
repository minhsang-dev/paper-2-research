"""L4 tests: reference DualFIFO cross-check, CURE adapter, CBRS 'full' state, scenario stream hooks. Synthetic data."""
import sys
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

import cure as ref_cure  # noqa: E402
import dualfifo as ref_dual  # noqa: E402
from models import LightGBMModel  # noqa: E402
from policies import CBRS, DualFIFO  # noqa: E402
from policies_cure import CURE  # noqa: E402
from replay import IsolationError, run_replay  # noqa: E402
from rows import Rows  # noqa: E402
from test_replay import PER_DAY, FakeStream, labelled  # noqa: E402

F = 4


def frame(rows):
    df = pd.DataFrame(rows.X.astype(np.float32), columns=[f"f{j}" for j in range(rows.X.shape[1])])
    df["y"] = rows.y.astype(np.int64)
    df["row_id"] = rows.rid.astype(np.int64)
    return df


def random_batches(seed, n=400, p_attack=0.15):
    rng = np.random.default_rng(seed)
    ids = np.arange(n)
    y = (rng.random(n) < p_attack).astype(np.uint8)
    X = rng.normal(size=(n, F)).astype(np.float32)
    X[:, 0] = ids
    X[:, 1] += 2.0 * y
    r = Rows(X, y, y.astype(np.int16), ids.astype(np.int64))
    cuts = np.sort(rng.choice(np.arange(1, n), 12, replace=False))
    return [r.take(np.arange(a, b)) for a, b in zip(np.r_[0, cuts], np.r_[cuts, n])]


class TestDualFIFOAgainstReference(unittest.TestCase):
    def test_same_context_as_reference_code(self):
        for k in (4, 10, 40, 100):
            for seed in (0, 1, 2):
                mine, ref = DualFIFO(k=k), ref_dual.DualFIFOPolicy(k=k)
                ctx, ref_ctx = Rows.empty(F), None
                for b in random_batches(seed):
                    ctx = mine.update(ctx, b, None)
                    ref_ctx = ref.update(ref_ctx, frame(b), None)
                    self.assertEqual(sorted(ctx.rid.tolist()), sorted(ref_ctx["row_id"].tolist()), (k, seed))
                    self.assertEqual(len(ctx), len(ref_ctx))


class TestCBRSFullState(unittest.TestCase):
    def test_no_eviction_before_memory_is_full_and_state_marks_full_after(self):
        p = CBRS(k=50, seed=3)
        rows = labelled(range(120), [1 if i % 5 == 0 else 0 for i in range(120)])
        ctx = p.update(Rows.empty(F), rows.take(np.arange(49)), None)
        self.assertEqual(ctx.rid.tolist(), list(range(49)))            # k-1 rows: everything kept, in order
        ctx = p.update(ctx, rows.take(np.arange(49, 50)), None)
        self.assertEqual(ctx.rid.tolist(), list(range(50)))            # exactly k rows: still no replacement
        self.assertEqual(sum(p.seen.values()), 50)
        ctx2 = p.update(ctx, rows.take(np.arange(50, 120)), None)      # from now on the 'full' rules apply
        self.assertEqual(len(ctx2), 50)
        self.assertNotEqual(ctx2.rid.tolist(), list(range(50)))        # replacements happened only after fullness
        self.assertTrue(set(ctx2.rid.tolist()) <= set(range(120)))


class CountingModel(LightGBMModel):
    """predict_proba depends on the size of the context only, and every call is recorded."""
    def __init__(self):
        super().__init__(params=dict(n_estimators=3, verbosity=-1))
        self.calls = []

    def predict_proba(self, context, X):
        self.calls.append(len(context))
        q = 1.0 / (len(context) + 2)
        return np.column_stack([np.full(len(X), 1 - q), np.full(len(X), q)])


class TestRowsEntropyField(unittest.TestCase):
    def test_take_and_concat_carry_h(self):
        a = labelled(range(4), [0, 1, 0, 1])
        b = labelled(range(4, 6), [1, 0])
        self.assertIsNone(Rows.concat(a, b).h)
        a.h = np.array([0.1, 0.2, 0.3, 0.4])
        c = Rows.concat(a, b)
        self.assertTrue(np.array_equal(c.h[:4], a.h) and np.isnan(c.h[4:]).all())
        self.assertTrue(np.array_equal(c.take([1, 3]).h, np.array([0.2, 0.4])))
        self.assertIsNone(b.take([0]).h)


class TestCUREAdapter(unittest.TestCase):
    def test_tau_is_required(self):
        with self.assertRaises(ValueError):
            CURE(k=100)

    def test_matches_reference_policy_driven_with_stored_entropy(self):
        """The adapter equals CUREPolicy fed the same batches with the stored entropy `_h` (scorer never used)."""
        for k, tau in ((20, 0.3), (60, 0.0), (100, 0.6)):
            mine = CURE(k=k, tau=tau, warmup_steps=30)
            direct = ref_cure.CUREPolicy(k=k, tau=tau, warmup_steps=30)
            rng = np.random.default_rng(k)
            ctx, state = Rows.empty(F), None
            delivered, fam_of = set(), {}
            for b in random_batches(7, n=500, p_attack=0.3):
                b.h = np.where(rng.random(len(b)) < 0.2, np.nan, rng.random(len(b)))   # NaN = no prediction
                ctx = mine.update(ctx, b, None)
                fr = frame(b)
                fr["_h"] = b.h
                state = direct.update(state, fr, None, None)
                delivered |= set(b.rid.tolist())
                fam_of.update(zip(b.rid.tolist(), b.fam.tolist()))
                self.assertEqual(ctx.rid.tolist(), state["row_id"].tolist())
                self.assertLessEqual(len(ctx), k)
                self.assertTrue(set(ctx.rid.tolist()) <= delivered)
                self.assertTrue(all(fam_of[int(r)] == f for r, f in zip(ctx.rid, ctx.fam)))
                self.assertTrue(np.array_equal(ctx.X, state[[f"f{j}" for j in range(F)]].to_numpy(np.float32)))
                self.assertTrue(np.array_equal(mine.state["_h"].to_numpy(), state["_h"].to_numpy()))

    def test_admission_uses_the_stored_entropy_not_a_new_one(self):
        # k=6 -> B_S=4, B_L=2; tau=0.5; warm-fill (long bank < 2) admits anything, afterwards h >= tau is required
        p = CURE(k=6, tau=0.5, warmup_steps=0)
        rows = labelled(range(12), [0, 1] * 6)
        rows.h = np.array([0.0] * 6 + [0.9, 0.1, 0.9, 0.1, 0.9, 0.1])
        ctx = p.update(Rows.empty(F), rows, None)
        self.assertEqual(len(ctx), 6)
        long_rows = p.state.loc[p.state["_bank"] == "L", "row_id"].tolist()
        self.assertEqual(len(long_rows), 2)
        # rows 6..11 leave the short bank after rows 0..5; low-entropy candidates (h = 0.1 < tau) never reach the long bank
        self.assertTrue(all(p.state.loc[p.state["row_id"] == r, "_h"].iloc[0] >= 0.5 or r < 2 for r in long_rows))

    def test_no_stored_entropy_means_zero(self):
        p = CURE(k=30, tau=0.3, warmup_steps=0)
        ctx = p.update(Rows.empty(F), labelled(range(10), [0, 1] * 5), None)    # h is None: no prediction
        self.assertTrue((p.state["_h"] == 0.0).all())
        self.assertEqual(len(ctx), 10)
        with self.assertRaises(ValueError):
            p.update(Rows.empty(F), labelled([100], [1]), None)               # harness context differs from CURE's state

    def test_entropy_is_scored_on_the_query_day_with_the_current_context(self):
        """Score first, learn after: h is computed on the day a row is queried (context of that moment) and is the value
        used when the label arrives; nothing is recomputed at arrival."""
        tau_delay, n_days = 2, 6
        pol, model = CURE(k=1000, tau=0.0, warmup_steps=0), CountingModel()
        run_replay(FakeStream(n_days=n_days), pol, model, b=300, eta=0.2, tau=tau_delay, a_fp=50, n_days=n_days,
                   n_eval=300)
        per_day = 240                                          # (1 - eta) * b policy rows per day
        # contexts at query time hold (d - tau) days of rows; days 0..2 have no usable context -> no model call
        self.assertEqual(model.calls, [per_day * (d - tau_delay) for d in range(tau_delay + 1, n_days)])
        # rows that arrived by the end of the last day were queried on days 0..3
        st = pol.state
        self.assertEqual(len(st), per_day * (n_days - tau_delay))
        for rid_day in range(n_days - tau_delay):
            h = st.loc[(st["row_id"] // PER_DAY) == rid_day, "_h"].to_numpy()
            n_ctx = per_day * max(0, rid_day - tau_delay)
            expected = 0.0 if n_ctx < 2 else float(ref_cure.normalized_entropy(
                np.array([[1 - 1 / (n_ctx + 2), 1 / (n_ctx + 2)]]))[0])
            self.assertTrue(np.allclose(h, expected), (rid_day, h[:3], expected))

    def test_replay_with_cure_keeps_isolation_and_rejects_nothing_extra(self):
        recs = run_replay(FakeStream(n_days=4), CURE(k=500, tau=0.3), LightGBMModel(params=dict(n_estimators=5,
                          verbosity=-1)), b=400, eta=0.2, tau=0, a_fp=50, n_days=4, n_eval=500)
        self.assertEqual(len(recs), 3)
        self.assertTrue(all(r["policy"] == "CURE" and r["n_ctx"] <= 500 for r in recs))
        self.assertEqual(recs[-1]["n_ctx"], 500)                       # 3 days x 320 policy rows, k = 500

    def test_cure_cannot_smuggle_reserved_rows(self):
        class Bad(CURE):
            def update(self, context, new, unl):
                out = super().update(context, new, unl)
                return Rows.concat(out.take(np.arange(max(0, len(out) - 1))), unl_rows(out))   # fabricated row

        def unl_rows(out):
            r = labelled([999_999], [0])
            return r
        with self.assertRaises(IsolationError):
            run_replay(FakeStream(n_days=3), Bad(k=500, tau=0.3), LightGBMModel(params=dict(n_estimators=3,
                       verbosity=-1)), b=300, eta=0.2, tau=0, a_fp=50, n_days=3, n_eval=300)


if __name__ == "__main__":
    unittest.main()
