"""Unit tests on synthetic data only (no development-data results are read). Run: python -m unittest discover -s tests"""
import sys
import unittest
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from data import eval_positions, rare_families  # noqa: E402
from models import LightGBMModel  # noqa: E402
from policies import CBRS, FIFO, CBRSFamily, DualFIFO  # noqa: E402
from replay import IsolationError, day_metrics, run_replay, threshold_at_alpha  # noqa: E402
from rows import Rows  # noqa: E402

F = 4
PER_DAY = 4000


def mk(n, fam_probs, start_id=0, seed=0):
    rng = np.random.default_rng(seed)
    fam = rng.choice(len(fam_probs), size=n, p=fam_probs).astype(np.int16)
    X = np.zeros((n, F), np.float32)
    X[:, 0] = np.arange(start_id, start_id + n)          # row id, to track provenance
    X[:, 1] = fam + rng.normal(0, 0.1, n)                # separable signal
    return Rows(X, (fam > 0).astype(np.uint8), fam, X[:, 0].astype(np.int64))


def labelled(ids, ys):
    ids = np.asarray(ids)
    X = np.zeros((len(ids), F), np.float32)
    X[:, 0] = ids
    return Rows(X, np.asarray(ys, np.uint8), np.asarray(ys, np.int16), ids.astype(np.int64))


class FakeStream:
    """Duck-typed DayStream: n_days days of PER_DAY rows; X[:,0] is a unique global id (day = id // PER_DAY)."""
    dataset = "NF-ToN-IoT-v3"
    n_features = F

    def __init__(self, n_days=5):
        self.days = [mk(PER_DAY, [0.7, 0.2, 0.0995, 0.0005], start_id=d * PER_DAY, seed=d) for d in range(n_days)]
        self.names = [f"d{d}" for d in range(n_days)]
        self.rows = [np.arange(PER_DAY) for _ in range(n_days)]

    def labels(self, i): return self.days[i].y
    def families(self, i): return self.days[i].fam
    def get(self, i, pos): return self.days[i].take(pos)


class SpyModel(LightGBMModel):
    def __init__(self):
        super().__init__(params=dict(n_estimators=5, verbosity=-1))
        self.calls = []

    def score(self, context, X):
        self.calls.append((context.X[:, 0].astype(int).copy(), X[:, 0].astype(int).copy()))
        return super().score(context, X)


class TestPolicies(unittest.TestCase):
    def test_fifo_keeps_newest_k_in_order(self):
        p = FIFO(k=10)
        ctx = p.update(Rows.empty(F), mk(7, [1, 0], 0), None)
        ctx = p.update(ctx, mk(8, [1, 0], 100), None)
        self.assertEqual(ctx.X[:, 0].tolist(), [5, 6, 100, 101, 102, 103, 104, 105, 106, 107])

    def test_dualfifo_follows_cure_paper_definition(self):
        # k=10, rho=0.75 -> short bank 8, long bank 2. Hand-worked from App. B.1: short overflow enters the long
        # bank; on long-bank overflow the oldest item of the most represented class (candidate counted) is removed.
        p = DualFIFO(k=10)
        self.assertEqual((p.b_short, p.b_long), (8, 2))
        ys = [0, 0, 1, 0, 1, 0, 0] + [0] * 8
        ctx = p.update(Rows.empty(F), labelled(range(15), ys), None)
        self.assertEqual(ctx.X[:, 0].astype(int).tolist(), [4, 6] + list(range(7, 15)))
        # batch splitting must not change the result (state is carried by the policy)
        q = DualFIFO(k=10)
        c = Rows.empty(F)
        for a, z in ((0, 5), (5, 9), (9, 15)):
            c = q.update(c, labelled(range(a, z), ys[a:z]), None)
        self.assertEqual(c.X[:, 0].astype(int).tolist(), ctx.X[:, 0].astype(int).tolist())

    def test_dualfifo_not_5050_and_long_bank_keeps_minority(self):
        p = DualFIFO(k=100)
        ys = ([0] * 95 + [1] * 5) * 20   # 5% attacks
        ctx = p.update(Rows.empty(F), labelled(range(len(ys)), ys), None)
        self.assertEqual(len(ctx), 100)
        self.assertGreater(int(ctx.y.sum()), 5)   # long bank keeps more attacks than the stream rate
        self.assertLess(int(ctx.y.sum()), 50)     # but is not forced to 50/50
        self.assertEqual(ctx.X[-75:, 0].astype(int).tolist(), list(range(len(ys) - 75, len(ys))))   # short bank = newest 75

    def test_cbrs_variants(self):
        stream = mk(3000, [0.85, 0.1, 0.045, 0.005], 0, seed=2)

        def run(cls, seed):
            p = cls(k=200, seed=seed)
            ctx = Rows.empty(F)
            for a in range(0, 3000, 500):
                ctx = p.update(ctx, stream.take(np.arange(a, a + 500)), None)
                self.assertLessEqual(len(ctx), 200)
            return ctx

        c1, c2, c3 = run(CBRS, 5), run(CBRS, 5), run(CBRS, 6)
        self.assertEqual(len(c1), 200)
        self.assertTrue(np.array_equal(c1.X, c2.X))
        self.assertFalse(np.array_equal(c1.X, c3.X))
        self.assertAlmostEqual(int(c1.y.sum()), 100, delta=2)       # binary classes balanced (stream is 15% attack)
        ids = c1.X[:, 0]
        self.assertEqual(len(np.unique(ids)), len(ids))
        f = run(CBRSFamily, 5)
        counts = np.bincount(f.fam, minlength=4)
        self.assertGreater(counts[3], 0)                            # rarest family kept
        self.assertLessEqual(counts.max() - np.sort(counts)[-2], 5)  # family classes balanced at the top
        self.assertEqual((CBRS.name, CBRSFamily.name), ("CBRS", "CBRS-family"))

    def test_policies_differ_once_buffer_overflows(self):
        batch = mk(600, [0.9, 0.1], 0, seed=4)
        outs = {}
        for cls in (FIFO, DualFIFO, CBRS):
            p = cls(k=100)
            outs[cls.__name__] = tuple(p.update(Rows.empty(F), batch, None).X[:, 0].astype(int).tolist())
        self.assertEqual(len({outs["FIFO"], outs["DualFIFO"], outs["CBRS"]}), 3)


class TestHarness(unittest.TestCase):
    def test_threshold_respects_alpha(self):
        s = np.random.default_rng(0).random(10_000)
        thr = threshold_at_alpha(s, 0.01)
        self.assertLessEqual((s >= thr).mean(), 0.01)
        self.assertGreater((s >= thr).mean(), 0.0085)
        self.assertEqual(threshold_at_alpha(np.zeros(0), 0.01), np.inf)

    def test_primary_metric_is_inverse_probability_weighted(self):
        y = np.array([1, 1, 0, 0]); sc = np.array([0.9, 0.1, 0.8, 0.2]); fam = y.astype(np.int16)
        a = day_metrics(y, fam, np.ones(4), sc, 0.5, np.zeros(0, np.int16))
        b = day_metrics(y, fam, np.array([1.0, 1.0, 100.0, 1.0]), sc, 0.5, np.zeros(0, np.int16))
        self.assertEqual(a["auprc"], b["auprc"])
        self.assertNotEqual(a["auprc_w"], b["auprc_w"])
        self.assertEqual(a["recall_by_family"], {1: 0.5})

    def test_eval_sample_fixed_disjoint_keeps_rare(self):
        d = mk(20_000, [0.7, 0.2, 0.0995, 0.0005], seed=3)
        a, wa = eval_positions(d.fam, d.y, 2000, seed=11)
        b, _ = eval_positions(d.fam, d.y, 2000, seed=11)
        self.assertTrue(np.array_equal(a, b))
        rare = rare_families(d.fam, d.y)
        self.assertIn(3, rare.tolist())
        self.assertEqual(int(np.isin(a, np.flatnonzero((d.y == 1) & np.isin(d.fam, rare))).sum()),
                         int(((d.y == 1) & np.isin(d.fam, rare)).sum()))
        c, _ = eval_positions(d.fam, d.y, 2000, seed=12, exclude=a)
        self.assertEqual(len(np.intersect1d(a, c)), 0)
        self.assertAlmostEqual(wa.sum(), 20_000, delta=40)

    def _delay_check(self, tau, n_days):
        s = FakeStream(n_days=n_days)
        calls = []

        class Spy(FIFO):
            def update(self, context, new, unl):
                calls.append(sorted(set((new.X[:, 0] // PER_DAY).astype(int).tolist())))
                return super().update(context, new, unl)

        spy = SpyModel()
        recs = run_replay(s, Spy(k=100_000), spy, b=300, eta=0.2, tau=tau, a_fp=100, n_days=n_days, n_eval=500)
        for t, got in enumerate(calls):          # end of day t delivers exactly the labels queried on day t - tau
            self.assertEqual(got, [t - tau] if t - tau >= 0 else [])
        self.assertEqual(len(recs), n_days - 1)
        for r, (ctx_ids, x_ids) in zip(recs, spy.calls):
            t = int(r["day"][1:])
            usable = max(0, t - tau)             # days whose labels may be used on day t: queried on days <= t-tau-1
            self.assertEqual(r["n_ctx"], 240 * usable)          # (1-eta)*b = 240 per day
            self.assertEqual(r["n_cal"], 60 * min(usable, 3))   # eta*b = 60 per day, pooled over W_V = 3 days
            if usable:
                self.assertTrue(set(ctx_ids // PER_DAY) <= set(range(usable)))
                self.assertLessEqual(int((ctx_ids // PER_DAY).max()), t - tau - 1)
            ev_ids, cal_ids = x_ids[:r["n_eval"]], x_ids[r["n_eval"]:]
            self.assertEqual(len(cal_ids), r["n_cal"])
            if len(cal_ids):
                self.assertLessEqual(int((cal_ids // PER_DAY).max()), t - tau - 1)
                self.assertGreaterEqual(int((cal_ids // PER_DAY).min()), max(0, t - tau - 3))   # window of 3 days
            self.assertEqual(len(np.intersect1d(ctx_ids, cal_ids)), 0)   # reserved rows never reach the policy
            self.assertEqual(len(np.intersect1d(ev_ids, ctx_ids)), 0)    # I1: evaluation rows not in context ...
            self.assertEqual(len(np.intersect1d(ev_ids, cal_ids)), 0)    # ... nor in D_cal
        return recs

    def test_label_delay_tau0(self):
        self._delay_check(0, 5)

    def test_label_delay_tau1_usable_from_d_plus_2(self):
        recs = self._delay_check(1, 6)
        self.assertEqual([r["n_ctx"] for r in recs], [0, 240, 480, 720, 960])   # day 1 empty; first labels at day 2

    def test_label_delay_tau7_usable_from_d_plus_8(self):
        recs = self._delay_check(7, 11)
        self.assertEqual([r["n_ctx"] for r in recs], [0] * 7 + [240, 480, 720])   # day 8 is first with labels
        self.assertFalse(recs[6]["context_ok"])
        self.assertTrue(recs[7]["context_ok"])

    def test_alpha_rule_and_floor_flag(self):
        s = FakeStream(n_days=4)
        r = run_replay(s, FIFO(k=5000), LightGBMModel(params=dict(n_estimators=5, verbosity=-1)), b=400, eta=0.5,
                       tau=0, a_fp=2, n_days=4, n_eval=500)
        last = r[-1]
        self.assertEqual(last["n_cal"], 600)   # tau=0, 3 usable days x 200 reserved rows = 600 (W_V = 3 window)
        share = last["n_cal_benign"] / last["n_cal"]
        self.assertAlmostEqual(last["alpha_t"], 2 / (PER_DAY * share), places=9)
        self.assertEqual(last["alpha_eff"], max(last["alpha_t"], 5 / last["n_cal_benign"]))
        self.assertTrue(last["alpha_floor_active"])          # tiny alpha_t, so the 5/n_benign floor binds
        r2 = run_replay(FakeStream(n_days=4), FIFO(k=5000), LightGBMModel(params=dict(n_estimators=5, verbosity=-1)),
                        b=400, eta=0.5, tau=0, a_fp=2000, n_days=4, n_eval=500)
        self.assertFalse(r2[-1]["alpha_floor_active"])       # alpha_t ~ 0.7 > floor
        self.assertEqual(r2[-1]["alpha_eff"], r2[-1]["alpha_t"])

    def test_same_labelled_rows_for_every_policy_and_seeded_determinism(self):
        out = {}
        for cls in (FIFO, DualFIFO, CBRS, CBRSFamily):
            r = run_replay(FakeStream(n_days=3), cls(k=1000), LightGBMModel(params=dict(n_estimators=10, verbosity=-1)),
                           b=200, tau=0, a_fp=50, n_days=3, n_eval=600, seed=7)
            out[cls.__name__] = r
            self.assertTrue(all(0.0 <= x["auprc_w"] <= 1.0 for x in r))
        for n, v in out.items():
            self.assertEqual([(x["day"], x["n_eval"], x["n_cal"]) for x in v],
                             [(x["day"], x["n_eval"], x["n_cal"]) for x in out["FIFO"]])
        r2 = run_replay(FakeStream(n_days=3), FIFO(k=1000), LightGBMModel(params=dict(n_estimators=10, verbosity=-1)),
                        b=200, tau=0, a_fp=50, n_days=3, n_eval=600, seed=7)
        self.assertEqual([x["auprc_w"] for x in r2], [x["auprc_w"] for x in out["FIFO"]])

    def test_eval_rows_stay_in_query_pool_and_are_isolated_when_scored(self):
        """Score-then-learn: day t's evaluation rows may be queried (they are labelled for day t+1 on) but are never
        in the context or D_cal when day t is scored."""
        s = FakeStream(n_days=4)
        spy = SpyModel()
        recs = run_replay(s, FIFO(k=100_000), spy, b=3000, eta=0.2, tau=0, a_fp=50, n_days=4, n_eval=500)
        ev_of_day = {}
        for r, (ctx_ids, x_ids) in zip(recs, spy.calls):
            t = int(r["day"][1:])
            ev_ids = x_ids[:r["n_eval"]]
            ev_of_day[t] = ev_ids
            self.assertEqual(len(np.intersect1d(ev_ids, ctx_ids)), 0)
            self.assertEqual(len(np.intersect1d(ev_ids, x_ids[r["n_eval"]:])), 0)
        # day 1's evaluation rows were queried at the end of day 1 and sit in the day-2 context (or D_cal)
        _, x2 = spy.calls[1][0], spy.calls[1][1]
        seen_on_day2 = np.concatenate([spy.calls[1][0], x2[recs[1]["n_eval"]:]])
        self.assertGreater(len(np.intersect1d(ev_of_day[1], seen_on_day2)), 0)

    def test_policy_cannot_return_unlabelled_or_fabricated_rows(self):
        s = FakeStream(n_days=3)

        class FromUnlabelled(FIFO):
            """Reads the unlabelled stream and tries to put those rows in the context."""
            def update(self, context, new, unl):
                n = len(unl)
                return Rows(unl.copy(), np.zeros(n, np.uint8), np.zeros(n, np.int16), np.zeros(n, np.int64))

        class Fabricate(FIFO):
            """Returns every row of day 0 (including the rows reserved for D_cal)."""
            def update(self, context, new, unl):
                return s.get(0, np.arange(PER_DAY))

        class Tamper(FIFO):
            """Returns a delivered row with altered content."""
            def update(self, context, new, unl):
                out = super().update(context, new, unl)
                if len(out):
                    out.X[0, 1] += 1.0
                return out

        for cls in (FromUnlabelled, Fabricate, Tamper):
            with self.assertRaises(IsolationError, msg=cls.__name__):
                run_replay(FakeStream(n_days=3), cls(k=100_000), LightGBMModel(params=dict(n_estimators=3, verbosity=-1)),
                           b=300, eta=0.2, tau=0, a_fp=50, n_days=3, n_eval=300)
        # an honest policy that is also handed the reserved rows' day is fine (control)
        run_replay(s, FIFO(k=100_000), LightGBMModel(params=dict(n_estimators=3, verbosity=-1)), b=300, eta=0.2, tau=0,
                   a_fp=50, n_days=3, n_eval=300)

    def test_resampled_days_assert_mode_raises_filter_mode_isolates(self):
        class Shared(FakeStream):
            """Days resampled with replacement from one pool of 1500 root rows (as the drift generator does)."""
            def __init__(self, n_days):
                pool = mk(1500, [0.7, 0.2, 0.0995, 0.0005], seed=9)
                rng = np.random.default_rng(1)
                self.days = [pool.take(np.sort(rng.integers(0, 1500, 3000))) for _ in range(n_days)]
                self.names = [f"d{d}" for d in range(n_days)]
                self.rows = [np.arange(3000) for _ in range(n_days)]

        with self.assertRaises(IsolationError):
            run_replay(Shared(4), FIFO(k=100_000), SpyModel(), b=600, eta=0.2, tau=0, a_fp=50, n_days=4, n_eval=300,
                       isolation="assert")
        delivered_all = []

        class Rec(FIFO):
            def update(self, context, new, unl):
                delivered_all.append(new.rid.copy())
                return super().update(context, new, unl)

        spy = SpyModel()
        with self.assertRaises(IsolationError):   # filter mode stops on any dropped row by default (v2 rule)
            run_replay(Shared(4), Rec(k=100_000), SpyModel(), b=600, eta=0.2, tau=0, a_fp=50, n_days=4, n_eval=300,
                       isolation="filter")
        delivered_all.clear()
        recs = run_replay(Shared(4), Rec(k=100_000), spy, b=600, eta=0.2, tau=0, a_fp=50, n_days=4, n_eval=300,
                          isolation="filter", max_filter_drops=None)
        self.assertGreater(sum(r["iso_dropped_ctx"] + r["iso_dropped_cal"] for r in recs), 0)   # collisions were real
        cal_seen = set()
        for r, (ctx_ids, x_ids) in zip(recs, spy.calls):
            ev_ids, cal_ids = x_ids[:r["n_eval"]], x_ids[r["n_eval"]:]
            self.assertEqual(len(np.intersect1d(ev_ids, ctx_ids)), 0)    # I1
            self.assertEqual(len(np.intersect1d(ev_ids, cal_ids)), 0)
            cal_seen |= set(cal_ids.tolist())
        # I3: no row both reserved (seen in D_cal) and given to the policy
        self.assertEqual(len(cal_seen & set(np.concatenate(delivered_all).tolist())), 0)
        self.assertEqual(recs[-1]["isolation"], "filter")

    def test_dev_data_guard(self):
        from data import DayStream
        for bad in ("UGR16", "CIDDS-001", "DS1"):
            with self.assertRaises(ValueError):
                DayStream(bad)


if __name__ == "__main__":
    unittest.main()
