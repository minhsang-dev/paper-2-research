"""Smoke run L2 (replaces run_smoke.py): 2 evaluated days of NF-ToN-IoT-v3, LightGBM, k=2000 so that policies
overflow. FIFO / DualFIFO / CBRS / CBRS-family. Provisional LightGBM params; results are NOT for H1.
Output: out/smoke_k2000.json."""
import json
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from data import DayStream  # noqa: E402
from models import LightGBMModel  # noqa: E402
from policies import POLICIES  # noqa: E402
from replay import run_replay  # noqa: E402

DATASET, B, ETA, TAU, K, A_FP, SEED = "NF-ToN-IoT-v3", 2000, 0.2, 0, 2000, 1000, 42
FIRST_DAY, N_DAYS = 0, 3   # day 0 warm-up + 2 evaluated days


def main():
    t0 = time.perf_counter()
    stream = DayStream(DATASET)
    out = {"config": dict(dataset=DATASET, b=B, eta=ETA, tau=TAU, k=K, a_fp=A_FP, seed=SEED, first_day=FIRST_DAY,
                          n_days=N_DAYS, n_eval=10_000, cal_cap=5000), "records": []}
    for name, cls in POLICIES.items():
        out["records"] += run_replay(stream, cls(k=K, seed=SEED), LightGBMModel(seed=SEED), b=B, eta=ETA, tau=TAU,
                                     a_fp=A_FP, first_day=FIRST_DAY, n_days=N_DAYS, seed=SEED)
        print(name, "done", round(time.perf_counter() - t0, 1), "s", flush=True)
    (HERE / "out").mkdir(exist_ok=True)
    (HERE / "out" / "smoke_k2000.json").write_text(json.dumps(out, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
