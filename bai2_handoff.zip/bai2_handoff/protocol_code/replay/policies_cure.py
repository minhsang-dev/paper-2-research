"""CURE for the replay harness: adapter around the reference implementation in cure.py (copied unchanged from
cure_ref/, SHA-256 bb279157fe790626a941d239cd3beb1f1bf1ec2bae00a83c1a726f31a9b209c6; follows the official code at
commit f7c6b2f of github.com/morcellinus/CURE-ICML-FMSD).

The reference works on pandas frames and keeps its bookkeeping (_bank, _h, _arrival) in the context it returns. The
adapter keeps that frame as policy state and returns the harness `Rows` (features, label, family, rid) of the retained
rows, so the harness checks I2 on what CURE returns. The `context` argument of the harness is only checked against the
policy state.

Entropy follows the official protocol, score first and learn after: on the day a row is queried, the replay scores it
with the model conditioned on the CURRENT context (`query_entropy`, Eq. 7: normalised predictive entropy of the model
output) and stores the value with the row (`Rows.h`). When the label arrives (day d + tau + 1) the stored value is passed
to the reference as `_h` and drives the admission gate; nothing is recomputed at arrival and the reference's scorer is
never called. A row with no prediction gets h = 0, as in the official code: the context had fewer than 2 rows or fewer
than 2 classes when the row was queried, or the row's arrival index is below the warm-up (the reference zeroes it).
CURE's own tau (entropy threshold, `tau`) has no default for NIDS data and must be passed explicitly; it is not the
label delay.
"""
import numpy as np
import pandas as pd

from cure import CUREPolicy, normalized_entropy
from policies import POLICIES, Policy
from rows import Rows


class CURE(Policy):
    name = "CURE"

    def __init__(self, k, seed=0, tau=None, short_ratio=0.75, warmup_steps=100):
        super().__init__(k, seed)
        if tau is None:
            raise ValueError("CURE tau (entropy threshold) must be set explicitly: no default exists for NIDS data")
        self.tau = float(tau)
        self.ref = CUREPolicy(k=k, short_ratio=short_ratio, tau=tau, warmup_steps=warmup_steps, seed=seed)
        self.state = None     # DataFrame returned by the reference (feature columns, y, row_id, _bank, _h, _arrival)
        self._fam = {}        # rid -> attack family (a flow has one family)

    def query_entropy(self, model, context, rows):
        """Normalised entropy (Eq. 7) of `model` conditioned on `context`, for the rows queried today. 0 where there
        is no prediction (context with fewer than 2 rows or 2 classes)."""
        if len(rows) == 0 or len(context) < 2 or len(np.unique(context.y)) < 2:
            return np.zeros(len(rows))
        return normalized_entropy(model.predict_proba(context, rows.X))

    def _context_rows(self, n_features):
        if self.state is None or len(self.state) == 0:
            return Rows.empty(n_features)
        fcols = [f"f{j}" for j in range(n_features)]
        rid = self.state["row_id"].to_numpy(np.int64)
        return Rows(self.state[fcols].to_numpy(np.float32), self.state["y"].to_numpy(np.uint8),
                    np.asarray([self._fam[int(r)] for r in rid], np.int16), rid)

    def update(self, context, new_labelled_rows, unlabelled_stream):
        n = len(new_labelled_rows)
        nf = new_labelled_rows.X.shape[1]
        mine = self._context_rows(nf)
        if len(context) != len(mine) or not np.array_equal(context.rid, mine.rid):
            raise ValueError("the context handed to CURE differs from CURE's own state")
        if n == 0:
            return mine
        frame = pd.DataFrame(new_labelled_rows.X.astype(np.float32), columns=[f"f{j}" for j in range(nf)])
        frame["y"] = new_labelled_rows.y.astype(np.int64)
        frame["row_id"] = new_labelled_rows.rid.astype(np.int64)
        frame["_h"] = 0.0 if new_labelled_rows.h is None else np.nan_to_num(new_labelled_rows.h, nan=0.0)
        self._fam.update(zip(new_labelled_rows.rid.tolist(), new_labelled_rows.fam.tolist()))
        self.state = self.ref.update(self.state, frame, None, None)   # `_h` present: the scorer is never called
        return self._context_rows(nf)


ALL_POLICIES = dict(POLICIES) | {"CURE": CURE}
