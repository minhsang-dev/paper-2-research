"""Day stream over the Study 1/2 binary cache (development data only: NF-ToN-IoT-v3, NF-CICIDS2018-v3).

Adapted from legacy/build_data_bai3.py (load_cache, clean, day_name, day rule): days are UTC days of
FLOW_START_MILLISECONDS holding >= min_day_rows flows, rows of a day in start-time order.
"""
import hashlib
import json
from pathlib import Path

import numpy as np

from rows import Rows

DAY_MS = 86_400_000
DEV_DATASETS = ("NF-ToN-IoT-v3", "NF-CICIDS2018-v3")
CACHE_DIR = Path(r"D:\Personal\PhD\IUH\bai3-netflow\build\cache")


def seed_of(*parts):
    return int.from_bytes(hashlib.sha256("|".join(map(str, parts)).encode()).digest()[:8], "little")


def clean(x):
    x = np.asarray(x, dtype=np.float32)
    return np.where(np.isfinite(x), x, np.float32(0.0)).astype(np.float32)


class DayStream:
    def __init__(self, dataset, cache_dir=CACHE_DIR, min_day_rows=100_000):
        if dataset not in DEV_DATASETS:
            raise ValueError(f"{dataset} is not a development dataset")
        import pandas as pd
        c = Path(cache_dir) / dataset
        meta = json.loads((c / "meta.json").read_text(encoding="utf-8"))
        n, k = meta["rows"], meta["n_features"]
        self.dataset, self.n_features = dataset, k
        self.attack_names = meta["attack_names"]
        self._feat = np.memmap(c / "feat.bin", dtype=np.float32, mode="r", shape=(n, k))
        self._label = np.memmap(c / "label.bin", dtype=np.uint8, mode="r", shape=(n,))
        self._attack = np.memmap(c / "attack.bin", dtype=np.int16, mode="r", shape=(n,))
        start = np.asarray(np.memmap(c / "start.bin", dtype=np.int64, mode="r", shape=(n,)))
        day = np.where(start >= 0, start // DAY_MS, -1)
        uniq, counts = np.unique(day[day >= 0], return_counts=True)
        kept = [int(d) for d, cnt in zip(uniq, counts) if cnt >= min_day_rows]
        idx = np.flatnonzero(np.isin(day, kept))
        order = idx[np.argsort(start[idx], kind="stable")]
        b = np.searchsorted(day[order], kept + [kept[-1] + 1])
        self.day_index = kept
        self.rows = [order[b[i]:b[i + 1]] for i in range(len(kept))]
        self.names = [pd.Timestamp(d * DAY_MS, unit="ms", tz="UTC").strftime("%Y-%m-%d") for d in kept]

    def __len__(self):
        return len(self.rows)

    def labels(self, i):
        return np.asarray(self._label[self.rows[i]])

    def families(self, i):
        return np.asarray(self._attack[self.rows[i]])

    def get(self, i, pos):
        """Rows at positions `pos` (any order) within day i."""
        g = self.rows[i][np.asarray(pos, dtype=np.int64)]
        o = np.argsort(g, kind="stable")   # sorted reads from the memmap, restored to the requested order
        X = np.empty((len(g), self.n_features), np.float32)
        X[o] = clean(self._feat[g[o]])
        return Rows(X, np.asarray(self._label[g]).astype(np.uint8), np.asarray(self._attack[g]).astype(np.int16),
                    g.astype(np.int64))


def _column(self, i, j):
    """Column j (float32, cleaned) of every row of day i, in the day's row order."""
    g = self.rows[i]
    o = np.argsort(g, kind="stable")
    out = np.empty(len(g), np.float32)
    out[o] = clean(self._feat[g[o], j])
    return out


DayStream.column = _column


def rare_families(fam, y, thr=0.01):
    """Families with < thr of the day's attack flows (benign excluded)."""
    att = fam[y == 1]
    if att.size == 0:
        return np.zeros(0, np.int16)
    f, c = np.unique(att, return_counts=True)
    return f[c / att.size < thr]


def eval_positions(fam, y, n, seed, exclude=None):
    """Fixed stratified sample of ~n positions: every flow of a rare family kept (rare: < 1% of the day's attack
    flows), the rest drawn per stratum (benign / each non-rare family) proportionally, at least one row per stratum.
    Returns (positions ascending, weights) with weight = 1 / inclusion probability. `exclude` positions are never
    drawn."""
    rng = np.random.default_rng(seed)
    avail = np.ones(len(y), bool)
    if exclude is not None and len(exclude):
        avail[np.asarray(exclude)] = False
    keep_all = avail & (y == 1) & np.isin(fam, rare_families(fam, y))
    rest = np.flatnonzero(avail & ~keep_all)
    budget = max(0, n - int(keep_all.sum()))
    pos, w = [np.flatnonzero(keep_all)], [np.ones(int(keep_all.sum()))]
    if budget and rest.size:
        budget = min(budget, rest.size)
        strata = fam[rest]
        classes, counts = np.unique(strata, return_counts=True)
        exact = budget * counts / rest.size
        take = np.floor(exact).astype(int)
        short = budget - int(take.sum())
        for i in sorted(range(len(classes)), key=lambda i: (-(exact[i] - take[i]), classes[i]))[:short]:
            take[i] += 1
        take = np.minimum(np.maximum(take, 1), counts)
        for cl, t, cnt in zip(classes, take, counts):
            members = rest[strata == cl]
            pos.append(rng.choice(members, size=int(t), replace=False))
            w.append(np.full(int(t), cnt / t))
    pos, w = np.concatenate(pos), np.concatenate(w)
    o = np.argsort(pos)
    return pos[o], w[o]
