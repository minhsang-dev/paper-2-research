"""Models. Interface: score(context, X_query) -> attack score in [0, 1]; the context is the training buffer
(LightGBM) or the in-context examples (TabFM)."""
import time

import numpy as np

# Provisional LightGBM setup copied from legacy/pipeline_v3.py train_lgbm (Study 1/2). Step C (Task 3) replaces it
# with lgbm_hparams_locked.json; until then results of this harness are smoke runs only.
LEGACY_LGBM_PARAMS = dict(n_estimators=300, learning_rate=0.05, num_leaves=63, min_child_samples=20, verbosity=-1)


class Model:
    name = "model"
    last_fit_seconds = 0.0
    context_ok = True

    def score(self, context, X):
        raise NotImplementedError

    def predict_proba(self, context, X):
        """(n, C) class probabilities of a model conditioned on `context` (used by CURE's entropy gate); does not
        touch last_fit_seconds / context_ok, which describe the scoring call of the day."""
        raise NotImplementedError


class LightGBMModel(Model):
    name = "LightGBM"

    def __init__(self, params=None, seed=0, n_jobs=2):
        self.params = dict(LEGACY_LGBM_PARAMS if params is None else params)
        self.params.update(random_state=seed, n_jobs=n_jobs)

    def score(self, context, X):
        import lightgbm as lgb
        classes = np.unique(context.y)
        if len(classes) < 2:   # no signal: constant score, flagged
            self.context_ok = False
            self.last_fit_seconds = 0.0
            return np.full(X.shape[0], float(classes[0]) if len(classes) else 0.0)
        self.context_ok = True
        t0 = time.perf_counter()
        m = lgb.LGBMClassifier(**self.params).fit(context.X, context.y)
        self.last_fit_seconds = time.perf_counter() - t0
        return m.predict_proba(X)[:, 1]

    def predict_proba(self, context, X):
        import lightgbm as lgb
        if len(np.unique(context.y)) < 2:
            return np.ones((X.shape[0], 1))
        return lgb.LGBMClassifier(**self.params).fit(context.X, context.y).predict_proba(X)


class TabFMModel(Model):
    """Placeholder: TabFM scoring needs the Colab GPU stack (Task 3 / Step D); not part of Task 1."""
    name = "TabFM"

    def score(self, context, X):
        raise NotImplementedError("TabFM runs on Colab; see cost_pilot.ipynb (Task 3)")
