"""Day-by-day replay (Step A), revision L4.

Design: score first, learn after ("chấm trước, học sau"). Timeline for day t (the first day of the run is warm-up,
evaluation starts on the second):
  1. score day t with the context and D_cal built from labels that arrived before the end of day t-1;
  2. end of day t: query b labels from day t, uniformly at random from ALL rows of the day (the evaluation sample of
     day t is NOT removed from the query pool: it keeps every flow of the rare families, removing it would leave rare
     families without labels). A fraction eta is reserved for the calibration set D_cal and never shown to the
     policy; the other (1-eta)*b go to the policy. All arrive at the end of day t + tau;
  3. arrivals of the end of day t: policy rows -> policy.update(context, new_rows, unlabelled rows of day t);
     reserved rows -> D_cal.
Labels queried on day d are usable from day d + tau + 1 (tau = 0 -> d+1, tau = 1 -> d+2, tau = 7 -> d+8).
D_cal pools the reserved labels that arrived in the last `cal_window_days` (W_V = 3) days (newest `cal_cap` rows at
most). split_vt = False: all of eta*b goes to D_cal (the D_cal/V_t split belongs to RQ3-RQ4).

Isolation conditions (every row has an identity `rid`):
  I1  the evaluation rows of day t are in neither the context nor D_cal when day t is scored;
  I2  rows reserved for D_cal are never returned in the context of any policy, and every context row is a row the
      policy was given (same rid, same content), so a policy cannot smuggle rows in through the unlabelled stream;
  I3  a row is never both reserved and given to the policy.
Real days hold distinct flows, so I1 and I3 hold by construction and are asserted (isolation="assert": a violation
raises IsolationError). Synthetic scenario days are resampled WITH replacement from one root day, so the same root row
can appear on several days of a chain; there isolation="filter" enforces I1/I3 deterministically and independently of
the policy: colliding rows are dropped from the scoring context/D_cal (I1) and, at arrival, a row already reserved is
not given to the policy and a row already given to the policy is not reserved (I3). Counts are reported. I2 is always
asserted.
Scenario streams of generator v2 hold three disjoint row pools per day, exposed by the optional hook
`stream.roles(t)` -> {'eval','policy','cal'} (positions inside day t): the evaluation sample is drawn only from `eval`,
reserved rows only from `cal`, policy rows only from `policy`, so I1 and I3 hold by construction. In `filter` mode
any dropped row stops the run (IsolationError) unless `max_filter_drops=None` (unbounded, for tests of the filter
itself); v2 streams must drop 0 rows. Optional hook `stream.n_flows(t)` gives the nominal flow count of day t for
the A_FP rate (default: number of rows of the day).

Threshold (A_FP = false alarms per day): N_t = flows of day t x benign share of D_cal (D_cal is a uniform sample, so
the share is unbiased); alpha_t = A_FP / N_t; alpha_eff = max(alpha_t, 5 / n_benign_cal), flagged when the floor
applies; threshold = (1 - alpha_eff) quantile of the benign D_cal scores.

Primary metric: AUPRC weighted by inverse sampling probability (`auprc_w`). Secondary: unweighted AUPRC, the
threshold metrics (weighted), and recall per attack family.
"""
import numpy as np
from sklearn.metrics import average_precision_score, f1_score

from data import eval_positions, rare_families, seed_of
from rows import Rows

N_UNLAB = 5000
CAL_MIN_BENIGN = 5   # alpha floor = CAL_MIN_BENIGN / n_benign_cal


class IsolationError(AssertionError):
    pass


def threshold_at_alpha(scores_benign, alpha):
    """Smallest threshold flagging at most alpha of the benign calibration scores (score >= threshold is flagged)."""
    if scores_benign.size == 0:
        return np.inf
    q = np.quantile(scores_benign, 1.0 - min(alpha, 1.0), method="higher")
    return float(np.nextafter(q, np.inf))


def day_metrics(y, fam, w, score, thr, rare):
    pred = (score >= thr).astype(int)
    has_att = bool(y.any())
    ben = y == 0
    out = {
        "auprc_w": float(average_precision_score(y, score, sample_weight=w)) if has_att else None,   # primary
        "auprc": float(average_precision_score(y, score)) if has_att else None,
        "fpr_w": float(np.average(pred[ben], weights=w[ben])) if ben.any() else None,
        "false_alarms_est": float((pred[ben] * w[ben]).sum()) if ben.any() else None,
        "recall_w": float(np.average(pred[y == 1], weights=w[y == 1])) if has_att else None,
        "macro_f1_w": float(f1_score(y, pred, average="macro", sample_weight=w)),
    }
    out["recall_by_family"] = {int(f): float(pred[(y == 1) & (fam == f)].mean())
                               for f in np.unique(fam[y == 1])}
    r = (y == 1) & np.isin(fam, rare)
    out["rare_families"] = [int(f) for f in rare]
    out["n_rare_flows"] = int(r.sum())
    out["rare_recall"] = float(pred[r].mean()) if r.any() else None
    return out


def _isolate(rows, forbidden_rids, mode, what):
    """Rows without any rid in `forbidden_rids`. mode 'assert' raises when something collides."""
    hit = np.isin(rows.rid, forbidden_rids)
    if not hit.any():
        return rows, 0
    if mode == "assert":
        raise IsolationError(f"{what}: {int(hit.sum())} row(s) collide")
    return rows.take(np.flatnonzero(~hit)), int(hit.sum())


def _check_context(ctx, k, reserved_rids, delivered):
    """I2: bounded size, no reserved row, and every row is a row the policy was given (same rid and content)."""
    if len(ctx) > k:
        raise IsolationError(f"context of {len(ctx)} rows exceeds k={k}")
    if np.isin(ctx.rid, reserved_rids).any():
        raise IsolationError("a D_cal (reserved) row was returned in the policy context")
    for j in range(len(ctx)):
        d = delivered.get(int(ctx.rid[j]))
        if d is None or d[0] != int(ctx.y[j]) or not np.array_equal(d[1], ctx.X[j]):
            raise IsolationError("the policy context holds a row that was not given to the policy")


def run_replay(stream, policy, model, *, b, tau, a_fp, eta=0.2, first_day=0, n_days=3, n_eval=10_000,
               cal_cap=5000, cal_window_days=3, isolation="assert", max_filter_drops=0, seed=0):
    ds = stream.dataset
    n_cal_q = int(round(eta * b))
    ctx = Rows.empty(stream.n_features)
    pending = {}     # arrival day -> list of (policy rows, calibration rows)
    cal_days = {}    # arrival day -> reserved rows that arrived at the end of that day
    reserved_ever = np.zeros(0, np.int64)
    delivered = {}   # rid -> (y, X row) of every row given to the policy
    arrival_dropped = {"policy": 0, "cal": 0}
    records = []
    for t in range(first_day, first_day + n_days):
        if t > first_day:
            fam_t, y_t = stream.families(t), stream.labels(t)
            roles = stream.roles(t) if hasattr(stream, "roles") else None
            if roles is None:
                e_pos, e_w = eval_positions(fam_t, y_t, n_eval, seed_of(ds, "eval", t))
            else:
                pool = np.asarray(roles["eval"])
                loc, e_w = eval_positions(fam_t[pool], y_t[pool], n_eval, seed_of(ds, "eval", t))
                e_pos = pool[loc]
            ev = stream.get(t, e_pos)
            cal = Rows.empty(stream.n_features)
            for d in range(t - cal_window_days, t):
                if d in cal_days:
                    cal = Rows.concat(cal, cal_days[d])
            cal = cal.take(np.arange(max(0, len(cal) - cal_cap), len(cal)))
            ctx_s, drop_ctx = _isolate(ctx, ev.rid, isolation, "I1 evaluation rows in context")
            cal_s, drop_cal = _isolate(cal, ev.rid, isolation, "I1 evaluation rows in D_cal")
            scores = model.score(ctx_s, np.concatenate([ev.X, cal_s.X]))
            s_ev, s_cal = scores[:len(ev)], scores[len(ev):]
            s_ben = s_cal[cal_s.y == 0]
            if len(cal_s) and s_ben.size:
                n_flows = stream.n_flows(t) if hasattr(stream, "n_flows") else len(stream.rows[t])
                n_hat = n_flows * s_ben.size / len(cal_s)
                alpha_t = a_fp / n_hat
                alpha_eff = max(alpha_t, CAL_MIN_BENIGN / s_ben.size)
                floor_active = bool(alpha_eff > alpha_t)
            else:
                alpha_t, alpha_eff, floor_active = None, None, None
            thr = threshold_at_alpha(s_ben, alpha_eff) if alpha_eff is not None else float("inf")
            rec = {"dataset": ds, "day": stream.names[t], "policy": policy.name, "model": model.name, "tau": tau,
                   "b": b, "eta": eta, "k": policy.k, "a_fp": a_fp, "seed": seed, "n_ctx": len(ctx),
                   "n_eval": len(ev), "n_cal": len(cal_s), "n_cal_benign": int(s_ben.size),
                   "isolation": isolation, "iso_dropped_ctx": drop_ctx, "iso_dropped_cal": drop_cal,
                   "iso_arrival_dropped_policy": arrival_dropped["policy"],
                   "iso_arrival_dropped_cal": arrival_dropped["cal"],
                   "alpha_t": alpha_t, "alpha_eff": alpha_eff, "alpha_floor_active": floor_active,
                   "context_ok": bool(model.context_ok), "threshold": thr if np.isfinite(thr) else None,
                   "fit_seconds": float(model.last_fit_seconds)}
            rec.update(day_metrics(ev.y, ev.fam, e_w, s_ev, thr, rare_families(fam_t, y_t)))
            records.append(rec)
        # end of day t: query labels from all rows of day t (evaluation rows included)
        n_t = len(stream.rows[t])
        roles = stream.roles(t) if hasattr(stream, "roles") else None
        if roles is None:
            q = np.random.default_rng(seed_of(ds, "query", t, seed)).choice(n_t, size=min(b, n_t), replace=False)
            q = q[np.random.default_rng(seed_of(ds, "split", t, seed)).permutation(len(q))]
            n_res = min(n_cal_q, len(q))
            res_pos, pol_pos = q[:n_res], q[n_res:]
            unl_pool = np.arange(n_t)
        else:
            rng_q = np.random.default_rng(seed_of(ds, "query", t, seed))
            res_pos = rng_q.choice(roles["cal"], size=min(n_cal_q, len(roles["cal"])), replace=False)
            pol_pos = rng_q.choice(roles["policy"], size=min(b - len(res_pos), len(roles["policy"])), replace=False)
            unl_pool = np.concatenate([roles["policy"], roles["cal"]])   # evaluation rows are never in the stream
        pol_rows = stream.get(t, np.sort(pol_pos))
        if hasattr(policy, "query_entropy"):
            # Score first, learn after (CURE): the rows queried today are scored now by the model conditioned on the
            # current context; the entropy is stored with the row and used when the label arrives (day t + tau + 1).
            pol_rows.h = policy.query_entropy(model, ctx, pol_rows)
        pending.setdefault(t + tau, []).append((pol_rows, stream.get(t, np.sort(res_pos))))
        new = Rows.empty(stream.n_features)
        new_cal = Rows.empty(stream.n_features)
        for pol_rows, cal_rows in pending.pop(t, []):
            new = Rows.concat(new, pol_rows)
            new_cal = Rows.concat(new_cal, cal_rows)
        # I3 at arrival: reserved rows first, then policy rows that are not reserved
        new_cal, n1 = _isolate(new_cal, np.fromiter(delivered, np.int64, len(delivered)), isolation,
                               "I3 reserved row already given to the policy")
        reserved_ever = np.union1d(reserved_ever, new_cal.rid)
        new, n2 = _isolate(new, reserved_ever, isolation, "I3 policy row already reserved")
        arrival_dropped["cal"] += n1
        arrival_dropped["policy"] += n2
        if len(new_cal):
            cal_days[t] = new_cal
        for j in range(len(new)):
            delivered.setdefault(int(new.rid[j]), (int(new.y[j]), new.X[j].copy()))
        if isolation == "filter" and max_filter_drops is not None:
            total = arrival_dropped["policy"] + arrival_dropped["cal"] + sum(
                r["iso_dropped_ctx"] + r["iso_dropped_cal"] for r in records)
            if total > max_filter_drops:
                raise IsolationError(f"filter dropped {total} row(s) (allowed {max_filter_drops}): the stream does not "
                                     f"isolate by construction")
        u = np.sort(np.random.default_rng(seed_of(ds, "unlab", t)).choice(unl_pool, size=min(N_UNLAB, len(unl_pool)),
                                                                          replace=False))
        ctx = policy.update(ctx, new, stream.get(t, u).X)
        _check_context(ctx, policy.k, reserved_ever, delivered)
    return records
