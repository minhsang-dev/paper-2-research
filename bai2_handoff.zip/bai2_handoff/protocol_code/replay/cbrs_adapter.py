"""Adapters that expose the harness CBRS policies with the contract of cbrs_ref/cbrs_crosscheck.py:
    init(m, columns, label_col) -> empty DataFrame memory;  update(memory, new_rows, rng) -> memory
The memory has the columns sid, x, y; slot i is row i. The policy object travels in memory.attrs and uses the
Generator handed to `update` (so a run is comparable slot by slot with the reference).
`*_binary`: harness policy CBRS (class = binary label, y must be 0/1). `*_family`: CBRSFamily (class = the label
column, taken as the attack family; the binary label is 'family > 0')."""
import numpy as np
import pandas as pd

from policies import CBRS, CBRSFamily
from rows import Rows


def _to_rows(df, family):
    lab = df["y"].to_numpy()
    y = (lab > 0).astype(np.uint8) if family else lab.astype(np.uint8)
    return Rows(df[["x"]].to_numpy(np.float32), y, lab.astype(np.int16), df["sid"].to_numpy(np.int64))


def _to_frame(rows, family):
    return pd.DataFrame({"sid": rows.rid.astype(np.int64), "x": rows.X[:, 0].astype(np.float64),
                         "y": (rows.fam if family else rows.y).astype(np.int64)})


def _make(cls, family):
    def init(m, columns, label_col="y"):
        mem = pd.DataFrame({"sid": pd.Series([], dtype="int64"), "x": pd.Series([], dtype="float64"),
                            "y": pd.Series([], dtype="int64")})
        mem.attrs["policy"] = cls(k=m)
        return mem

    def update(memory, new_rows, rng):
        pol = memory.attrs["policy"]
        pol.rng = rng
        ctx = _to_rows(memory, family) if len(memory) else Rows.empty(1)
        out = _to_frame(pol.update(ctx, _to_rows(new_rows, family), None), family)
        out.attrs["policy"] = pol
        return out
    return init, update


init_binary, update_binary = _make(CBRS, False)
init_family, update_family = _make(CBRSFamily, True)
