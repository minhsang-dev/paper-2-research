"""Cross-check of the harness CBRS / CBRS-family against the reference cbrs_ref/cbrs.py with cbrs_crosscheck.py.
Writes the streams to out/cbrs_streams/ and the reports to out/cbrs_crosscheck/ (summary.json). Expected verdict:
IDENTICAL (same memory slot by slot for every seed). A negative control (reference vs the reference variant that tracks
fullness during the fill phase) must come out DIFFERENT, showing that the check can see that error."""
import json
import os
import subprocess
import sys
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
REF = HERE.parent / "cbrs_ref"
OUT = HERE / "out" / "cbrs_crosscheck"
STREAMS = HERE / "out" / "cbrs_streams"
M, SEEDS = 1000, 30


def binary_streams():
    STREAMS.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(2026)
    specs = {   # name: (n_benign, n_attack, kind)
        "bin_minority_shuffled": (5000, 300, "shuffle"),      # attacks < m/2: Property 1 applies
        "bin_minority_first": (5000, 108, "attack_first"),    # first arrival is an attack (fill-phase edge)
        "bin_attack_majority": (150, 4000, "shuffle"),        # the class order flips
        "bin_blocks": (4000, 400, "blocks"),                  # benign block, then attack block (drift-like)
    }
    paths = {}
    for name, (nb, na, kind) in specs.items():
        y = np.r_[np.zeros(nb, int), np.ones(na, int)]
        if kind == "shuffle":
            rng.shuffle(y)
        elif kind == "attack_first":
            rng.shuffle(y)
            k = int(np.flatnonzero(y == 1)[0])
            y[0], y[k] = y[k], y[0]
        df = pd.DataFrame({"sid": np.arange(len(y)), "x": rng.normal(size=len(y)), "y": y})
        p = STREAMS / f"{name}.csv"
        df.to_csv(p, index=False)
        paths[name] = p
    return paths


def run(a, b, stream, out_name, expect_exit=0):
    OUT.mkdir(parents=True, exist_ok=True)
    cmd = [sys.executable, str(REF / "cbrs_crosscheck.py"), "--a", a, "--b", b, "--stream", stream, "--m", str(M),
           "--seeds", str(SEEDS), "--out", str(OUT / out_name)]
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=str(HERE))
    if not (OUT / out_name).exists():
        raise SystemExit(f"cross-check failed ({out_name}): {r.stdout[-800:]} {r.stderr[-800:]}")
    rep = json.loads((OUT / out_name).read_text())
    return {"report": out_name, "stream": stream, "verdict": rep["verdict"], "exit": r.returncode,
            "exact_same_slots_rate": rep["exact_same_slots_rate"], "property1_pass_rate_A": rep["property1_pass_rate_A"],
            "property1_pass_rate_B": rep["property1_pass_rate_B"], "n_seeds": rep["seeds"]}


def main():
    rel = lambda p: os.path.relpath(p, HERE)   # noqa: E731  (a drive letter's ':' breaks the FILE:FN syntax)
    ref = f"{rel(REF / 'cbrs.py')}:update:empty_memory"
    fam = f"{rel(HERE / 'cbrs_adapter.py')}:update_family:init_family"
    binr = f"{rel(HERE / 'cbrs_adapter.py')}:update_binary:init_binary"
    res = []
    for s in ("fig1", "interleaved", "interleaved-b"):
        res.append(run(ref, fam, s, f"family_{s}.json"))
    for name, p in binary_streams().items():
        res.append(run(ref, binr, f"csv:{rel(p)}", f"binary_{name}.json"))
    # negative control: the reference variant that marks fullness during the fill phase must differ
    res.append(run(ref, f"{rel(REF / 'cbrs.py')}:cbrs_always_update:empty_memory_always", "interleaved-b",
                   "control_ref_vs_always_interleaved-b.json"))
    (OUT / "summary.json").write_text(json.dumps(res, indent=1), encoding="utf-8")
    for r in res:
        print(r["report"], r["verdict"], r["exact_same_slots_rate"], r["property1_pass_rate_A"],
              r["property1_pass_rate_B"], flush=True)


if __name__ == "__main__":
    main()
