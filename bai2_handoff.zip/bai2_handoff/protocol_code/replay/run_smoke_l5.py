"""Smoke run L5 (same design as L4; CURE now scores rows on the query day): one scenario of each kind x 5 policies, LightGBM with the provisional Study 1/2 parameters.
Mechanism check only (not results, not for H1). Scenario choice fixed by rule before running: root day = the smallest
root day (NF-ToN-IoT-v3 2019-04-28, the tightest pools), scenario index 0 of each kind. CURE's tau is a PLACEHOLDER
(0.3); the pre-registered rule for tau is not applied here. isolation='filter' with max_filter_drops=0: a single
dropped row stops the run. Output: out/smoke_l5.json."""
import json
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from data import DayStream  # noqa: E402
from models import LightGBMModel  # noqa: E402
from policies_cure import ALL_POLICIES, CURE  # noqa: E402
from replay import run_replay  # noqa: E402
from scenario_stream import ScenarioStream  # noqa: E402

DATASET, ROOT_DAY = "NF-ToN-IoT-v3", "2019-04-28"
B, ETA, TAU_DELAY, K, A_FP, SEED, N_EVAL = 2000, 0.2, 1, 2000, 1000, 42, 10_000
CURE_TAU_PLACEHOLDER = 0.3


def main():
    t0 = time.perf_counter()
    man = json.loads((HERE.parent / "scenario_manifest.json").read_text(encoding="utf-8"))
    pools = {p["day"]: p["sha256"] for p in man["datasets"][DATASET]["pools"]}
    root = DayStream(DATASET)
    out = {"config": dict(dataset=DATASET, root_day=ROOT_DAY, b=B, eta=ETA, label_delay=TAU_DELAY, k=K, a_fp=A_FP,
                          seed=SEED, n_eval=N_EVAL, cure_tau_placeholder=CURE_TAU_PLACEHOLDER,
                          manifest_generator_sha256=man["generator_sha256"]), "records": []}
    total_drops = 0
    for kind in ("feature", "prior", "recurring"):
        scn = next(s for s in man["scenarios"] if s["dataset"] == DATASET and s["root_day"] == ROOT_DAY
                   and s["kind"] == kind and s["id"].endswith("|0"))
        stream = ScenarioStream(root, scn, expected_pool_sha256=pools[ROOT_DAY])
        for name, cls in ALL_POLICIES.items():
            pol = CURE(k=K, seed=SEED, tau=CURE_TAU_PLACEHOLDER) if name == "CURE" else cls(k=K, seed=SEED)
            recs = run_replay(stream, pol, LightGBMModel(seed=SEED), b=B, eta=ETA, tau=TAU_DELAY, a_fp=A_FP,
                              n_days=len(scn["days"]), n_eval=N_EVAL, isolation="filter", max_filter_drops=0,
                              seed=SEED)
            for r in recs:
                r["scenario"] = scn["id"]
                r["kind"] = kind
                total_drops += (r["iso_dropped_ctx"] + r["iso_dropped_cal"] + r["iso_arrival_dropped_policy"]
                                + r["iso_arrival_dropped_cal"])
            out["records"] += recs
            print(kind, name, len(recs), "records", round(time.perf_counter() - t0, 1), "s", flush=True)
    out["total_filter_dropped_rows"] = total_drops
    (HERE / "out").mkdir(exist_ok=True)
    (HERE / "out" / "smoke_l5.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    print("total filter-dropped rows:", total_drops)


if __name__ == "__main__":
    main()
