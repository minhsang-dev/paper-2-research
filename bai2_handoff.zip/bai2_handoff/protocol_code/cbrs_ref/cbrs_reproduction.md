# CBRS reproduction check

**Paper:** Chrysakis & Moens, "Online Continual Learning from Imbalanced Data", ICML 2020, PMLR 119 (Algorithm 1, §2.2, Fig. 1).
**Implementation under test:** `cbrs.py`, an independent reimplementation; no official code exists (`cbrs_spec.md`).
**Raw numbers:** `cbrs_repro_results.json` (from `python cbrs_repro.py --runs 2000`) and `cbrs_repro_extra_results.json` (from `python cbrs_repro_extra.py --runs 2000`).
**Environment:** Python 3.13, numpy 2.5.3, pandas 3.0.5, scipy 1.18.1. No external data was used.

## 1. Settings (all synthetic; 2,000 Monte Carlo runs each)

| ID | Stream | m |
|---|---|---|
| S1 "Fig. 1-like" | MNIST classes 0–4, one class after another (paper order). Sizes (51, 581, 162, 1669, 5030) = MNIST train counts × retention factor, scaled so that class 0 has exactly 51 (paper: "the smallest class of the stream contains 51 instances"). Classes 0 and 2 get 10^-2 and 10^-1.5 (paper: both < 200). **Assumed** factors for 1, 3, 4: 10^-1, 10^-0.5, 10^0 (not given in the paper). | 1000 |
| S2a | Paper protocol (§3.1): 10 MNIST-size classes, retention factors r = (10^-2 … 10^0) re-drawn at random every run ("starting over" for >5 classes), classes arrive in increasing order | 500 |
| S2b | Same protocol, 10 CIFAR-10-size classes (5000 each) | 1000 |
| S3 | Interleaved stream: 5 classes in proportions ∝ r (34, 108, 342, 1084, 3429), randomly shuffled once (seed 12345); same order in every run | 1000 |
| S3b | S3 with the first arrival swapped to a class-1 instance (fill-phase edge case) | 1000 |
| S4 | 2,000 random streams: K ∈ [2, 10], log-normal class sizes, sequential, shuffled or bursty order, random m | random |

Only the CBRS randomness changes between runs (`numpy.random.default_rng(seed)`, seed = run index). In S2 and S4 the stream itself also changes per run.

## 2. Properties and results

**P1 (paper, Property 1).** "If the stream contains a class with less than m/n_c instances, then all of these instances will be stored in memory after the stream has been read in whole." Pass rate across runs:

| S1 | S2a | S2b | S3 | S3b | S4 |
|---|---|---|---|---|---|
| 1.000 (classes 0, 2) | 1.000 | 1.000 | 1.000 (classes 0, 1) | 1.000 | 1.000 (2,000 random streams) |

**PASS** (0 violations in 12,000 runs).

**P2 (paper, Property 2).** "The subset of the instances from each class that are stored in memory is iid with respect to the instances of the same class contained in the stream." This was tested as a uniform random subset of each class's stream instances, on every class that is not stored in full.

The tests were:

* **(a)** Per-decile inclusion rates (stream position within the class), with 99% CIs, compared against the expected rate E[m_c]/n_c.
* **(b)** A Hotelling T² test that all 10 decile rates are equal, with per-run dependence handled.
* **(c)** A per-position χ² test with df = n_c − 1. This test is exact for a fixed m_c, which holds here.
* **(d)** A second-order check: the number of adjacent stored pairs (i, i+1) against its expected value m_c(m_c−1)/n_c.

| Setting / class | n_c | m_c | expected inclusion | Hotelling p | position χ² p | positions outside 99% band | adjacent pairs obs − exp (99% CI) |
|---|---|---|---|---|---|---|---|
| S1 / 1 | 581 | 262 | 0.4509 | 0.042 | 0.036 | 0.9% | +0.12 (−0.22, 0.47) |
| S1 / 3 | 1669 | 262 | 0.1570 | 0.322 | 0.028 | 1.1% | −0.01 (−0.32, 0.30) |
| S1 / 4 | 5030 | 263 | 0.0523 | 0.841 | 0.753 | 0.8% | +0.02 (−0.18, 0.22) |
| S3 / 2 | 342 | 286 | 0.8363 | 0.596 | 0.146 | 1.5% | +0.02 (−0.12, 0.16) |
| S3 / 3 | 1084 | 286 | 0.2638 | 0.690 | 0.246 | 1.0% | −0.05 (−0.42, 0.32) |
| S3 / 4 | 3429 | 286 | 0.0834 | 0.814 | 0.425 | 1.3% | +0.04 (−0.22, 0.29) |
| S1 replication (fresh seeds 1,000,000+) / 1, 3, 4 | | | | 0.568 / 0.397 / 0.703 | 0.213 / 0.105 / 0.479 | — | all CIs contain 0 |

The main run produced one marginal flag. The 99% CI for S1/class 1, decile 3, was [0.4517, 0.4588], which just misses the expected 0.4509. That is 1 miss out of 60 decile intervals, where about 0.6 misses are expected by chance; the smallest p-value is 0.028, and no test is significant after Bonferroni correction (24 tests). A fresh-seed replication with 2,000 runs passes every test. **PASS.**

As a positive control, plain reservoir sampling also passes P2 (it is uniform within each class) but fails P1 (pass rate 0.000 in S3).

**Memory size (implicit in Alg. 1).** The memory holds exactly min(m, t) items after t arrivals: 1.000 in all settings. **PASS.**

**D1 (derived invariant, not stated in the paper).** Every class that never became full is stored in its entirety. The rate is 1.000 in S1, S2a, S2b, S3 and S4. This is the mechanism behind P1. **PASS.**

**D2 (derived, matches the paper's "keep the classes as balanced as possible").** At the end of the stream, the memory counts of the full classes differ by at most 1, and the final counts equal the "water-level" allocation min(n_c, L) up to ±1. The spread was ≤ 1 in 100% of runs in every setting. The maximum deviation from the water level was 0 (S2a), 1 (S2b) and 0 (S3). **PASS.**

## 3. Figure 1 comparison (m = 1000, MNIST 0–4)

| | class 0 | class 1 | class 2 | class 3 | class 4 |
|---|---|---|---|---|---|
| stream (S1) | 51 | 581 | 162 | 1669 | 5030 |
| CBRS memory (all 2,000 runs identical counts) | **51** | 262 | **162** | 262 | 263 |
| Reservoir memory, mean (expected 1000·n_c/N) | 6.85 (6.81) | 77.16 (77.54) | 21.53 (21.62) | 223.20 (222.74) | 671.27 (671.29) |

Paper: CBRS "does not discard any instances from the significantly underrepresented classes 0 and 2" and "balances the remaining three". **Reproduced.** Classes 0 and 2 are stored in full, and classes 1, 3, 4 hold 262/262/263. This qualitative result does not depend on the assumed factors for classes 1, 3, 4, as long as each of those classes has more than 263 instances.

Paper (§3.6): with m = 255, CBRS "would keep the memory perfectly balanced". **Reproduced:** 51/51/51/51/51 in 2,000/2,000 runs.

The figure's exact bar heights are not printed in the text, so no numeric comparison with the figure itself was possible.

The paper-protocol runs (S2) give the mean memory count per retention factor:

* S2a (m = 500): 50 / 50 / 50 / 50 / 50. The water level is 50, and even the smallest MNIST class at 10^-2 has about 54 instances, so every class is capped at 50.
* S2b (m = 1000): 50.0 / 112.5 / 112.5 / 112.5 / 112.5, for factors 10^-2 … 10^0. The 10^-2 classes are kept in full (50 each).

## 4. Interpretation finding: when "full" is first evaluated

The paper defines a class as full if it "currently is, or has been in one of the previous time steps, the largest class". The definition does not say whether the fill phase counts. Under the variant that also marks classes that were largest during the fill phase (`full_tracking="always"`), the results are:

* **S3b:** P1 pass rate **0.000**. Class 1, with 108 instances, ends at 21 instead of 108, because the first arrival makes it "largest". Memory counts are 34/21/315/315/315.
* **S4:** P1 pass rate **0.8975**, versus 1.000 for the reference.
* **S1, S2 and S3:** results identical to the reference. In these streams the class that is largest during the fill phase never gets more instances later.

So the paper's Property 1 holds only if fullness is evaluated after the memory is filled, and `cbrs.py` uses that reading. When you check another implementation, run the `interleaved-b` stream: it is the one that separates the two readings.

## 5. Implementation consistency and cross-check demos

* The DataFrame API (`update`, batches of 10) and the label-level core give **identical memories** on 5 seeds.
* There is no official code, so step 4 of the task (running both implementations on the same streams and seeds) could not be done against the authors' code. Instead, `cbrs_crosscheck.py` was demonstrated with the following pairs (reports in `crosscheck_demo/`):

| A vs B | stream, seeds | verdict | details |
|---|---|---|---|
| cbrs.py vs cbrs.py | fig1, 50 | IDENTICAL | slot-for-slot equal in 50/50 seeds |
| cbrs.py vs `cbrs_alt.py` (pandas-only rewrite, different RNG consumption) | interleaved, 100 | EQUIVALENT_IN_DISTRIBUTION | 0/100 identical memories, equal class counts in every seed, 0/55 significant tests, P1 1.0 / 1.0 |
| cbrs.py vs fill-phase "always" variant | interleaved-b, 50 | DIFFERENT | 25/55 significant tests; P1 1.0 vs 0.0 |
| cbrs.py vs reservoir sampling | fig1, 50 | DIFFERENT | 50/55 significant tests; P1 1.0 vs 0.0 |

## 6. Verdict

Every property the paper states about CBRS was reproduced under the "evaluate fullness after the memory is filled" reading of Algorithm 1:

* Property 1 (small classes kept whole): **PASS**.
* Property 2 (uniform within-class sample): **PASS**.
* The Fig. 1 qualitative memory composition: **PASS**.
* The m = 255 perfect-balance remark: **PASS**.

Limits of this check:

* The proofs in the supplement and the exact Fig. 1 bar heights could not be retrieved.
* The Fig. 1 retention factors for classes 1, 3 and 4 are assumed.
* No classifier-accuracy results were reproduced; this check covers only the memory policy.
