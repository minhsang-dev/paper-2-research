"""Extra checks: (a) confirmatory replication of the S1 within-class uniformity tests with
fresh seeds; (b) the paper's statement that in the Figure-1 stream CBRS 'would keep the memory
perfectly balanced if its size was m = 255'.
Usage: python cbrs_repro_extra.py [--runs 2000] [--out cbrs_repro_extra_results.json]"""
import argparse, json
import numpy as np
from cbrs_repro import fig1_stream, monte_carlo, within_class_uniformity

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", type=int, default=2000)
    ap.add_argument("--seed0", type=int, default=1_000_000)
    ap.add_argument("--out", default="cbrs_repro_extra_results.json")
    a = ap.parse_args()
    sizes, y = fig1_stream()
    srcs, _ = monte_carlo(y, 1000, a.runs, 2, seed0=a.seed0)
    rep = [within_class_uniformity(y, srcs, c) for c in (1, 3, 4)]
    s255, _ = monte_carlo(y, 255, a.runs, 2, seed0=a.seed0)
    c255 = np.array([np.bincount(y[s], minlength=5) for s in s255])
    out = {"runs": a.runs, "seed0": a.seed0, "S1_replication_uniformity": rep,
           "m255_min_counts": c255.min(0).tolist(), "m255_max_counts": c255.max(0).tolist(),
           "m255_perfectly_balanced_rate": float(np.mean((c255 == 51).all(1)))}
    json.dump(out, open(a.out, "w"), indent=1)
    for u in rep:
        print(u["class"], round(u["hotelling_p"], 4), u.get("position_chi2_p"), u["deciles_all_cover_expected_99"], u["adjacent_pairs_ok"], u["pass"])
    print("m=255", out["m255_min_counts"], out["m255_max_counts"], out["m255_perfectly_balanced_rate"])
