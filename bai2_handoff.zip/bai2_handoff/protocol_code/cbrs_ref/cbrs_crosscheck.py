"""Cross-check two memory-update policies on the same stream and seeds.

Each policy is given as  FILE_OR_MODULE:UPDATE_FN[:INIT_FN]
  UPDATE_FN(memory, new_rows, rng) -> memory      (rng = numpy.random.Generator)
  INIT_FN(m, columns, label_col) -> empty memory  (optional; default: empty DataFrame,
                                                    and m is passed as update(..., m=m))
Examples
  python cbrs_crosscheck.py --a cbrs.py:update:empty_memory --b cbrs.py:update:empty_memory
  python cbrs_crosscheck.py --a cbrs.py:update:empty_memory \
         --b my_adapter.py:update:init --stream fig1 --seeds 200
  python cbrs_crosscheck.py ... --stream csv:my_stream.csv   (needs a 'y' column)

Both policies receive identical batches and, per seed, Generators created with
numpy.random.default_rng(seed).  Every stream row carries a unique integer 'sid'
so stored rows can be identified.  The report contains
  1. exact agreement: memories identical slot-by-slot / as sets, per seed;
  2. class-count agreement: per-class memory counts per seed (A - B);
  3. Property 1 (paper): classes with n_c < m / n_classes stored entirely, for A and B;
  4. distributional agreement of WHICH instances are kept: per class and stream-position
     decile, per-seed inclusion rates of A vs B compared with Welch t-tests
     (Bonferroni over all tests, alpha = 0.001) -- meaningful even when the two
     implementations consume random numbers differently.
Verdict: IDENTICAL | EQUIVALENT_IN_DISTRIBUTION | DIFFERENT.  Exit code 0/0/1.
"""
from __future__ import annotations

import argparse
import importlib
import importlib.util
import inspect
import json
import os
import sys

import numpy as np
import pandas as pd

R_FACTORS = np.array([10 ** -2, 10 ** -1.5, 10 ** -1, 10 ** -0.5, 10 ** 0])


def load_policy(spec: str):
    parts = spec.split(":")
    if len(parts) not in (2, 3):
        raise SystemExit(f"bad policy spec {spec!r}; use FILE_OR_MODULE:UPDATE_FN[:INIT_FN]")
    src = parts[0]
    if src.endswith(".py") or os.path.sep in src:
        path = os.path.abspath(src)
        sys.path.insert(0, os.path.dirname(path))
        name = f"_xc_{abs(hash(path))}"
        sp = importlib.util.spec_from_file_location(name, path)
        mod = importlib.util.module_from_spec(sp)
        sys.modules[name] = mod
        sp.loader.exec_module(mod)
    else:
        mod = importlib.import_module(src)
    upd = getattr(mod, parts[1])
    init = getattr(mod, parts[2]) if len(parts) == 3 else None
    return upd, init


def make_stream(kind: str, seed: int = 12345) -> pd.DataFrame:
    if kind == "fig1":          # classes 0..4, sequential; see cbrs_reproduction.md
        sizes = [51, 581, 162, 1669, 5030]
        y = np.concatenate([np.full(k, c) for c, k in enumerate(sizes)])
    elif kind in ("interleaved", "interleaved-b"):
        sizes = np.floor(R_FACTORS / R_FACTORS.sum() * 5000).astype(int)
        y = np.concatenate([np.full(k, c) for c, k in enumerate(sizes)])
        np.random.default_rng(seed).shuffle(y)
        if kind == "interleaved-b":     # first arrival is a class-1 instance (fill-phase edge case)
            k = int(np.flatnonzero(y == 1)[0])
            y[0], y[k] = y[k], y[0]
    elif kind.startswith("csv:"):
        df = pd.read_csv(kind[4:])
        if "sid" not in df.columns:
            df.insert(0, "sid", np.arange(len(df)))
        return df
    else:
        raise SystemExit(f"unknown stream {kind!r}")
    rng = np.random.default_rng(seed + 1)
    return pd.DataFrame({"sid": np.arange(len(y)), "x": rng.normal(size=len(y)), "y": y})


def run_policy(upd, init, stream, m, seed, batch, label_col):
    cols = list(stream.columns)
    if init is not None:
        mem = init(m, cols, label_col)
        kw = {}
    else:
        mem = stream.iloc[:0].copy()
        kw = {"m": m} if "m" in inspect.signature(upd).parameters else {}
    rng = np.random.default_rng(seed)
    for s in range(0, len(stream), batch):
        mem = upd(mem, stream.iloc[s:s + batch], rng, **kw)
    if len(mem) > m:
        raise RuntimeError(f"policy returned {len(mem)} rows > m={m}")
    return mem["sid"].to_numpy(dtype=np.int64)


def welch_p(a, b):
    from scipy import stats
    a, b = np.asarray(a, float), np.asarray(b, float)
    if np.allclose(a, a[0]) and np.allclose(b, b[0]):
        return 1.0 if np.isclose(a[0], b[0]) else 0.0
    import warnings
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)   # near-constant samples
        p = stats.ttest_ind(a, b, equal_var=False).pvalue
    return float(p) if np.isfinite(p) else (1.0 if np.isclose(a.mean(), b.mean()) else 0.0)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--a", required=True)
    ap.add_argument("--b", required=True)
    ap.add_argument("--stream", default="fig1")
    ap.add_argument("--m", type=int, default=1000)
    ap.add_argument("--seeds", type=int, default=100)
    ap.add_argument("--seed0", type=int, default=0)
    ap.add_argument("--batch", type=int, default=10)
    ap.add_argument("--label-col", default="y")
    ap.add_argument("--alpha", type=float, default=0.001)
    ap.add_argument("--out", default=None, help="write JSON report here")
    a = ap.parse_args(argv)

    stream = make_stream(a.stream)
    y = stream[a.label_col].to_numpy()
    classes, y_idx = np.unique(y, return_inverse=True)
    sizes = np.bincount(y_idx)
    sid2row = pd.Series(np.arange(len(stream)), index=stream["sid"].to_numpy())
    thr = a.m / len(classes)
    small = [i for i in range(len(classes)) if sizes[i] < thr]

    pols = {"A": load_policy(a.a), "B": load_policy(a.b)}
    res = {k: [] for k in pols}
    for seed in range(a.seed0, a.seed0 + a.seeds):
        for k, (upd, init) in pols.items():
            res[k].append(run_policy(upd, init, stream, a.m, seed, a.batch, a.label_col))

    # 1. exact agreement
    same_order = [np.array_equal(x, z) for x, z in zip(res["A"], res["B"])]
    same_set = [set(x.tolist()) == set(z.tolist()) for x, z in zip(res["A"], res["B"])]
    first_diff = next((a.seed0 + i for i, s in enumerate(same_set) if not s), None)

    # 2./3. class counts and Property 1
    nbins = 10
    rank = np.zeros(len(stream), int)
    for c in range(len(classes)):
        pos = np.flatnonzero(y_idx == c)
        rank[pos] = np.minimum((np.arange(len(pos)) * nbins) // max(1, len(pos)), nbins - 1)
    binsize = np.zeros((len(classes), nbins))
    np.add.at(binsize, (y_idx, rank), 1)
    counts, p1, rates = {}, {}, {}
    for k in pols:
        cnt, ok, rt = [], [], []
        for sids in res[k]:
            rows = sid2row.loc[sids].to_numpy()
            cc = np.bincount(y_idx[rows], minlength=len(classes))
            cnt.append(cc)
            ok.append(all(cc[i] == sizes[i] for i in small))
            h = np.zeros((len(classes), nbins))
            np.add.at(h, (y_idx[rows], rank[rows]), 1)
            rt.append(np.divide(h, binsize, out=np.zeros_like(h), where=binsize > 0))
        counts[k], p1[k], rates[k] = np.array(cnt), float(np.mean(ok)), np.array(rt)
    dcount = counts["A"] - counts["B"]

    # 4. distributional tests
    tests = []
    for c in range(len(classes)):
        tests.append((f"count[{classes[c]}]", welch_p(counts["A"][:, c], counts["B"][:, c]),
                      float(counts["A"][:, c].mean()), float(counts["B"][:, c].mean())))
        for d in range(nbins):
            if binsize[c, d] == 0:
                continue
            tests.append((f"incl[{classes[c]}][decile {d}]",
                          welch_p(rates["A"][:, c, d], rates["B"][:, c, d]),
                          float(rates["A"][:, c, d].mean()), float(rates["B"][:, c, d].mean())))
    thr_p = a.alpha / len(tests)
    sig = [t for t in tests if t[1] < thr_p]

    if all(same_order):
        verdict = "IDENTICAL"
    elif not sig and p1["A"] == p1["B"] == 1.0:
        verdict = "EQUIVALENT_IN_DISTRIBUTION"
    else:
        verdict = "DIFFERENT"
    report = {
        "policy_A": a.a, "policy_B": a.b, "stream": a.stream, "stream_class_sizes":
            dict(zip(map(str, classes), sizes.tolist())), "m": a.m, "seeds": a.seeds, "batch": a.batch,
        "exact_same_slots_rate": float(np.mean(same_order)), "exact_same_set_rate": float(np.mean(same_set)),
        "first_seed_with_different_set": first_diff,
        "mean_class_counts_A": dict(zip(map(str, classes), counts["A"].mean(0).round(3).tolist())),
        "mean_class_counts_B": dict(zip(map(str, classes), counts["B"].mean(0).round(3).tolist())),
        "max_abs_class_count_diff_any_seed": int(np.abs(dcount).max()),
        "seeds_with_any_class_count_diff": int((np.abs(dcount).sum(1) > 0).sum()),
        "property1_classes": [str(classes[i]) for i in small],
        "property1_pass_rate_A": p1["A"], "property1_pass_rate_B": p1["B"],
        "n_distribution_tests": len(tests), "bonferroni_threshold": thr_p,
        "significant_differences": [{"test": t[0], "p": t[1], "mean_A": t[2], "mean_B": t[3]} for t in sig],
        "verdict": verdict,
    }
    txt = json.dumps(report, indent=1)
    print(txt)
    if a.out:
        tmp = a.out + ".tmp"
        with open(tmp, "w") as f:
            f.write(txt)
        os.replace(tmp, a.out)
    return 0 if verdict != "DIFFERENT" else 1


if __name__ == "__main__":
    sys.exit(main())
