# CBRS reference implementation and cross-check kit

This folder holds an independent reference implementation of Class-Balancing Reservoir Sampling (CBRS) from Chrysakis & Moens, ICML 2020 (PMLR 119), and a Monte Carlo check of the properties the paper states. No official code exists (see `cbrs_spec.md`), so `cbrs.py` is written from the paper's Algorithm 1 alone.

| File | Purpose |
|---|---|
| `cbrs_spec.md` | Algorithm 1 and the definitions, quoted from the paper, plus the interpretation choices |
| `cbrs.py` | Reference implementation: `update(memory, new_rows, rng) -> memory`, label column `y` |
| `cbrs_repro.py` | Monte Carlo reproduction script (2,000 runs per setting) |
| `cbrs_repro_results.json` | Raw results of `python cbrs_repro.py --runs 2000` |
| `cbrs_repro_extra.py`, `cbrs_repro_extra_results.json` | Fresh-seed replication of the uniformity tests, and the paper's m = 255 balance remark |
| `cbrs_reproduction.md` | Properties tested, numbers, and verdict |
| `cbrs_crosscheck.py` | Compares two policy implementations on the same stream and seeds |
| `cbrs_alt.py` | A second, deliberately different CBRS implementation, used to demo the cross-check |
| `crosscheck_demo/*.json` | Cross-check reports produced in the sandbox |
| `SHA256SUMS` | SHA-256 of every file above |

Requirements: Python ≥ 3.9, numpy, pandas, and scipy (scipy is used only for the test statistics).

## Using the reference implementation

```python
import numpy as np, cbrs
mem = cbrs.empty_memory(m=1000, columns=["sid", "x", "y"])   # state lives in mem.attrs["cbrs_state"]
rng = np.random.default_rng(0)
for batch in batches:                    # pandas DataFrames with a 'y' column
    mem = cbrs.update(mem, batch, rng)   # rows processed one at a time, as in Algorithm 1
```

Given the same stream and the same Generator, the output is always identical. The exact order in which random numbers are drawn is documented in the `cbrs.py` docstring. Another implementation can therefore aim for slot-by-slot identity if it follows the same order.

## Comparing with `bai1_protocol/replay/policies.py` on your machine

1. Copy `cbrs.py`, `cbrs_crosscheck.py` (and optionally `cbrs_alt.py`) next to your project, or add this folder to `PYTHONPATH`.
2. Write a small adapter that exposes your CBRS policy with the cross-check contract. The adapter is needed because the constructor and method names in `policies.py` are not known here; change the three marked lines to match your code:

```python
# my_adapter.py  -- adapt the marked lines to bai1_protocol/replay/policies.py
import sys; sys.path.insert(0, "/path/to/project")            # <-- 1. project root
from bai1_protocol.replay import policies

def init(m, columns, label_col="y"):
    pol = policies.CBRS(memory_size=m, label_col=label_col)    # <-- 2. your constructor
    mem = __import__("pandas").DataFrame(columns=columns)
    mem.attrs["policy"] = pol
    return mem

def update(memory, new_rows, rng):
    pol = memory.attrs["policy"]
    out = pol.update(memory, new_rows, rng)                    # <-- 3. your update call
    out.attrs["policy"] = pol
    return out
```

If your policy already has the signature `update(memory, new_rows, rng) -> memory` and takes `m` as a keyword, skip the adapter and pass `policies.py:update`. The script then supplies `m=` on its own.

3. Run:

```bash
python cbrs_crosscheck.py --a cbrs.py:update:empty_memory --b my_adapter.py:update:init \
       --stream fig1 --m 1000 --seeds 200 --out crosscheck_fig1.json
python cbrs_crosscheck.py --a cbrs.py:update:empty_memory --b my_adapter.py:update:init \
       --stream interleaved --m 1000 --seeds 200 --out crosscheck_interleaved.json
python cbrs_crosscheck.py --a cbrs.py:update:empty_memory --b my_adapter.py:update:init \
       --stream interleaved-b --m 1000 --seeds 200 --out crosscheck_edge.json
# your own stream: --stream csv:path/to/stream.csv   (needs a 'y' column; 'sid' is added if absent)
```

How to read the verdict:

* **IDENTICAL**: every seed gives the same memory, slot by slot. This only happens if both implementations draw random numbers in the same order.
* **EQUIVALENT_IN_DISTRIBUTION**: the memories differ, but per-class counts and per-decile inclusion rates show no significant difference (Welch t-tests, Bonferroni, α = 0.001), and Property 1 holds for both. This is the expected result for a correct implementation that draws random numbers differently.
* **DIFFERENT**: the exit code is 1. `significant_differences` lists the class or position decile where the implementations disagree. Typical causes:
  * fullness tracked during the fill phase. The `interleaved-b` stream exposes this: class 1 drops from 108 to about 21.
  * n_c counted only after the fill phase.
  * replacement from a random class instead of the largest one.
  * reservoir probability m/n instead of m_c/n_c.

Demo results from this sandbox are in `crosscheck_demo/` and summarised in `cbrs_reproduction.md` §5.

## Re-running the reproduction

```bash
python cbrs_repro.py --runs 2000 --procs 4 --out cbrs_repro_results.json   # about 9 min on 2 cores
python cbrs_repro_extra.py --runs 2000                                      # about 4 min
```
