# CBRS specification (from the paper text)

**Source.** A. Chrysakis and M.-F. Moens, "Online Continual Learning from Imbalanced Data", *Proceedings of the 37th International Conference on Machine Learning (ICML 2020)*, PMLR 119:1952–1961. Landing page: https://proceedings.mlr.press/v119/chrysakis20a.html. PDF: https://proceedings.mlr.press/v119/chrysakis20a/chrysakis20a.pdf. Supplement: https://proceedings.mlr.press/v119/chrysakis20a/chrysakis20a-supp.pdf.

**How the text was obtained (limitations).** The sandbox could not download the PMLR PDF or the supplement: the proxy blocked them, and the fetch tool hit an http/https redirect loop. The quotes below come from a plain-text extraction of the same PMLR PDF hosted in the SDSC "ml-papers-txt" mirror (`.../ml-papers-txt/ICML/2020/online_continual_learning_from_imbalanced_data__20b13d7e.txt`). The fetch tool returned them as short exact fragments.

The extraction drops mathematical symbols. The arrow `←` after `mc` and `nc`, the `∼` in "u ∼ Uniform", the `≤` in "u ≤ mc/nc", subscripts and superscripts are missing from the raw text. Where a symbol is restored here, it appears in [square brackets]. Before citing, check every quote against the PDF.

The **supplement, which holds the proofs of both properties, could not be read**. The property statements below come from the main text.

**Official code.** None was found. The PMLR page has no code link (its only GitHub link points to the proceedings repo `mlresearch/v119`). The paper says nothing about code availability; it only says the datasets are "freely available online". Papers with Code lists "no code implementations" for the paper and for the author. ML Anthology has no code link. Direct GitHub search was not possible: the sandbox's GitHub API is restricted to configured repositories. Web searches for "class-balancing reservoir sampling" GitHub returned no implementation by the authors.

## 1. Algorithm 1, as printed (raw extraction, one fragment per line)

```
Algorithm 1 Class-Balancing Reservoir Sampling
1: input: stream: {(xi, yi)}n                               [ {(x_i, y_i)}_{i=1}^{n} ]
2: for i = 1 to n do
3: if memory is not filled then
4: store (xi, yi)
5: else
6: if c yi is not a full class then                         [ c ≡ y_i ]
7: find all instances of the largest class
8: select from them an instance at random
9: overwrite the selected instance with (xi, yi)
10: else
11: mc number of currently stored instances of class c yi   [ m_c ← ... ; c ≡ y_i ]
12: nc number of stream instances of class c yi encountered thus far   [ n_c ← ... ]
13: sample u Uniform(0, 1)                                    [ u ∼ Uniform(0,1) ]
14: if u mc/nc then                                           [ u ≤ m_c/n_c ]
15: pick a stored instance of class c yi at random
16: replace it with (xi, yi)
17: else
18: ignore the instance (xi, yi)
19: end if
20: end if
21: end if
22: end for
```

## 2. Definitions and rules (Section 2.2, verbatim fragments)

| Item | Verbatim text |
|---|---|
| Largest class | "When a certain class contains the most instances among all the different classes" / "present in the memory, we will call it the largest." |
| Ties | "Two or more classes can be the largest, if they are equal in size and also the most numerous." |
| Full class | "Finally, we will call a class full if it currently is, or has been in one of the previous" / "time steps, the largest class." |
| Persistence | "Once a class becomes full, it remains so in the future." / "Such classes are called full, because CBRS does not allow them to grow in size." |
| Before the memory is full | "as long as the memory is not filled, all the incoming stream instances are getting stored in memory" ; "After the memory is filled, we move on to the second stage." |
| Non-full class, memory full | "If it does not, the received instance is stored in the place of another instance that belongs to the largest class." (Alg. 1, l. 7–9: "find all instances of the largest class" / "select from them an instance at random" / "overwrite the selected instance with (xi, yi)") |
| Full class, memory full | "replaces a randomly selected stored instance of the same class c with probability mc/nc" [m_c/n_c] |
| Counters | m_c: "number of currently stored instances of class c" ; n_c: "the number of stream instances of class c that we have encountered so far" (Alg. 1 l. 12: "encountered thus far") |
| Random choices | (i) l. 8, one instance chosen at random from all instances of the largest class; (ii) l. 13, u ∼ Uniform(0,1); (iii) l. 15, one stored instance of class c chosen at random. |
| Processing granularity | "the learner goes over the data instances contained in the currently observed batch" / "one at a time, and decides which ones to store." (batch size b = 10) |

## 3. Stated properties (Section 2.2; proofs are in the supplement)

> "Assuming a stream that contains instances of nc distinct classes, and a memory of size m, the following two statements stand."

The symbol n_c is overloaded here. In this sentence it means the number of distinct classes. In Algorithm 1 it is a per-class stream counter.

* **Property 1.** "First, if the stream contains a class with less than m/nc instances, then all of these" / "instances will be stored in memory after the stream has been read in whole."
* **Property 2.** "Second, the subset of the instances from each class that are stored in memory is iid with" / "respect to the instances of the same class contained in the stream."
* "We prove both statements in the supplementary material."

Figure 1 (memory m = 1000, first five MNIST classes, imbalanced stream): "CBRS (iv) does not discard any instances from the significantly underrepresented classes 0 and 2" / "and balances the remaining three." Text: "the two classes of the stream that are composed by less than 200 instances (i.e., classes 0 and 2) are stored in their entirety by CBRS"; "the smallest class of the stream contains 51 instances"; "CBRS would keep the memory perfectly balanced if its size was m = 255". No per-class memory counts are printed, and the figure's bars could not be read from the text extraction.

Experimental imbalance (Sec. 3.1): "For each class, we define its retention factor as the percentage of its instances in the original dataset" / "that will be present in the stream." r = (10^-2, 10^-1.5, 10^-1, 10^-0.5, 10^0). "We distribute the retention factors to each class at random and without replacement," / "starting over if the number of classes in the dataset is larger than k." The factors are re-drawn every run. Classes arrive one per task, in increasing class order. m = 500 for MNIST and Fashion-MNIST, and m = 1000 for CIFAR-10 and CIFAR-100.

## 4. Points the paper leaves open, and the choices made in `cbrs.py`

1. **When fullness is first evaluated.** The definition says "has been in one of the previous time steps, the largest class", without excluding the fill phase. If classes that were largest during the fill phase were also marked full, Property 1 would be false. Counter-example: a stream whose first instance belongs to a class with fewer than m/n_classes instances. That class is "largest" at step 2, so later instances of it are only kept with probability m_c/n_c < 1. The `S3b` test in `cbrs_reproduction.md` shows this: Property 1 passes in 0/2000 runs under that reading. **Choice: fullness is evaluated on the memory state at the start of each time step once the memory is filled.** This is the reading under which Property 1 holds. The other reading is available as `full_tracking="always"`, for cross-checks only.
2. **n_c includes the current instance and the fill phase** ("encountered thus far"). The acceptance probability m_c/n_c then equals the classic reservoir probability k/n, which is what Property 2 needs.
3. **Ties for "largest".** "Find all instances of the largest class" is read as the union of the instances of all tied largest classes, with one instance chosen uniformly from it. Picking a tied class uniformly and then an instance within it gives the same distribution, because tied classes have equal sizes.
4. **"Overwrite"** is implemented in place: memory slot order is kept.
5. **`u ≤ m_c/n_c`** (≤ versus < differs only on a probability-zero event). A full class with m_c = 0 ignores the instance.
6. "iid" in Property 2 is read as: the stored instances of a class form a **uniform random subset (without replacement)** of that class's stream instances, given their number.
