"""Second, deliberately different CBRS implementation (pandas-only, different random-number
consumption) used to demonstrate cbrs_crosscheck.py.  Not the reference; see cbrs.py.
State is kept in memory.attrs["alt"] = {"m", "n_seen", "full"}.
Differences from cbrs.py (distributionally irrelevant):
  * ties for "largest": first draw one tied class with rng.choice, then one of its rows;
  * a full-class replacement picks its victim with rng.choice over row labels."""
import numpy as np
import pandas as pd


def init(m, columns, label_col="y"):
    mem = pd.DataFrame(columns=columns)
    mem.attrs["alt"] = {"m": m, "n_seen": {}, "full": set(), "label_col": label_col}
    return mem


def update(memory, new_rows, rng):
    st = {k: (v.copy() if hasattr(v, "copy") else v) for k, v in memory.attrs["alt"].items()}
    lab, m = st["label_col"], st["m"]
    mem = memory.copy()
    for _, row in new_rows.iterrows():
        c = row[lab]
        st["n_seen"][c] = st["n_seen"].get(c, 0) + 1
        if len(mem) < m:
            mem = pd.concat([mem, row.to_frame().T], ignore_index=True)
            continue
        vc = mem[lab].value_counts()
        st["full"] |= set(vc.index[vc == vc.max()])
        if c not in st["full"]:
            big = sorted(vc.index[vc == vc.max()])
            cls = big[int(rng.choice(len(big)))]
            victims = np.flatnonzero((mem[lab] == cls).to_numpy())
            mem.iloc[int(rng.choice(victims))] = row.to_numpy()
        else:
            mine = np.flatnonzero((mem[lab] == c).to_numpy())
            if rng.random() <= len(mine) / st["n_seen"][c] and len(mine):
                mem.iloc[int(rng.choice(mine))] = row.to_numpy()
    mem = mem.astype(new_rows.dtypes.to_dict())
    mem.attrs = {"alt": st}
    return mem
