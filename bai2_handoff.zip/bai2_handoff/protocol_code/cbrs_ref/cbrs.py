"""Class-Balancing Reservoir Sampling (CBRS) -- independent reference implementation.

Paper: A. Chrysakis and M.-F. Moens, "Online Continual Learning from Imbalanced
Data", ICML 2020, PMLR 119:1952-1961, Algorithm 1.  No official code was found
(see cbrs_spec.md), so this file is written from the paper text alone.

Public interface
----------------
    memory = empty_memory(m, columns, label_col="y")
    memory = update(memory, new_rows, rng)          # rng: numpy.random.Generator

`memory` is a pandas DataFrame whose row i is memory slot i.  The algorithm state
that cannot be recovered from the stored rows (per-class stream counters n_c and
the set of "full" classes) travels in ``memory.attrs["cbrs_state"]``.  `update`
never mutates its inputs; it returns a new DataFrame.  Rows of `new_rows` are
processed one at a time, in order, exactly as in Algorithm 1 (a batch of b rows
is equivalent to b single-row calls).

Determinism contract (needed for exact cross-implementation comparison)
------------------------------------------------------------------------
Given the same stream and the same Generator state, the output is identical.
Random numbers are consumed only after the memory is filled, in this order:
  * class y is NOT full:  one ``rng.integers(0, L)`` where L is the number of
    stored instances that belong to the largest class(es); the candidates are
    the slots of all tied largest classes, sorted by slot index ascending.
  * class y IS full:      one ``rng.random()`` (u); if ``u <= m_c / n_c`` then one
    ``rng.integers(0, m_c)`` indexing the slots of class y sorted ascending.
Nothing is drawn during the fill phase.

Interpretation choices (paper is silent; see cbrs_spec.md section 3)
-------------------------------------------------------------------
  * n_c counts every stream instance of class c, including the fill phase and
    the current instance (so the acceptance probability is m_c / n_c with n_c>=1).
  * Fullness ("is, or has been, the largest class") is evaluated on the memory
    state at the start of every time step *after the memory is filled*
    (``full_tracking="after_fill"``, default).  The alternative
    ``full_tracking="always"`` also marks classes that were largest during the
    fill phase; it violates the paper's Property 1 and is provided only for
    cross-checking other implementations.
  * Ties for "largest": an instance is drawn uniformly from the union of all
    tied largest classes (equivalent in distribution to first picking one of the
    tied classes uniformly, because tied classes have equal size).
"""
from __future__ import annotations

import bisect
import copy
from dataclasses import dataclass, field
from typing import Any, Dict, Hashable, List, Optional, Sequence, Set

import numpy as np
import pandas as pd

STATE_KEY = "cbrs_state"
SKIP = -1


@dataclass
class CBRSCore:
    """Label-level CBRS state machine (no payload).  Used by the DataFrame API."""

    m: int
    full_tracking: str = "after_fill"
    labels: List[Hashable] = field(default_factory=list)          # slot -> class
    slots: Dict[Hashable, List[int]] = field(default_factory=dict)  # class -> sorted slots
    n_seen: Dict[Hashable, int] = field(default_factory=dict)      # class -> n_c
    full: Set[Hashable] = field(default_factory=set)
    t: int = 0                                                     # instances seen

    def __post_init__(self) -> None:
        if int(self.m) < 1:
            raise ValueError("memory size m must be >= 1")
        if self.full_tracking not in ("after_fill", "always"):
            raise ValueError("full_tracking must be 'after_fill' or 'always'")
        self.m = int(self.m)

    # -- helpers -----------------------------------------------------------
    def counts(self) -> Dict[Hashable, int]:
        return {c: len(s) for c, s in self.slots.items() if s}

    def _largest(self) -> List[Hashable]:
        cnt = self.counts()
        if not cnt:
            return []
        mx = max(cnt.values())
        return [c for c, v in cnt.items() if v == mx]

    def _mark_full(self) -> None:
        self.full.update(self._largest())

    def _move(self, slot: int, new_class: Hashable) -> None:
        old = self.labels[slot]
        lst = self.slots[old]
        del lst[bisect.bisect_left(lst, slot)]
        bisect.insort(self.slots.setdefault(new_class, []), slot)
        self.labels[slot] = new_class

    # -- Algorithm 1, one stream instance ----------------------------------
    def step(self, y: Hashable, rng: np.random.Generator) -> int:
        """Process one instance of class y.  Returns the slot it is written to,
        or SKIP (-1) if it is ignored.  A returned slot equal to the previous
        memory size means "append" (fill phase)."""
        self.t += 1
        self.n_seen[y] = self.n_seen.get(y, 0) + 1
        if self.full_tracking == "always":
            self._mark_full()
        size = len(self.labels)
        if size < self.m:                                   # lines 3-4
            self.labels.append(y)
            self.slots.setdefault(y, []).append(size)       # size is the max slot
            return size
        if self.full_tracking == "after_fill":
            self._mark_full()
        if y not in self.full:                              # lines 6-9
            largest = self._largest()
            if len(largest) == 1:
                cand = self.slots[largest[0]]
            else:
                cand = sorted(s for c in largest for s in self.slots[c])
            j = cand[int(rng.integers(0, len(cand)))]
            self._move(j, y)
            return j
        mc = len(self.slots.get(y, ()))                     # lines 11-18
        nc = self.n_seen[y]
        u = rng.random()
        if mc > 0 and u <= mc / nc:
            return self.slots[y][int(rng.integers(0, mc))]
        return SKIP


@dataclass
class ReservoirCore:
    """Plain reservoir sampling (Vitter's Algorithm R), same step() contract.
    Baseline only.  Draws one rng.integers(0, t) per post-fill instance."""

    m: int
    labels: List[Hashable] = field(default_factory=list)
    t: int = 0

    def counts(self) -> Dict[Hashable, int]:
        out: Dict[Hashable, int] = {}
        for c in self.labels:
            out[c] = out.get(c, 0) + 1
        return out

    def step(self, y: Hashable, rng: np.random.Generator) -> int:
        self.t += 1
        if len(self.labels) < self.m:
            self.labels.append(y)
            return len(self.labels) - 1
        j = int(rng.integers(0, self.t))
        if j < self.m:
            self.labels[j] = y
            return j
        return SKIP


# ---------------------------------------------------------------------------
# DataFrame API
# ---------------------------------------------------------------------------
def empty_memory(m: int, columns: Sequence[str], label_col: str = "y",
                 full_tracking: str = "after_fill", dtypes: Optional[Dict[str, Any]] = None,
                 policy: str = "cbrs") -> pd.DataFrame:
    """Create an empty memory of capacity m carrying CBRS (or reservoir) state."""
    if label_col not in columns:
        raise ValueError(f"label column {label_col!r} not in columns")
    mem = pd.DataFrame({c: pd.Series([], dtype=(dtypes or {}).get(c, "object")) for c in columns})
    core = CBRSCore(m, full_tracking) if policy == "cbrs" else ReservoirCore(m)
    mem.attrs[STATE_KEY] = {"core": core, "label_col": label_col}
    return mem


def _apply(memory: pd.DataFrame, new_rows: pd.DataFrame, rng: np.random.Generator,
           m: Optional[int], label_col: str, full_tracking: str, policy: str) -> pd.DataFrame:
    if not isinstance(rng, np.random.Generator):
        raise TypeError("rng must be a numpy.random.Generator")
    st = memory.attrs.get(STATE_KEY)
    if st is None:
        if m is None:
            raise ValueError("memory has no CBRS state; create it with empty_memory(m, ...) "
                             "or pass m=... together with an EMPTY memory")
        if len(memory):
            raise ValueError("cannot infer stream counters for a non-empty memory without state")
        st = {"core": CBRSCore(m, full_tracking) if policy == "cbrs" else ReservoirCore(m),
              "label_col": label_col}
    st = copy.deepcopy(st)
    core, lab = st["core"], st["label_col"]
    if lab not in new_rows.columns:
        raise KeyError(f"new_rows lacks label column {lab!r}")
    if len(memory) != len(core.labels):
        raise ValueError("memory rows and CBRS state are out of sync")
    n_mem = len(memory)
    src = list(range(n_mem))           # slot -> row position in concat([memory, new_rows])
    for k, y in enumerate(new_rows[lab].tolist()):
        j = core.step(y, rng)
        if j == SKIP:
            continue
        if j == len(src):
            src.append(n_mem + k)
        else:
            src[j] = n_mem + k
    if len(memory) == 0:
        both = new_rows.reset_index(drop=True)
    else:
        both = pd.concat([memory, new_rows[memory.columns]], ignore_index=True)
    out = both.iloc[src].reset_index(drop=True)
    out.attrs = {STATE_KEY: st}
    return out


def update(memory: pd.DataFrame, new_rows: pd.DataFrame, rng: np.random.Generator,
           m: Optional[int] = None, label_col: str = "y",
           full_tracking: str = "after_fill") -> pd.DataFrame:
    """CBRS memory update.  Returns a new memory DataFrame (slot order preserved)."""
    return _apply(memory, new_rows, rng, m, label_col, full_tracking, "cbrs")


def reservoir_update(memory: pd.DataFrame, new_rows: pd.DataFrame, rng: np.random.Generator,
                     m: Optional[int] = None, label_col: str = "y") -> pd.DataFrame:
    """Plain reservoir sampling with the same interface (baseline)."""
    return _apply(memory, new_rows, rng, m, label_col, "after_fill", "reservoir")


def empty_reservoir_memory(m: int, columns: Sequence[str], label_col: str = "y") -> pd.DataFrame:
    return empty_memory(m, columns, label_col, policy="reservoir")


def cbrs_always_update(memory, new_rows, rng, m=None, label_col="y"):
    """Variant that also tracks fullness during the fill phase (NOT the paper's
    intent -- violates Property 1).  For cross-check demonstrations only."""
    return _apply(memory, new_rows, rng, m, label_col, "always", "cbrs")


def empty_memory_always(m: int, columns: Sequence[str], label_col: str = "y") -> pd.DataFrame:
    return empty_memory(m, columns, label_col, full_tracking="always")


def full_classes(memory: pd.DataFrame) -> Set[Hashable]:
    return set(memory.attrs[STATE_KEY]["core"].full)


def stream_counts(memory: pd.DataFrame) -> Dict[Hashable, int]:
    return dict(memory.attrs[STATE_KEY]["core"].n_seen)
