"""Monte Carlo reproduction check of CBRS properties (Chrysakis & Moens, ICML 2020).

Usage:  python cbrs_repro.py [--runs 2000] [--out cbrs_repro_results.json] [--procs 2]

No external data.  Streams are synthetic, built from class sizes x retention factors
r = (10^-2, 10^-1.5, 10^-1, 10^-0.5, 10^0) as in the paper (Sec. 3.1).
"""
from __future__ import annotations

import argparse
import json
import time
from multiprocessing import Pool

import numpy as np
import pandas as pd

import cbrs

R_FACTORS = np.array([10 ** -2, 10 ** -1.5, 10 ** -1, 10 ** -0.5, 10 ** 0])
MNIST_TRAIN = [5923, 6742, 5958, 6131, 5842, 5421, 5918, 6265, 5851, 5949]
Z99 = 2.5758


# ---------------------------------------------------------------- streams
def seq_stream(sizes):
    return np.concatenate([np.full(int(k), c) for c, k in enumerate(sizes)]).astype(np.int64)


def fig1_stream():
    # Fig.1 setting: MNIST classes 0-4, m = 1000, smallest class has 51 instances,
    # classes 0 and 2 have < 200 instances.  Per-class factors for 1,3,4 are not
    # given in the paper; we assume 1->10^-1, 3->10^-0.5, 4->10^0 and scale MNIST
    # train counts by 51/59.23 so that class 0 has exactly 51 instances.
    s = 51 / (MNIST_TRAIN[0] * 0.01)
    fac = [10 ** -2, 10 ** -1, 10 ** -1.5, 10 ** -0.5, 10 ** 0]
    sizes = [int(round(MNIST_TRAIN[c] * s * fac[c])) for c in range(5)]
    sizes[0] = 51
    return sizes, seq_stream(sizes)


def interleaved_stream(n_total=5000, seed=12345):
    p = R_FACTORS / R_FACTORS.sum()
    sizes = np.floor(p * n_total).astype(int)
    y = seq_stream(sizes)
    np.random.default_rng(seed).shuffle(y)
    return sizes.tolist(), y


def paper_protocol_sizes(base, rng):
    k = len(R_FACTORS)
    fac = []
    while len(fac) < len(base):           # "starting over if #classes > k"
        fac.extend(rng.permutation(R_FACTORS).tolist())
    fac = np.array(fac[:len(base)])
    return np.maximum(1, np.round(np.array(base) * fac)).astype(int), fac


# ---------------------------------------------------------------- running
def run_core(y, m, seed, policy="cbrs", full_tracking="after_fill"):
    rng = np.random.default_rng(seed)
    core = cbrs.CBRSCore(m, full_tracking) if policy == "cbrs" else cbrs.ReservoirCore(m)
    src = []
    step = core.step
    for i, c in enumerate(y.tolist()):
        j = step(c, rng)
        if j < 0:
            continue
        if j == len(src):
            src.append(i)
        else:
            src[j] = i
    full = sorted(core.full) if policy == "cbrs" else []
    return np.array(src, dtype=np.int64), full


def water_level(sizes, m):
    """Balanced allocation: min(n_c, L) with sum = m (classes below L kept whole)."""
    sizes = np.asarray(sizes)
    if sizes.sum() <= m:
        return sizes.copy()
    lo, hi = 0, int(sizes.max())
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if np.minimum(sizes, mid).sum() <= m:
            lo = mid
        else:
            hi = mid - 1
    alloc = np.minimum(sizes, lo)
    return alloc  # remainder (m - sum) is spread +1 over some capped classes


def _job(args):
    name, y, m, seed, policy, ft = args
    src, full = run_core(y, m, seed, policy, ft)
    return seed, src, full


def monte_carlo(y, m, runs, procs, policy="cbrs", ft="after_fill", seed0=0):
    jobs = [("x", y, m, seed0 + r, policy, ft) for r in range(runs)]
    with Pool(procs) as pool:
        res = pool.map(_job, jobs, chunksize=max(1, runs // (8 * procs)))
    res.sort(key=lambda t: t[0])
    return [r[1] for r in res], [r[2] for r in res]


# ---------------------------------------------------------------- statistics
def mean_ci(x, z=1.96):
    x = np.asarray(x, float)
    mu = x.mean()
    se = x.std(ddof=1) / np.sqrt(len(x)) if len(x) > 1 else 0.0
    return float(mu), float(mu - z * se), float(mu + z * se)


def hotelling_zero_mean(Z):
    """One-sample Hotelling T^2 test of E[Z]=0 (rows = runs).  Returns (T2, F, p)."""
    from scipy import stats
    Z = np.asarray(Z, float)
    n, p = Z.shape
    mu = Z.mean(0)
    S = np.cov(Z, rowvar=False)
    T2 = float(n * mu @ np.linalg.pinv(S) @ mu)
    F = (n - p) / (p * (n - 1)) * T2
    return T2, float(F), float(stats.f.sf(F, p, n - p))


def within_class_uniformity(y, srcs, cls, nbins=10):
    """Property 2 tests for one class.
    For each run: X_d = fraction of the class's stream instances in position-decile d
    that are stored.  H0 (uniform subset): E[X_d] equal for all d.  Test with
    Hotelling T^2 on deviations from the run mean (9 dims), plus per-decile 99% CIs,
    a per-position chi-square (valid when m_c is fixed across runs) and an
    adjacent-pair joint-inclusion test (second-order check)."""
    from scipy import stats
    pos = np.flatnonzero(y == cls)              # stream indices of this class, in order
    n = len(pos)
    rank = np.full(len(y), -1)
    rank[pos] = np.arange(n)
    bins = np.minimum((np.arange(n) * nbins) // n, nbins - 1)
    bin_size = np.bincount(bins, minlength=nbins)
    X, mcs, adj_obs, adj_exp = [], [], [], []
    incl = np.zeros(n)
    for src in srcs:
        r = rank[src]
        r = r[r >= 0]
        mc = len(r)
        mcs.append(mc)
        incl[r] += 1
        X.append(np.bincount(bins[r], minlength=nbins) / bin_size)
        stored = np.zeros(n, bool)
        stored[r] = True
        adj_obs.append(np.sum(stored[:-1] & stored[1:]))
        adj_exp.append(mc * (mc - 1) / n if n > 1 else 0.0)
    X = np.array(X)
    mcs = np.array(mcs)
    R = len(srcs)
    Z = X[:, :-1] - X.mean(1, keepdims=True)
    T2, F, p_h = hotelling_zero_mean(Z)
    dec = []
    for d in range(nbins):
        mu, lo, hi = mean_ci(X[:, d], Z99)
        dec.append({"decile": d, "rate": mu, "ci99": [lo, hi]})
    expected_rate = float(np.mean(mcs / n))
    dec_ok = all(r["ci99"][0] <= expected_rate <= r["ci99"][1] for r in dec)
    out = {"class": int(cls), "n_c": int(n), "m_c_mean": float(mcs.mean()),
           "m_c_min": int(mcs.min()), "m_c_max": int(mcs.max()),
           "expected_inclusion": expected_rate, "deciles": dec,
           "deciles_all_cover_expected_99": bool(dec_ok),
           "hotelling_T2": T2, "hotelling_p": p_h}
    if mcs.min() == mcs.max() and 0 < mcs[0] < n:
        p = mcs[0] / n
        E = R * p
        chi = float(((incl - E) ** 2).sum() / (R * p * (1 - p)) * (n - 1) / n)
        out["position_chi2"] = chi
        out["position_chi2_df"] = n - 1
        out["position_chi2_p"] = float(stats.chi2.sf(chi, n - 1))
        lo_p, hi_p = stats.binom.ppf([0.005, 0.995], R, p)
        out["positions_outside_99pct_band"] = float(np.mean((incl < lo_p) | (incl > hi_p)))
    d = np.array(adj_obs) - np.array(adj_exp)
    mu, lo, hi = mean_ci(d, Z99)
    out["adjacent_pairs_obs_minus_exp"] = {"mean": mu, "ci99": [lo, hi],
                                           "expected_mean": float(np.mean(adj_exp))}
    out["adjacent_pairs_ok"] = bool(lo <= 0 <= hi)
    out["pass"] = bool(p_h > 0.001 and dec_ok and out["adjacent_pairs_ok"]
                       and out.get("position_chi2_p", 1.0) > 0.001)
    return out


def class_summary(y, srcs, fulls, m, K=None):
    sizes = np.bincount(y)
    K = K or int((sizes > 0).sum())
    thr = m / K
    small = [c for c in range(len(sizes)) if 0 < sizes[c] < thr]
    counts = np.array([np.bincount(y[s], minlength=len(sizes)) for s in srcs])
    p1_ok = np.array([all(cnt[c] == sizes[c] for c in small) for cnt in counts])
    d1_ok = []
    bal = []
    for cnt, full in zip(counts, fulls):
        if full is None:
            continue
        nonfull = [c for c in range(len(sizes)) if sizes[c] > 0 and c not in full]
        d1_ok.append(all(cnt[c] == sizes[c] for c in nonfull))
        fc = [cnt[c] for c in full]
        bal.append((max(fc) - min(fc)) if fc else 0)
    return {
        "stream_sizes": sizes.tolist(), "m": m, "threshold_m_over_nc": thr,
        "classes_below_threshold": small,
        "mean_counts": counts.mean(0).round(3).tolist(),
        "min_counts": counts.min(0).tolist(), "max_counts": counts.max(0).tolist(),
        "memory_size_always_m": bool(all(len(s) == min(m, len(y)) for s in srcs)),
        "P1_pass_rate": float(p1_ok.mean()),
        "D1_nonfull_classes_complete_rate": float(np.mean(d1_ok)) if d1_ok else None,
        "full_class_spread_max": int(max(bal)) if bal else None,
        "full_class_spread_le1_rate": float(np.mean(np.array(bal) <= 1)) if bal else None,
        "water_level_allocation": water_level(sizes, m).tolist(),
    }


# ---------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", type=int, default=2000)
    ap.add_argument("--procs", type=int, default=2)
    ap.add_argument("--out", default="cbrs_repro_results.json")
    a = ap.parse_args()
    R, P = a.runs, a.procs
    res = {"runs": R, "numpy": np.__version__, "pandas": pd.__version__}
    t0 = time.time()

    # 0. DataFrame API == core (exact, same seeds)
    sizes, y = fig1_stream()
    eq = []
    for seed in range(5):
        df = pd.DataFrame({"sid": np.arange(len(y)), "y": y})
        mem = cbrs.empty_memory(1000, ["sid", "y"])
        rng = np.random.default_rng(seed)
        for s in range(0, len(df), 10):
            mem = cbrs.update(mem, df.iloc[s:s + 10], rng)
        src, _ = run_core(y, 1000, seed)
        eq.append(bool(np.array_equal(mem["sid"].to_numpy(), src)))
    res["api_equals_core"] = all(eq)

    # S1. Figure-1-like setting
    srcs, fulls = monte_carlo(y, 1000, R, P)
    s1 = class_summary(y, srcs, fulls, 1000)
    s1["uniformity"] = [within_class_uniformity(y, srcs, c) for c in range(5) if s1["max_counts"][c] < sizes[c]]
    rs, _ = monte_carlo(y, 1000, R, P, policy="reservoir")
    s1["reservoir_mean_counts"] = class_summary(y, rs, [None] * R, 1000)["mean_counts"]
    s1["reservoir_expected"] = (1000 * np.array(sizes) / sum(sizes)).round(2).tolist()
    s1["reservoir_uniformity"] = [within_class_uniformity(y, rs, c)["pass"] for c in range(5)]
    res["S1_fig1"] = s1
    print("S1 done", time.time() - t0, flush=True)

    # S3. Interleaved imbalanced stream (random-order arrival), fixed order across runs
    sizes3, y3 = interleaved_stream()
    srcs3, fulls3 = monte_carlo(y3, 1000, R, P)
    s3 = class_summary(y3, srcs3, fulls3, 1000)
    s3["uniformity"] = [within_class_uniformity(y3, srcs3, c) for c in range(5) if s3["max_counts"][c] < sizes3[c]]
    a_srcs, a_fulls = monte_carlo(y3, 1000, R, P, ft="always")
    s3["variant_always"] = class_summary(y3, a_srcs, a_fulls, 1000)
    # S3b: same stream but the first arrival is a class-1 instance (108 < m/nc = 200).
    y3b = y3.copy()
    k = int(np.flatnonzero(y3b == 1)[0])
    y3b[0], y3b[k] = y3b[k], y3b[0]
    b_srcs, b_fulls = monte_carlo(y3b, 1000, R, P)
    s3["S3b_first_is_class1_after_fill"] = class_summary(y3b, b_srcs, b_fulls, 1000)
    bb_srcs, bb_fulls = monte_carlo(y3b, 1000, R, P, ft="always")
    s3["S3b_first_is_class1_variant_always"] = class_summary(y3b, bb_srcs, bb_fulls, 1000)
    rs3, _ = monte_carlo(y3, 1000, R, P, policy="reservoir")
    s3["reservoir"] = class_summary(y3, rs3, [None] * R, 1000)
    res["S3_interleaved"] = s3
    print("S3 done", time.time() - t0, flush=True)

    # S2. Paper protocol: retention factors re-drawn every run, sequential classes.
    for name, base, m in [("S2a_mnist10_m500", MNIST_TRAIN, 500),
                          ("S2b_cifar10_m1000", [5000] * 10, 1000)]:
        ys, facs = [], []
        g = np.random.default_rng(2020)
        for r in range(R):
            sz, fac = paper_protocol_sizes(base, g)
            ys.append(seq_stream(sz))
            facs.append(fac)
        jobs = [("x", ys[r], m, r, "cbrs", "after_fill") for r in range(R)]
        with Pool(P) as pool:
            out = pool.map(_job, jobs, chunksize=max(1, R // (8 * P)))
        p1 = d1 = 0
        spread = []
        by_factor = {f: [] for f in R_FACTORS.round(5).tolist()}
        dev_from_wl = []
        for (seed, src, full), yy, fac in zip(out, ys, facs):
            cs = class_summary(yy, [src], [full], m)
            p1 += cs["P1_pass_rate"]
            d1 += cs["D1_nonfull_classes_complete_rate"]
            spread.append(cs["full_class_spread_max"])
            cnt = np.bincount(yy[src], minlength=len(base))
            for c, f in enumerate(fac):
                by_factor[round(float(f), 5)].append(int(cnt[c]))
            wl = water_level(np.bincount(yy, minlength=len(base)), m)
            dev_from_wl.append(int(np.max(np.abs(cnt - wl))))
        res[name] = {"m": m, "P1_pass_rate": p1 / R, "D1_nonfull_classes_complete_rate": d1 / R,
                     "full_class_spread_le1_rate": float(np.mean(np.array(spread) <= 1)),
                     "full_class_spread_max": int(max(spread)),
                     "max_abs_dev_from_water_level_max": int(max(dev_from_wl)),
                     "mean_count_by_retention_factor": {str(k): float(np.mean(v)) for k, v in by_factor.items()}}
        print(name, "done", time.time() - t0, flush=True)

    # S4. Randomised property test: random K, sizes, orders (mixed sequential/interleaved/bursty), m
    g = np.random.default_rng(7)
    jobs, meta = [], []
    for r in range(R):
        K = int(g.integers(2, 11))
        sizes4 = np.maximum(1, np.round(g.lognormal(4, 1.5, K))).astype(int)
        y4 = seq_stream(sizes4)
        mode = r % 3
        if mode == 1:
            g.shuffle(y4)
        elif mode == 2:                       # bursty: shuffle blocks of 25
            blocks = [y4[i:i + 25] for i in range(0, len(y4), 25)]
            g.shuffle(blocks)
            y4 = np.concatenate(blocks)
        m4 = int(g.integers(5, max(6, len(y4))))
        jobs.append(("x", y4, m4, 10_000 + r, "cbrs", "after_fill"))
        meta.append((y4, m4))
    with Pool(P) as pool:
        out = pool.map(_job, jobs, chunksize=max(1, R // (8 * P)))
        out_alw = pool.map(_job, [j[:5] + ("always",) for j in jobs], chunksize=max(1, R // (8 * P)))
    res["S4_variant_always_P1_pass_rate"] = float(np.mean(
        [class_summary(y4, [src], [full], m4)["P1_pass_rate"] for (_, src, full), (y4, m4) in zip(out_alw, meta)]))
    p1 = d1 = 0
    sz_ok = 0
    for (seed, src, full), (y4, m4) in zip(out, meta):
        cs = class_summary(y4, [src], [full], m4)
        p1 += cs["P1_pass_rate"]
        d1 += cs["D1_nonfull_classes_complete_rate"]
        sz_ok += cs["memory_size_always_m"]
    res["S4_random_streams"] = {"cases": R, "P1_pass_rate": p1 / R,
                                "D1_nonfull_classes_complete_rate": d1 / R,
                                "memory_size_ok_rate": sz_ok / R}
    res["elapsed_s"] = round(time.time() - t0, 1)
    with open(a.out, "w") as f:
        json.dump(res, f, indent=1)
    print(json.dumps({k: (v if not isinstance(v, dict) else "...") for k, v in res.items()}))


if __name__ == "__main__":
    main()
