"""Bài 1 — locked analysis of H1 (prereg_bai1.md, sections 5–6). Run ONCE (main_colab.py analyze):

    python analysis_h1.py results_h1.jsonl out_h1.json

Input (one JSON object per evaluated day; main_colab.py results):
  dataset, root_day, kind, scenario_id, policy, seed, day, primary, status (ok | not_evaluable | tech_fail), reason,
  auprc_w_tfm, auprc_w_lgbm (LightGBM also on tech_fail days), tfm_gpu_seconds, lgbm_cpu_seconds

H1a (policy FIFO). d = AUPRC_w(TabFM) - AUPRC_w(LightGBM) per ok day; chain = mean over its ok days; root day = mean
over its chains. Decision on the 16 root-day outcomes x (H0: theta <= EPS1):
  * exact one-sided Wilcoxon signed-rank test of x - EPS1 (equivalently: Hodges-Lehmann exact one-sided 95% lower
    bound >= EPS1);
  * dependence check: moving-block bootstrap (blocks of BLOCK consecutive root days within each dataset) one-sided 95%
    lower bound of the HL estimate;
  * symmetry check: exact sign test of x - EPS1 (no symmetry assumption).
  Verdict: CONFIRMED if the exact lower bound >= EPS1 AND the block-bootstrap lower bound >= EPS1;
           SUPPORTED_DEPENDENCE_SENSITIVE if only the exact bound is >= EPS1;
           SUPERIOR_BELOW_EPS1 if the Wilcoxon test against 0 rejects (alpha 0.05) but the exact bound < EPS1;
           NOT_ESTABLISHED otherwise;
           NO_CONFIRMATORY_CLAIM if technical failures exceed TECH_FAIL_MAX_SHARE of the primary evaluable days.
  The sign-test result and the lag-1 autocorrelation of root-day outcomes are reported with the verdict.
Missing data (technical failures, prereg 6.3): primary = available ok days; sensitivity S1 worst case for TabFM
(AUPRC_w(TabFM) = 0 on failed days), S2 complete chains only, S3 root days without any failure only.
H1b: confirmatory only if LAMBDA_VND and both unit prices are set below before the lock; otherwise descriptive.
"""
import json
import sys
from itertools import combinations_with_replacement

import numpy as np
from scipy import stats

EPS1 = 0.02
ALPHA = 0.05
PRIMARY_POLICY = "FIFO"
BLOCK = 3
N_BOOT = 10_000
BOOT_SEED = 20261028
TECH_FAIL_MAX_SHARE = 0.05
# H1b (fill BEFORE the lock, or leave None: H1b is then descriptive only)
LAMBDA_VND = None            # VND per +0.01 AUPRC_w
PRICE_GPU_HOUR_VND = None
PRICE_CPU_HOUR_VND = None


def signed_rank_null(n):
    dist = np.zeros(n * (n + 1) // 2 + 1)
    dist[0] = 1
    for r in range(1, n + 1):
        new = dist.copy()
        new[r:] += dist[:-r]
        dist = new
    return dist / dist.sum()


def hodges_lehmann(x, alpha_one_sided=0.05):
    """HL estimate, exact one-sided (1-alpha) lower bound and matching upper bound (inversion of the signed-rank
    test)."""
    x = np.asarray(x, float)
    walsh = np.sort([(a + b) / 2 for a, b in combinations_with_replacement(x, 2)])
    cdf = np.cumsum(signed_rank_null(len(x)))
    c = int(np.searchsorted(cdf, alpha_one_sided, side="right"))
    return float(np.median(walsh)), float(walsh[c]), float(walsh[len(walsh) - 1 - c])


def hl_point(x):
    x = np.asarray(x, float)
    i, j = np.triu_indices(len(x))
    return float(np.median((x[i] + x[j]) / 2))


def block_bootstrap_lower(series_by_ds, alpha=0.05):
    """Moving-block bootstrap within each dataset (time order kept), HL of the pooled resample; one-sided lower
    quantile."""
    rng = np.random.default_rng(BOOT_SEED)
    stats_ = np.empty(N_BOOT)
    for b in range(N_BOOT):
        pooled = []
        for s in series_by_ds:
            n, L = len(s), min(BLOCK, len(s))
            starts = rng.integers(0, n - L + 1, size=int(np.ceil(n / L)))
            pooled += list(np.concatenate([s[k:k + L] for k in starts])[:n])
        stats_[b] = hl_point(pooled)
    return float(np.quantile(stats_, alpha))


def load(path):
    with open(path, encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def day_d(r, mode):
    if r["status"] == "ok":
        return r["auprc_w_tfm"] - r["auprc_w_lgbm"]
    if r["status"] == "tech_fail" and mode == "worst":
        return 0.0 - r["auprc_w_lgbm"]
    return None


def root_outcomes(recs, policy, mode="available"):
    """mode: available | worst | complete_chains | clean_roots."""
    chains, failed_chain, failed_root = {}, set(), set()
    for r in recs:
        if r["policy"] != policy or r["status"] == "not_evaluable":
            continue
        key = (r["dataset"], r["root_day"], r["kind"], r["scenario_id"], r["seed"])
        if r["status"] == "tech_fail":
            failed_chain.add(key)
            failed_root.add((r["dataset"], r["root_day"]))
        v = day_d(r, "worst" if mode == "worst" else "available")
        if v is not None:
            chains.setdefault(key, []).append(v)
    roots = {}
    for key, v in chains.items():
        if mode == "complete_chains" and key in failed_chain:
            continue
        if mode == "clean_roots" and (key[0], key[1]) in failed_root:
            continue
        roots.setdefault((key[0], key[1]), {}).setdefault(key[2], []).append(float(np.mean(v)))
    return {k: {"value": float(np.mean([np.mean(v) for v in kinds.values()])),
                "by_kind": {kk: float(np.mean(v)) for kk, v in kinds.items()}} for k, kinds in roots.items()}


def h1a_block(roots):
    keys = sorted(roots)
    x = np.array([roots[k]["value"] for k in keys])
    hl, lo, _ = hodges_lehmann(x, ALPHA)
    _, lo2, up2 = hodges_lehmann(x, ALPHA / 2)
    w_eps = stats.wilcoxon(x - EPS1, alternative="greater", method="exact")
    w_zero = stats.wilcoxon(x, alternative="greater", method="exact")
    nz = x - EPS1
    sign = stats.binomtest(int((nz > 0).sum()), int((nz != 0).sum()), 0.5, alternative="greater")
    series = [np.array([roots[k]["value"] for k in keys if k[0] == ds]) for ds in sorted({k[0] for k in keys})]
    boot_lo = block_bootstrap_lower(series, ALPHA)
    ac = [float(np.corrcoef(s[:-1], s[1:])[0, 1]) for s in series if len(s) >= 4]
    if lo >= EPS1 and boot_lo >= EPS1:
        verdict = "CONFIRMED"
    elif lo >= EPS1:
        verdict = "SUPPORTED_DEPENDENCE_SENSITIVE"
    elif w_zero.pvalue < ALPHA:
        verdict = "SUPERIOR_BELOW_EPS1"
    else:
        verdict = "NOT_ESTABLISHED"
    return {"n_root_days": len(x), "hodges_lehmann": hl, "exact_lower_bound_one_sided_95": lo,
            "ci95_two_sided": [lo2, up2], "wilcoxon_vs_eps1_p": float(w_eps.pvalue),
            "wilcoxon_vs_0_p": float(w_zero.pvalue), "block_bootstrap_lower_bound_95": boot_lo,
            "sign_test_vs_eps1_p": float(sign.pvalue), "lag1_autocorrelation_by_dataset": ac, "verdict": verdict}, x, keys


def mean_ci(x, groups=None):
    x = np.asarray(x, float)
    if groups is None:
        m, se, df = x.mean(), x.std(ddof=1) / np.sqrt(len(x)), len(x) - 1
    else:
        D = np.column_stack([np.asarray(groups) == g for g in sorted(set(groups))]).astype(float)
        beta, *_ = np.linalg.lstsq(D, x, rcond=None)
        resid = x - D @ beta
        df = len(x) - D.shape[1]
        cov = (resid @ resid / df) * np.linalg.inv(D.T @ D)
        wv = D.mean(0)
        m, se = float(wv @ beta), float(np.sqrt(wv @ cov @ wv))
    t = stats.t.ppf(0.975, df)
    return {"mean": float(m), "ci95": [float(m - t * se), float(m + t * se)], "df": int(df)}


def main(inp, outp):
    recs = load(inp)
    prim = [r for r in recs if r["policy"] == PRIMARY_POLICY and r["status"] != "not_evaluable"]
    n_fail = sum(r["status"] == "tech_fail" for r in prim)
    share = n_fail / len(prim) if prim else 0.0
    out = {"eps1": EPS1, "alpha_one_sided": ALPHA, "block_length": BLOCK, "n_boot": N_BOOT,
           "counts": {s: sum(r["status"] == s for r in recs) for s in ("ok", "not_evaluable", "tech_fail")},
           "not_evaluable_reasons": {}, "primary_tech_fail_share": share}
    for r in recs:
        if r["status"] == "not_evaluable":
            out["not_evaluable_reasons"][r["reason"]] = out["not_evaluable_reasons"].get(r["reason"], 0) + 1
    roots = root_outcomes(recs, PRIMARY_POLICY)
    res, x, keys = h1a_block(roots)
    if share > TECH_FAIL_MAX_SHARE:
        res["verdict"] = "NO_CONFIRMATORY_CLAIM"
    out["H1a"] = res
    out["H1a_missing_data_sensitivity"] = {}
    if n_fail:
        for mode in ("worst", "complete_chains", "clean_roots"):
            rm = root_outcomes(recs, PRIMARY_POLICY, mode)
            if len(rm) >= 6:
                out["H1a_missing_data_sensitivity"][mode] = h1a_block(rm)[0]
    ds = [k[0] for k in keys]
    med = np.median(x)
    mad = 1.4826 * np.median(np.abs(x - med))
    sec = {"mean_root_days": mean_ci(x), "mean_root_days_dataset_adjusted": mean_ci(x, ds),
           "per_dataset": {g: mean_ci(x[np.array(ds) == g]) for g in sorted(set(ds))},
           "per_root_day": {f"{k[0]}|{k[1]}": roots[k] for k in keys},
           "root_days_beyond_5_mad": {f"{k[0]}|{k[1]}": float(v) for k, v in zip(keys, x)
                                      if mad > 0 and abs(v - med) > 5 * mad},
           "per_kind": {}, "per_policy": {}}
    for kind in sorted({kk for k in keys for kk in roots[k]["by_kind"]}):
        vals = [roots[k]["by_kind"][kind] for k in keys if kind in roots[k]["by_kind"]]
        sec["per_kind"][kind] = mean_ci(vals) | {"n_root_days": len(vals)}
    for pol in sorted({r["policy"] for r in recs} - {PRIMARY_POLICY}):
        rp = root_outcomes(recs, pol)
        v = np.array([rp[k]["value"] for k in sorted(rp)])
        if len(v) >= 6:
            h, l2, u2 = hodges_lehmann(v, ALPHA / 2)
            sec["per_policy"][pol] = {"n_root_days": len(v), "hodges_lehmann": h, "ci95": [l2, u2]}
    out["secondary"] = sec
    ok = [r for r in recs if r["status"] == "ok"]
    gpu = float(np.median([r["tfm_gpu_seconds"] for r in ok]))
    cpu = float(np.median([r["lgbm_cpu_seconds"] for r in ok]))
    h1b = {"tfm_gpu_seconds_per_day_median": gpu, "lgbm_cpu_seconds_per_day_median": cpu,
           "extra_seconds_per_0.01_auprc": (gpu - cpu) / (res["hodges_lehmann"] / 0.01)
           if res["hodges_lehmann"] > 0 else None}
    if None in (LAMBDA_VND, PRICE_GPU_HOUR_VND, PRICE_CPU_HOUR_VND):
        h1b["status"] = "descriptive only (lambda or unit prices not locked)"
    elif res["verdict"] not in ("CONFIRMED", "SUPPORTED_DEPENDENCE_SENSITIVE"):
        h1b["status"] = "not tested (fixed sequence: H1a not supported)"
    else:
        icer = (gpu / 3600 * PRICE_GPU_HOUR_VND - cpu / 3600 * PRICE_CPU_HOUR_VND) / (res["hodges_lehmann"] / 0.01)
        h1b |= {"status": "tested", "vnd_per_0.01_auprc_per_day": icer, "lambda_vnd": LAMBDA_VND,
                "supported": bool(icer <= LAMBDA_VND)}
    out["H1b"] = h1b
    with open(outp, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=1)
    print(json.dumps(out["H1a"], indent=1))


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("usage: python analysis_h1.py results_h1.jsonl out_h1.json")
    main(sys.argv[1], sys.argv[2])
