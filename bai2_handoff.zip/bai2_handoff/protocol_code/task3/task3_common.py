"""Task 3 shared settings (Step C and the blinded variance pilot). Written before any Task 3 output exists.

Run from anywhere: paths are resolved from this file. Development data only (NF-ToN-IoT-v3, NF-CICIDS2018-v3).
The environment variable BAI1_CACHE_DIR overrides the cache folder (used only by the synthetic test).
"""
import hashlib
import json
import os
import sys
from pathlib import Path

TASK3 = Path(__file__).resolve().parent
PROTO = TASK3.parent
REPLAY = PROTO / "replay"
for p in (str(REPLAY), str(PROTO)):
    if p not in sys.path:
        sys.path.insert(0, p)

import data as _data  # noqa: E402

CACHE_DIR = Path(os.environ.get("BAI1_CACHE_DIR", str(_data.CACHE_DIR)))

# ---- replay settings shared by Step C and the pilot (fixed before any run)
B = 2000            # labels per day
ETA = 0.2           # share of b reserved for D_cal (must equal drift_generator_v2.ETA)
K = 2000            # context / buffer size
LABEL_DELAY = 0     # tau (label delay, days) for Step C and the pilot
A_FP = 1000         # false alarms per day (threshold metrics are secondary; not used for selection)
N_EVAL = 10_000     # evaluation sample per day
SEEDS = (42, 123)   # first two seeds of the Study 1/2 seed list

# ---- Step C (CPU, local)
TUNE_DATASET = "NF-ToN-IoT-v3"
TUNE_DAYS = ("2019-04-23", "2019-04-24", "2019-04-25", "2019-04-26")   # design days; the first is warm-up
N_LGBM_CONFIGS = 50          # config 0 = provisional Study 1/2 setup, 1..49 = seeded random search
LGBM_SEARCH_SEED = 20261027
CURE_TAU_GRID = (0.1, 0.2, 0.3, 0.4, 0.5)   # 5 of the 12 configurations allowed per policy

# ---- blinded variance pilot (scenarios of the v2 manifest; FIFO only; kind 'feature')
PILOT_KIND = "feature"
PILOT_POLICY = "FIFO"
EXTRA_SCENARIO_ROOTS = {"NF-ToN-IoT-v3": ("2019-04-23", "2019-04-24"),
                        "NF-CICIDS2018-v3": ("2018-02-14", "2018-02-15")}   # first two root days per dataset
EXTRA_SCENARIO_IDX = (1, 2)   # every root day gets scenario 0; these 4 root days also get 1 and 2


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 22), b""):
            h.update(block)
    return h.hexdigest()


def load_manifest():
    return json.loads((PROTO / "scenario_manifest.json").read_text(encoding="utf-8"))


def pilot_units(manifest):
    """Pilot units (scenario, seed) chosen by a fixed rule from the manifest: every root day x scenario 0 of kind
    'feature' x SEEDS, plus scenarios 1 and 2 on the first two root days of each dataset."""
    units = []
    for ds, info in sorted(manifest["datasets"].items()):
        for root in info["root_days"]:
            idxs = (0,) + (EXTRA_SCENARIO_IDX if root in EXTRA_SCENARIO_ROOTS.get(ds, ()) else ())
            for idx in idxs:
                sid = f"{ds}|{root}|{PILOT_KIND}|{idx}"
                scn = next((s for s in manifest["scenarios"] if s["id"] == sid), None)
                if scn is None:
                    raise ValueError(f"pilot scenario {sid} is not in the manifest")
                for seed in SEEDS:
                    units.append({"unit": f"{ds}__{root}__{PILOT_KIND}{idx}__s{seed}", "dataset": ds,
                                  "root_day": root, "scenario_id": sid, "scenario_idx": idx, "seed": seed})
    return units


def lgbm_locked_path():
    return TASK3 / "lgbm_hparams_locked.json"
