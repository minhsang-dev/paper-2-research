# CURE and DualFIFO reference policies for the bai1 replay harness

These files are a reference implementation of CURE (Lee, Choi, Choi & Yoo, 2026, arXiv:2606.18677) and its DualFIFO baseline. The CURE code follows the official release https://github.com/morcellinus/CURE-ICML-FMSD at commit `f7c6b2f3c172ce3576f6c208a25c9655de2ea7e2`. It was checked step by step against the official `CUREMemoryPolicy` and matched at every step (0 mismatching steps). DualFIFO has no official code, so it follows the paper's App. B.1 text.

| File | Content |
|---|---|
| `cure_spec.md` | Verbatim quotes, defaults, DualFIFO definition, 18 ambiguities and the choices made, reproduction targets |
| `cure.py` | `CUREPolicy` plus shared helpers (`split_capacity`, `normalized_entropy`) |
| `dualfifo.py` | `DualFIFOPolicy` (imports helpers from `cure.py`) |
| `test_cure.py` | pytest suite on synthetic data (20 tests) |
| `SHA256SUMS` | Checksums of all files, including this README |

## Drop-in to `bai1_protocol/replay/`

1. Copy `cure.py` and `dualfifo.py` into `bai1_protocol/replay/`. `dualfifo.py` uses `from .cure import ...` inside a package and falls back to a flat `from cure import ...` otherwise.
2. Copy `test_cure.py` into your test folder. Then replace the two flat imports (`from cure import ...`, `from dualfifo import ...`) with `from bai1_protocol.replay.cure import ...` and `from bai1_protocol.replay.dualfifo import ...`. You can also run it in place with `python -m pytest test_cure.py`.
3. Use the policies through the harness interface:
   ```python
   from bai1_protocol.replay.cure import CUREPolicy
   from bai1_protocol.replay.dualfifo import DualFIFOPolicy

   pol = CUREPolicy(k=1000, short_ratio=0.75, tau=TAU, warmup_steps=100, seed=0)
   ctx = None
   for batch in stream:                                # DataFrame: features + 'y' + 'row_id'
       scorer = lambda X: tfm.fit(ctx_X, ctx_y).predict_proba(X)   # TFM conditioned on current ctx
       ctx = pol.update(ctx, batch, unlabelled_stream=None, scorer=scorer)
       assert len(ctx) <= pol.k
   ```

**Contract details**
- The returned context has three extra columns: `_bank` (`'S'` or `'L'`), `_h` (stored normalised entropy) and `_arrival` (arrival index). Pass it back unchanged on the next call. Drop these columns (`cure.META_COLS`) before fitting the TFM. Feature columns are all columns except `y`, `row_id` and `META_COLS`, unless you pass `feature_cols=[...]`.
- **Exact paper behaviour:** call `update` with one row at a time, and give each new row a column `_h` holding the normalised entropy from the prediction you scored (test-then-train). When `_h` is present, the scorer is not called. Without `_h`, CURE calls `scorer` once on the batch, using the context as it was before the batch (ambiguity 12 in the spec).
- During warm-up (arrival index < `warmup_steps`), and whenever the context has fewer than 2 rows or fewer than 2 classes, the stored entropy is 0. This matches the official runner.
- `unlabelled_stream` is accepted but not used. Both policies are deterministic. `seed` is recorded only.
- The policy object keeps an arrival counter, so use one policy instance per stream or run.
- Features are stored as float32, matching the official code.

## Hyperparameters to lock (record them in the run config)

| Name | Value to lock | Note |
|---|---|---|
| `k` (B) | 1000 | paper and code default |
| `short_ratio` (ρ) | 0.75, giving B_S = 750 and B_L = 250 | same for CURE and DualFIFO |
| `tau` (τ) | must be set per dataset | Official values: noaa 0.4, meter 0.1, rialto 0.1, posture_no8 0.2, nomao 0.3, poker 0.3, agr_a 0.4. There is none for NIDS data. The class default 0.3 is a placeholder; fix τ with a pre-registered rule. |
| `warmup_steps` | 100 | prediction is not scored and entropy is 0 |
| `warm_fill_ratio` | 1.0 (hard-coded) | |
| entropy clip / std epsilon | 1e-12 / 1e-6 (hard-coded) | |
| majority-class tie-break | largest label value (hard-coded) | Encode IDS labels consistently, because string labels compare lexicographically. |
| update granularity | 1 labelled row per `update`, `_h` supplied | |
| backbone (for reproduction) | TabICL-v2 `tabicl-classifier-v2-20260212.ckpt`, `n_estimators=1`, `random_state=0` | |
| `seed` | 0 | does not affect the policy |

## Test result

Command: `python3 -m pytest -v test_cure.py` (Python 3.13.16, numpy 2.5.3, pandas 3.0.5, pytest 9.1.1):

```
test_cure.py::test_split_capacity PASSED
test_cure.py::test_capacity_respected[CUREPolicy-1] PASSED
test_cure.py::test_capacity_respected[CUREPolicy-7] PASSED
test_cure.py::test_capacity_respected[DualFIFOPolicy-1] PASSED
test_cure.py::test_capacity_respected[DualFIFOPolicy-7] PASSED
test_cure.py::test_tau_zero_fills_to_budget PASSED
test_cure.py::test_normalized_entropy PASSED
test_cure.py::test_scorer_entropy_is_stored_and_needs_two_classes PASSED
test_cure.py::test_warmup_rows_get_zero_entropy PASSED
test_cure.py::test_admission_prefers_high_entropy PASSED
test_cure.py::test_admission_threshold_is_inclusive PASSED
test_cure.py::test_eviction_removes_endpoint_farther_from_recent_centroid PASSED
test_cure.py::test_eviction_targets_most_represented_class_and_tiebreak PASSED
test_cure.py::test_eviction_centroid_fallback_when_no_recent_same_class PASSED
test_cure.py::test_dualfifo_matches_definition PASSED
test_cure.py::test_dualfifo_handcrafted PASSED
test_cure.py::test_dualfifo_never_calls_scorer PASSED
test_cure.py::test_determinism[CUREPolicy] PASSED
test_cure.py::test_determinism[DualFIFOPolicy] PASSED
test_cure.py::test_batch_equals_sequential_with_precomputed_entropy PASSED
============================= 20 passed in 12.73s ==============================
```

**Equivalence check against the official code (not shipped).** Synthetic drifting streams were fed to both the official `src/stream/memory/cure_memory.py` (commit f7c6b2f) and `cure.CUREPolicy`, one row at a time, with identical class probabilities. Four configurations were run, (B, ρ, τ, C, d, T) = (60, .75, .3, 3, 10, 3000), (40, .5, .5, 5, 4, 3000), (1000, .75, .4, 2, 8, 2500) and (25, .6, 0, 4, 3, 2000). The retained rows and bank flags matched at every step, with 0 mismatches out of 10,500 steps.

## SHA-256

```
993a6c785d3d5c3dffcf765b22a25b0a09c2d2cb0cd621aa2eff3af8503172e3  cure_spec.md
bb279157fe790626a941d239cd3beb1f1bf1ec2bae00a83c1a726f31a9b209c6  cure.py
3a2c1fbd6054b534c1fad6334029b164d7bad3b6ebcb6aae86d96c8a188df29b  dualfifo.py
32b9a783578a6b308e5e52f382c099689635e49e73b07f327c9a40616b887e3c  test_cure.py
```

A file cannot contain its own hash, so the hash of this README is in `SHA256SUMS`, which covers all five files. Verify with `sha256sum -c SHA256SUMS`.
