# CURE and DualFIFO: specification for the bai1 replay harness

**Source paper.** Lee, J., Choi, D., Choi, M., & Yoo, J. (2026). *Bounded Context Management for Tabular Foundation Models on Stream Learning.* 2nd ICML Workshop on Foundation Models for Structured Data. arXiv:2606.18677 (v1).

**Official code (authoritative where it differs from the paper).**
- Repository: https://github.com/morcellinus/CURE-ICML-FMSD
- Commit: `f7c6b2f3c172ce3576f6c208a25c9655de2ea7e2` (HEAD, 2026-06-04, "Update README.md"). History has three commits; `55887f7` is "Initial Commit".
- Linked from the arXiv abstract. Found through the Hugging Face papers page and papers.cool.
- Relevant files: `src/stream/memory/cure_memory.py` (class `CUREMemoryPolicy`), `src/stream/memory/base.py`, `src/stream/experiment/tabicl_cure_runner.py` (class `RunConfig`, function `run_tabicl_cure`), `config/expected_main_taus.json`, `scripts/run_tabicl_cure.py`.
- The repository contains **no DualFIFO implementation** and none of the ablation variants. It holds only the main CURE configuration with the TabICL-v2 backbone.

**How the quotes were obtained.** arxiv.org/abs and the HTML version could not be reached from this environment. The quotes below come from a text extraction of `https://arxiv.org/pdf/2606.18677`, so LaTeX is shown as extracted. Algorithm 1 was partly garbled in that extraction, and its line numbers are a best reconstruction. Check the line numbers against the PDF before citing them in the thesis. Code quotes come straight from the cloned repository at the commit above.

---

## 1. Compartments and capacity

| Item | Paper (verbatim) | Official code |
|---|---|---|
| Banks | Sec. 4.1: "where $S_t$ is a FIFO short bank and $L_t$ is a long bank." | `_is_short: list[bool]`. A single ordered list holds both banks, and each row carries a short/long flag. |
| Budget | Sec. 4.1, Eq. (6): "$\|S_t\| \le B_S, \|L_t\| \le B_L, B_S + B_L = B,$" | `self.short_capacity = max(1, int(round(budget_B * short_ratio)))`, `self.long_capacity = max(1, budget_B - self.short_capacity)` |
| Retention guarantee | Sec. 4.1: "Thus, every example remains available for at least the short-bank duration." | Every new row enters the short bank (`self._is_short.append(True)`). |
| Defaults | Sec. 5.1: "TFM policies use a total context budget of B=1000," / "a short-bank ratio of $\rho=0.75$ , and a warm-up period of 100 stream steps." | `RunConfig`: `budget_B: int = 1000`, `short_ratio: float = 0.75`, `warmup_steps: int = 100` |
| Update frequency | Sec. 5.1: "We update the context after every arriving labeled example and report cumulative prequential accuracy." | `memory.append_then_evict(x_t, y_t, t)` runs once per stream step. |
| Warm-up | App. E.4: "We use a warm-up period of 100 stream steps and report prequential accuracy only after warm-up." | No prediction is made for `t < warmup_steps`. The row's entropy is recorded as `0.0`. |

The defaults give **B_S = 750 and B_L = 250**. The paper does not state these two numbers, but the code computes them.

The order of the context passed to the TFM is the arrival order of all retained rows, with short and long rows interleaved (`memory.arrays()` stacks `_X` in list order).

## 2. Model output used: normalised predictive entropy

- Sec. 4.2: "We attach to $z_t$ its normalized predictive entropy"
- Eq. (7): "$h(z_t) = \frac{-\sum_{c=1}^{C} p_t(c) \log p_t(c)}{\log C}$"
- Sec. 4.2: $p_t$ is the TFM output "before observing $y_t$". Also: "This score is computed once at prediction time".

The code (`CUREMemoryPolicy.record_prediction_signal`) does the following:
```python
p = np.clip(p, 1e-12, 1.0); p = p / max(1e-12, float(p.sum()))
raw_entropy = float(-(p * np.log(p)).sum())
max_entropy = float(np.log(max(int(p.size), 1)))
entropy = float(raw_entropy / max_entropy) if max_entropy > 1e-12 else 0.0
```
`p` is `clf.predict_proba(x)` from TabICL-v2, which has one column per class present in the current context. The entropy is computed once and stored with the row, and it is never recomputed. The runner predicts only when `memory.size() >= 2 and np.unique(labels_now).size >= 2` and `t >= warmup_steps`. In every other case it calls `record_prediction_signal(..., probs=None)`, which stores entropy `0.0`.

## 3. Admission rule (entropy-gated, with warm-fill)

- Sec. 4.2, Eq. (8): "Admit(z^{+}) = \begin{cases} 1, & |L_{t}| < B_{L}," / "\mathbb{I}\{h(z^{+}) \ge \tau\}, & |L_{t}| \ge B_{L}."
- Sec. 4.2: "During warm-fill, candidates are inserted into $L_t$ until the long bank is full."
- Algorithm 1 (App. D), lines 1–8 as extracted:
  1. "S \leftarrow S \cup \{z\}"
  2. "if |S| > B_S then"
  3. "z^+ = (x^+, y^+) \leftarrow \text{oldest sample in } S"
  4. "S \leftarrow S \setminus \{z^+\}"
  5. "if |L| < B_L or h(z^+) \ge \tau then"
  6. "L \leftarrow L \cup \{z^+\}"
  7–8. "end if" / "end if"
- A candidate that fails the gate is removed from S and is not added to L, so it leaves the context. The paper's wording is that the candidate "is filtered by uncertainty-gated admission".

The code (`append_then_evict`) does the following:
```python
while self.short_size() > self.short_capacity:
    idx = next((i for i, is_short in enumerate(self._is_short) if is_short), None)  # oldest short
    cand_score = self._meta_score(self._meta[idx])          # stored normalised entropy
    bypass_gate = self.long_size() < warm_fill_target        # warm_fill_target = round(B_L * 1.0)
    if (not bypass_gate) and cand_score < self.entropy_threshold:
        self._drop_with_meta(idx); continue                  # rejected -> discarded
    self._is_short[idx] = False                              # admitted -> long bank
```
The comparison is inclusive: a candidate with h ≥ τ is admitted.

## 4. Eviction rule (redundancy-aware)

- Sec. 4.3: "Cure first selects the most represented class $c_{\max} \in \arg\max_c |\{z \in L_t : y_z = c\}|$"
- Sec. 4.3: "Within this class, Cure finds the closest same-class pair in the normalized raw-feature representation $\phi(x)$ :"
- Eq. (9): "\|\phi(x_i) - \phi(x_j)\|_2" subject to "y_i = y_i = c_{\text{max}}". The second subscript is a typo for $y_j$.
- Sec. 4.3: "It computes a recent centroid for class $c_{\max}$ and removes the endpoint farther from it."
- Algorithm 1, lines 9–16 as extracted:
  9. "if |L| > B_L then"
  10. "c_{\max} \leftarrow \arg\max_{c} |\{(x_i, y_i) \in L : y_i = c\}|"
  11. "(i^*, j^*) \leftarrow \arg\min_{\substack{i \neq j \\ y_i = y_j = c_{\max}}} \|\phi(x_i) - \phi(x_j)\|_2"
  12. "\mu^* \leftarrow \begin{cases} |S(c_{\max})|^{-1} \sum_{z_i \in S(c_{\max})} \phi(x_i), & |S(c_{\max})| > 0," … "$|S|^{-1} \sum_{z_i \in S} \phi(x_i), & |S(c_{\max})| = 0$"
  13. "u^* \leftarrow \arg\max_{u \in \{i^*, j^*\}} \|\phi(x_u) - \mu^*\|_2"
  14. "L \leftarrow L \setminus \{z_{u^*}\}"
  15–16. "end if" / "return S, L"

The code (`_pick_long_drop_index`) does the following:
```python
majority_class = max(counts.items(), key=lambda kv: (kv[1], kv[0]))[0]   # tie -> largest label
same = [long rows of majority_class, in arrival order]
if len(same) <= 1: return same[0] if same else long_indices[0]
centroid_indices = short_same if short_same else short_indices          # fallback: all of S
X_all = self._normalized_joint(same + centroid_indices)                  # z-score over this joint set
dist = sqrt(sum(diff^2)) / sqrt(d); fill_diagonal(inf); argmin           # first pair in row-major order
da, db = ||X_a - centroid|| / sqrt(d), ||X_b - centroid|| / sqrt(d)
drop a if da > db; b if db > da; tie -> older (smaller t) endpoint
```
`_normalized_joint` computes `(X - X.mean(0)) / (X.std(0) + 1e-6)` in float32. The code calls the eviction step in a `while long_size() > long_capacity` loop. With single-row updates it runs at most once per step.

## 5. Hyperparameters and defaults

| Hyperparameter | Value | Source |
|---|---|---|
| B (total context budget, our `k`) | 1000 | Sec. 5.1; `RunConfig.budget_B` |
| ρ (short-bank ratio) | 0.75, so B_S = 750 and B_L = 250 | Sec. 5.1; `RunConfig.short_ratio` |
| τ (entropy threshold) | chosen per dataset: noaa 0.4, meter 0.1, rialto 0.1, posture_no8 0.2, nomao 0.3, poker 0.3, agr_a 0.4 | `config/expected_main_taus.json`; Table 8 (App. E.4), partly unreadable in the extraction |
| warm-fill ratio | 1.0 (L fills to B_L before the gate applies) | code (`self.warm_fill_ratio = 1.0`); Eq. (8) |
| warm-up steps | 100 | Sec. 5.1, App. E.4; `RunConfig.warmup_steps` |
| Entropy clip | 1e-12 | code |
| φ normalisation epsilon | 1e-6 added to std | code |
| Backbone | TabICL-v2, checkpoint `tabicl-classifier-v2-20260212.ckpt`, `n_estimators=1`, `random_state=seed=0` | Sec. 5.1 ("We use TabICL-v2 (Qu et al., 2026) as the primary backbone."); `RunConfig`, runner |
| Seed | `seed=0`. The policy ignores it (`build_cure_policy`: `del seed`). | code |

**Randomness.** The CURE policy has none. The only seed in the code goes to the TabICL backbone. The paper's Table 1 caption says "denotes standard deviation over five seeds", but the CURE column has no ± values.

## 6. DualFIFO baseline

Quoted from App. B.1:
> "DualFIFO is the FIFO-style dual-memory reference policy." "It uses the same short-bank and long-bank budgets as CURE." "New examples enter the short bank, and short-bank overflow candidates are inserted into the long bank." "When the long bank exceeds its budget, DualFIFO selects the most represented class" "and removes the oldest long-bank item from that class." "Thus, DualFIFO preserves recency and coarse class balance, but does not use uncertainty or redundancy-aware removal."

The paper attributes it to prior work in Sec. 2: "one notable prior method Dual-FIFO (Lourenço et al., 2026) shows that TFMs" / "can be effective stream learners, but this does not provide an explicit criterion for the utility of retained examples." The reference is A. Lourenço, J. Gama, E. P. Xing, G. Marreiros, "In-context learning of evolving data streams with tabular foundational models", KDD 2026, pp. 973–982 (arXiv:2502.16840). That paper describes the same mechanism: the short-term memory "captures the most recent samples from the stream"; on overflow "the oldest sample is removed and moved to the long-term memory"; and on long-term overflow "the oldest sample from this overrepresented class is then removed". This cross-check was done with a text extraction of arXiv:2502.16840v2.

**Classification.** DualFIFO is a **recent FIFO bank plus a long-term bank** (B_S = 750, B_L = 250, the same budgets as CURE). It is **not** a per-class FIFO. Every short-bank overflow goes into the long bank with no gate. When the long bank overflows, it removes the **oldest long-bank row of the most represented class**. It never uses model outputs.

## 7. Ambiguities and the choices made (A = assumption unless the official code settles it)

| # | Gap in the paper | Choice made | Basis |
|---|---|---|---|
| 1 | φ(x), the "normalized raw-feature representation", is never defined. | Per-feature z-score `(X-mean)/(std+1e-6)` computed **only over the joint set** {long rows of c_max} ∪ {centroid rows}, in float32. | Official code |
| 2 | Value of C in Eq. (7). | C is the number of probability columns the scorer returns (classes present in the TFM's context), not the number of classes in the stream. | Official code |
| 3 | Entropy of rows with no prediction (warm-up, or context with fewer than 2 rows or fewer than 2 classes). | Stored h = 0. Such a row is admitted only during warm-fill (or if τ = 0). | Official code |
| 4 | Tie in the most represented class (paper writes "∈ argmax"). | The largest label value wins, since the code uses `max` over `(count, label)`. **IDS note:** with string labels this means the lexicographically largest label wins. | Official code |
| 5 | Tie between candidate nearest pairs. | The first pair in row-major order over the same-class long rows in arrival order (`np.argmin`). | Official code |
| 6 | Tie in endpoint distance to μ*. | Evict the older endpoint (smaller arrival index). | Official code |
| 7 | Fate of a rejected candidate. | Discarded from the context. | Alg. 1 and code |
| 8 | Distance scaling. | The code divides by √d. This does not change any argmin or argmax and is kept for exact float agreement. | Official code |
| 9 | Rounding of B_S = ρB. | Python `round()` (banker's rounding), as in the code. **A (deviation):** B_S is capped at B−1, because the code can produce B_S + B_L = B+1 when round(ρB) ≥ B. This has no effect for B=1000 and ρ=0.75. | Code plus our fix |
| 10 | Selection protocol for τ. | Not described (the App. E.4 text says only "the selected value is the entropy threshold"). Use the per-dataset values from the code. **A:** for a new dataset (our NIDS data), τ has no default. Our class default of 0.3 is a placeholder and must be locked explicitly. | Paper silent |
| 11 | τ for AGR(A) and NOMAO. | The extraction of Table 8 reads AGR(A) as 0.3 and NOMAO as unreadable. The code config gives 0.4 and 0.3, which are also the best-scoring τ in Table 5 (90.93 and 97.87, equal to the CURE numbers in Table 1). We follow the code. | Code, Table 5 |
| 12 | Batch updates (the paper updates after every example). | Rows in one `update()` call are processed one at a time in the given order. **A:** if the caller does not provide a precomputed `_h`, the scorer is called once on the whole batch with the pre-batch context. This equals the official behaviour only for batches of size 1. Pass `_h` from the prediction step to get exact agreement. | Our harness |
| 13 | Order of the context fed to the TFM. | Arrival order of all retained rows (S and L interleaved). The returned DataFrame is sorted by `_arrival`. | Official code |
| 14 | DualFIFO tie-break for the most represented class. | **A:** same as CURE (largest label). The repository has no DualFIFO code, and neither paper specifies a tie-break. | Assumption |
| 15 | DualFIFO warm-up and warm-fill. | **A:** none. Every overflow is promoted and FIFO behaviour starts at once, as described in B.1. | B.1 text |
| 16 | Number of CURE seeds. | Unspecified. The policy is deterministic, and the backbone uses `random_state=0`. | Code |
| 17 | `unlabelled_stream` argument. | Not used by either policy. CURE in the paper uses labelled rows only. | Paper |
| 18 | Feature precision. | The policy stores and compares features as float32 (as in the code). The context is returned in the caller's dtypes. | Official code |

## 8. Reproduction checks available from the paper

The protocol is test-then-train prequential evaluation, scored by "cumulative prequential accuracy" after a 100-step warm-up (Sec. 5.1, App. E.4). The streams are seven datasets from the USP Data Stream repository plus synthetic AGR(A). The code bundle ships the CSV files under `data/uspds/`.

**Table 7 (dataset statistics).** NOAA 18,159 rows × 8 features × 2 classes; METER 22,948 × 96 × 10; RIALTO 82,250 × 27 × 10; POSTURE-No8 163,477 × 3 × 10; POKER 829,201 × 10 × 10; NOMAO 34,465 × 118 × 2; AGR(A) 30,000 × 9 × 2. AGR(A) has abrupt drift at steps 7,500, 15,000 and 22,500 over Agrawal functions (0, 3, 6, 9) with 10% perturbation (code: `AGRASpec`, generator seed 5). Note that the code's `DEFAULT_MAXLEN` lists METER as 22950, while Table 7 says 22,948.

**Table 1 (prequential accuracy %, TabICL-v2 + CURE).** NOAA 81.94, METER 90.80, RIALTO 92.04, POSTURE-No8 62.10, POKER 99.60, NOMAO 97.87, AGR(A) 90.93. CURE has average rank 1.00 against ARF, BOLE, LevBag, SRP, EFDT and VFDT. The best baselines are ARF 79.42 on NOAA, SRP 71.49 on METER, SRP 72.45 on RIALTO, LevBag 60.52 on POSTURE-No8, LevBag 97.53 on POKER, SRP 97.42 on NOMAO and ARF 90.26 on AGR(A). The abstract's "up to 27.0%" relative gain is RIALTO: 92.04 / 72.45.

**Table 4 (ablation, TabICL-v2, six streams without POKER). This is the direct check for our two policies.**

| Dataset | CURE | DualFIFO | Entropy-only | Redundancy-only | CURE-Margin | CURE-GlobalNN |
|---|---|---|---|---|---|---|
| NOAA | 81.94 | 81.42 | 81.78 | 81.64 | 81.90 | 81.95 |
| METER | 90.80 | 90.60 | 89.94 | 90.63 | 90.53 | 90.68 |
| RIALTO | 92.04 | 91.72 | 91.36 | 91.97 | 92.00 | 92.02 |
| POSTURE-No8 | 62.10 | 61.85 | 61.97 | 62.01 | 62.01 | 61.88 |
| NOMAO | 97.87 | 97.47 | 97.65 | 97.64 | 97.81 | 97.75 |
| AGR(A) | 90.93 | 90.45 | 90.84 | 90.54 | 90.74 | 90.62 |
| Avg. rank | 1.17 | 5.50 | 4.33 | 4.08 | 3.08 | 2.83 |

**Table 5 (sensitivity to τ, TabICL-v2).** The τ = 0 column equals the Redundancy-only column of Table 4 on all six streams (81.64, 90.63, 91.97, 62.01, 97.64, 90.54). This is an internal consistency check: `CUREPolicy(tau=0)` must reproduce Redundancy-only. The other columns are:
- NOAA: 81.64, 81.83, 81.82, 81.94, 81.88 for τ = 0.1 to 0.5
- METER: 90.80, 90.62, 90.68, 90.62, 90.48
- RIALTO: 92.04, 91.98, 92.00, 92.02, 91.96
- POSTURE-No8: 62.03, 62.10, 62.03, 62.03, 62.08
- NOMAO: 97.71, 97.82, 97.87, 97.86, 97.86
- AGR(A): 90.49, 90.61, 90.52, 90.93, 90.61

App. B.2 says: "Cure is not sensitive to a narrowly tuned threshold."

**Table 2 (CURE vs DualFIFO on other backbones).**

| Dataset | LimiX-v1 CURE / DualFIFO | TabPFN-v2.5 CURE / DualFIFO | TabDPT-v1 CURE / DualFIFO |
|---|---|---|---|
| NOAA | 81.43 / 80.83 | 81.82 / 81.26 | 81.94 / 81.49 |
| METER | 89.06 / 88.69 | 87.88 / 87.64 | 80.73 / 79.65 |
| RIALTO | 90.17 / 89.59 | 89.53 / 88.93 | 88.05 / 87.64 |
| POSTURE-No8 | 60.50 / 60.47 | 60.83 / 60.99 | 61.67 / 61.50 |
| NOMAO | 97.83 / 97.54 | 97.85 / 97.55 | 97.34 / 96.58 |
| AGR(A) | 90.56 / 90.54 | 91.02 / 90.85 | 90.02 / 89.93 |

CURE beats DualFIFO in 17 of 18 cells. The exception is TabPFN-v2.5 on POSTURE-No8.

**Table 6 (per-step runtime).** CURE takes 0.0283 s in total (fit 0.0044, predict 0.0226, evict 0.0013). DualFIFO takes 0.0259 s.

**Policy-level check run on our side.** On synthetic streams, `cure.CUREPolicy` was compared step by step with the official `CUREMemoryPolicy` (commit f7c6b2f) on four configurations: (B, ρ, τ, C, d, T) = (60, .75, .3, 3, 10, 3000), (40, .5, .5, 5, 4, 3000), (1000, .75, .4, 2, 8, 2500) and (25, .6, 0, 4, 3, 2000). The retained arrival indices and the bank flags agreed at **every step, with 0 mismatches**. The comparison script is not shipped; it is described in the README.
