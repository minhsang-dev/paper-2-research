"""CURE context-management policy (reference re-implementation).

Source
------
Lee, J., Choi, D., Choi, M., & Yoo, J. (2026). "Bounded Context Management for
Tabular Foundation Models on Stream Learning". 2nd ICML Workshop on Foundation
Models for Structured Data. arXiv:2606.18677.

Authoritative code: https://github.com/morcellinus/CURE-ICML-FMSD
commit f7c6b2f3c172ce3576f6c208a25c9655de2ea7e2, file
src/stream/memory/cure_memory.py (class CUREMemoryPolicy). Where the paper and
the code differ, this module follows the code. See cure_spec.md.

Policy interface
----------------
    policy.update(context, new_labelled_rows, unlabelled_stream, scorer) -> context

* context / new_labelled_rows: pandas DataFrames with feature columns, a label
  column 'y' and an identifier column 'row_id'. The policy adds three
  bookkeeping columns to the context it returns (META_COLS): '_bank' ('S' short
  / 'L' long), '_h' (stored normalised entropy), '_arrival' (arrival index).
  Pass the returned context back unchanged on the next call.
* unlabelled_stream: accepted for interface compatibility, NOT used by CURE.
* scorer(X) -> (n, C) class-probability array, X a float numpy array of the
  feature columns of new_labelled_rows. It must be the TFM conditioned on the
  `context` passed into this call (i.e. the prediction-time model). If
  new_labelled_rows already holds a column '_h' (precomputed normalised entropy
  from the prediction step), that column is used and scorer is not called.

Pure numpy / pandas. No randomness (the official code ignores its seed); a seed
argument is accepted and recorded only.
"""

from __future__ import annotations

from collections import Counter
from typing import Callable, Optional, Sequence

import numpy as np
import pandas as pd

LABEL_COL = "y"
ID_COL = "row_id"
BANK_COL = "_bank"
ENTROPY_COL = "_h"
ARRIVAL_COL = "_arrival"
META_COLS = (BANK_COL, ENTROPY_COL, ARRIVAL_COL)
SHORT, LONG = "S", "L"

Scorer = Callable[[np.ndarray], np.ndarray]


# --------------------------------------------------------------------------- #
# Shared helpers (also imported by dualfifo.py)
# --------------------------------------------------------------------------- #
def split_capacity(budget_B: int, short_ratio: float) -> tuple[int, int]:
    """B_S, B_L as in the official code: B_S = max(1, round(B*rho)), B_L = max(1, B-B_S).

    Deviation (assumption A9 in cure_spec.md): the official code can yield
    B_S + B_L = B + 1 when round(B*rho) >= B. We cap B_S at B-1 so that
    |context| <= B always holds. Identical to the official code for B=1000, rho=0.75.
    """
    if budget_B < 2:
        raise ValueError("budget_B must be >= 2 (one short and one long slot)")
    if not 0.0 < short_ratio < 1.0:
        raise ValueError("short_ratio must be in (0, 1)")
    b_s = max(1, int(round(budget_B * short_ratio)))  # Python round(), as in official code
    b_s = min(b_s, budget_B - 1)
    b_l = max(1, budget_B - b_s)
    return b_s, b_l


def normalized_entropy(probs: np.ndarray) -> np.ndarray:
    """Eq. (7) as implemented in the official code (record_prediction_signal).

    p clipped to [1e-12, 1], renormalised, H = -sum p log p, divided by log C where
    C = number of probability columns returned by the scorer. C == 1 -> 0.
    """
    p = np.asarray(probs, dtype=np.float64)
    if p.ndim == 1:
        p = p.reshape(1, -1)
    p = np.clip(p, 1e-12, 1.0)
    p = p / np.maximum(1e-12, p.sum(axis=1, keepdims=True))
    raw = -(p * np.log(p)).sum(axis=1)
    c = p.shape[1]
    max_h = float(np.log(max(int(c), 1)))
    if max_h <= 1e-12:
        return np.zeros(p.shape[0], dtype=np.float64)
    return raw / max_h


def feature_columns(df: pd.DataFrame, explicit: Optional[Sequence[str]] = None) -> list[str]:
    if explicit is not None:
        return list(explicit)
    excl = {LABEL_COL, ID_COL, *META_COLS}
    return [c for c in df.columns if c not in excl]


def majority_class(labels: list) -> object:
    """argmax_c count(c); tie -> the largest label value (official: max over (count, label))."""
    counts = Counter(labels)
    return max(counts.items(), key=lambda kv: (kv[1], kv[0]))[0]


class _Store:
    """Ordered list-of-rows store mirroring the official BaseMemoryPolicy lists.

    Row order is arrival order; promotion S->L flips a flag but keeps position,
    exactly as the official `_is_short` list does.
    """

    def __init__(self) -> None:
        self.X: list[np.ndarray] = []
        self.y: list = []
        self.rid: list = []
        self.t: list[int] = []
        self.is_short: list[bool] = []
        self.h: list[float] = []

    @classmethod
    def from_frame(cls, ctx: Optional[pd.DataFrame], fcols: list[str]) -> "_Store":
        st = cls()
        if ctx is None or len(ctx) == 0:
            return st
        missing = [c for c in META_COLS if c not in ctx.columns]
        if missing:
            raise ValueError(
                f"context lacks policy columns {missing}; pass back the context returned by update()"
            )
        ctx = ctx.sort_values(ARRIVAL_COL, kind="mergesort")
        Xa = ctx[fcols].to_numpy(dtype=np.float32)
        st.X = [np.ascontiguousarray(r) for r in Xa]
        st.y = ctx[LABEL_COL].tolist()
        st.rid = ctx[ID_COL].tolist()
        st.t = [int(v) for v in ctx[ARRIVAL_COL].tolist()]
        st.is_short = [b == SHORT for b in ctx[BANK_COL].tolist()]
        st.h = [float(v) for v in ctx[ENTROPY_COL].tolist()]
        return st

    def to_frame(self, fcols: list[str], template: Optional[pd.DataFrame]) -> pd.DataFrame:
        X = np.stack(self.X, axis=0) if self.X else np.empty((0, len(fcols)), dtype=np.float32)
        df = pd.DataFrame(X, columns=fcols)
        if template is not None:  # restore caller dtypes for features where possible
            for c in fcols:
                if c in template.columns:
                    try:
                        df[c] = df[c].astype(template[c].dtype)
                    except (TypeError, ValueError):
                        pass
        df[LABEL_COL] = pd.Series(self.y, dtype=object if not self.y else None)
        df[ID_COL] = pd.Series(self.rid, dtype=object if not self.rid else None)
        df[BANK_COL] = [SHORT if s else LONG for s in self.is_short]
        df[ENTROPY_COL] = np.asarray(self.h, dtype=np.float64)
        df[ARRIVAL_COL] = np.asarray(self.t, dtype=np.int64)
        return df.reset_index(drop=True)

    def size(self) -> int:
        return len(self.y)

    def short_size(self) -> int:
        return int(sum(self.is_short))

    def long_size(self) -> int:
        return self.size() - self.short_size()

    def append(self, x, y, rid, t, h) -> None:
        self.X.append(np.ascontiguousarray(x, dtype=np.float32))
        self.y.append(y)
        self.rid.append(rid)
        self.t.append(int(t))
        self.is_short.append(True)
        self.h.append(float(h))

    def drop(self, idx: int) -> None:
        for lst in (self.X, self.y, self.rid, self.t, self.is_short, self.h):
            del lst[idx]

    def oldest_short(self) -> Optional[int]:
        return next((i for i, s in enumerate(self.is_short) if s), None)


# --------------------------------------------------------------------------- #
# CURE
# --------------------------------------------------------------------------- #
class CUREPolicy:
    """CURE: FIFO short bank + entropy-gated long bank with redundancy-aware eviction.

    Hyperparameters (defaults = paper Sec. 5.1 / official RunConfig):
        k (budget B)        = 1000
        short_ratio (rho)   = 0.75   -> B_S = 750, B_L = 250
        tau                 : per dataset (official config/expected_main_taus.json);
                              default here 0.3 is an ASSUMPTION (no global default exists).
        warmup_steps        = 100    rows with arrival index < warmup_steps get h = 0
                              (official runner makes no prediction during warm-up and
                              records entropy 0.0).
        warm_fill_ratio     = 1.0    (official, hard-coded)
    """

    name = "cure"

    def __init__(
        self,
        k: int = 1000,
        short_ratio: float = 0.75,
        tau: float = 0.3,
        warmup_steps: int = 100,
        seed: int = 0,
        feature_cols: Optional[Sequence[str]] = None,
    ) -> None:
        self.k = int(k)
        self.short_ratio = float(short_ratio)
        self.short_capacity, self.long_capacity = split_capacity(self.k, self.short_ratio)
        self.tau = float(tau)
        self.warmup_steps = int(warmup_steps)
        self.warm_fill_ratio = 1.0
        self.seed = int(seed)  # recorded only: the policy is deterministic
        self.feature_cols = list(feature_cols) if feature_cols is not None else None
        self._n_seen = 0
        self.last_events: list[dict] = []

    # ------------------------------------------------------------------ API
    def update(
        self,
        context: Optional[pd.DataFrame],
        new_labelled_rows: pd.DataFrame,
        unlabelled_stream=None,
        scorer: Optional[Scorer] = None,
    ) -> pd.DataFrame:
        del unlabelled_stream  # not used by CURE
        fcols = feature_columns(new_labelled_rows, self.feature_cols)
        store = _Store.from_frame(context, fcols)
        if context is not None and len(context) > 0:
            self._n_seen = max(self._n_seen, int(context[ARRIVAL_COL].max()) + 1)
        h_new = self._entropies(context, new_labelled_rows, fcols, scorer)
        Xn = new_labelled_rows[fcols].to_numpy(dtype=np.float32)
        yn = new_labelled_rows[LABEL_COL].tolist()
        rn = new_labelled_rows[ID_COL].tolist()
        self.last_events = []
        for i in range(len(new_labelled_rows)):
            t = self._n_seen
            self._n_seen += 1
            h = 0.0 if t < self.warmup_steps else float(h_new[i])
            self._append_then_evict(store, Xn[i], yn[i], rn[i], t, h)
        return store.to_frame(fcols, new_labelled_rows)

    # ------------------------------------------------------------ internals
    def _entropies(self, context, new_rows, fcols, scorer) -> np.ndarray:
        n = len(new_rows)
        if ENTROPY_COL in new_rows.columns:
            return new_rows[ENTROPY_COL].fillna(0.0).to_numpy(dtype=np.float64)
        # Official runner: no prediction (entropy 0) unless context has >= 2 rows and >= 2 classes.
        can_predict = (
            scorer is not None
            and context is not None
            and len(context) >= 2
            and context[LABEL_COL].nunique() >= 2
        )
        if not can_predict or n == 0:
            return np.zeros(n, dtype=np.float64)
        probs = np.asarray(scorer(new_rows[fcols].to_numpy(dtype=np.float64)))
        if probs.ndim != 2 or probs.shape[0] != n:
            raise ValueError("scorer must return an (n_rows, n_classes) probability array")
        return normalized_entropy(probs)

    def _append_then_evict(self, st: _Store, x, y, rid, t, h) -> None:
        st.append(x, y, rid, t, h)
        warm_fill_target = int(round(self.long_capacity * self.warm_fill_ratio))
        # Short-bank overflow -> admission gate (Eq. 8; Alg. 1 lines 2-8).
        while st.short_size() > self.short_capacity:
            idx = st.oldest_short()
            if idx is None:
                break
            bypass_gate = st.long_size() < warm_fill_target
            if (not bypass_gate) and st.h[idx] < self.tau:
                self.last_events.append({"event": "reject", "row_id": st.rid[idx], "h": st.h[idx]})
                st.drop(idx)
                continue
            st.is_short[idx] = False
            self.last_events.append({"event": "admit", "row_id": st.rid[idx], "h": st.h[idx]})
        # Long-bank overflow -> redundancy-aware eviction (Eq. 9; Alg. 1 lines 9-15).
        while st.long_size() > self.long_capacity:
            idx = self._pick_long_drop_index(st)
            if idx is None:
                break
            self.last_events.append({"event": "evict", "row_id": st.rid[idx]})
            st.drop(idx)

    @staticmethod
    def _normalized_joint(st: _Store, indices: list[int]) -> np.ndarray:
        # phi(x): per-feature z-score over the joint set {same-class long rows} U {centroid rows}
        X = np.stack([st.X[i] for i in indices], axis=0).astype(np.float32, copy=False)
        mean = X.mean(axis=0, keepdims=True)
        std = X.std(axis=0, keepdims=True) + 1e-6
        return (X - mean) / std

    @staticmethod
    def _nearest_pair(X: np.ndarray) -> Optional[tuple[int, int]]:
        if X.shape[0] < 2:
            return None
        diff = X[:, None, :] - X[None, :, :]
        dist = np.sqrt(np.sum(diff * diff, axis=2)) / np.sqrt(max(1, X.shape[1]))
        np.fill_diagonal(dist, np.inf)
        a, b = np.unravel_index(int(np.argmin(dist)), dist.shape)  # first in row-major order
        return int(a), int(b)

    def _pick_long_drop_index(self, st: _Store) -> Optional[int]:
        long_idx = [i for i, s in enumerate(st.is_short) if not s]
        if not long_idx:
            return None
        c_max = majority_class([st.y[i] for i in long_idx])
        same = [i for i in long_idx if st.y[i] == c_max]
        if len(same) <= 1:
            return same[0] if same else long_idx[0]
        short_idx = [i for i, s in enumerate(st.is_short) if s]
        short_same = [i for i in short_idx if st.y[i] == c_max]
        centroid_idx = short_same if short_same else short_idx
        X_all = self._normalized_joint(st, same + centroid_idx)
        X_same = X_all[: len(same)]
        mu = X_all[len(same):].mean(axis=0) if centroid_idx else X_same.mean(axis=0)
        pair = self._nearest_pair(X_same)
        if pair is None:
            return same[0]
        a, b = pair
        ia, ib = same[a], same[b]
        d = float(np.sqrt(max(1, X_same.shape[1])))
        da = float(np.linalg.norm(X_same[a] - mu) / d)
        db = float(np.linalg.norm(X_same[b] - mu) / d)
        if da > db:
            return ia
        if db > da:
            return ib
        return ia if st.t[ia] <= st.t[ib] else ib  # tie -> older endpoint


def update(context, new_labelled_rows, unlabelled_stream, scorer, *, policy: CUREPolicy):
    """Functional alias: policy object carries hyperparameters and the arrival counter."""
    return policy.update(context, new_labelled_rows, unlabelled_stream, scorer)


__all__ = [
    "CUREPolicy",
    "update",
    "split_capacity",
    "normalized_entropy",
    "META_COLS",
    "BANK_COL",
    "ENTROPY_COL",
    "ARRIVAL_COL",
    "LABEL_COL",
    "ID_COL",
]
