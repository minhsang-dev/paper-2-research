"""DualFIFO baseline context policy (reference re-implementation).

Definition (Lee et al., 2026, arXiv:2606.18677, Appendix B.1, quoted in cure_spec.md):
  "DualFIFO is the FIFO-style dual-memory reference policy."
  "It uses the same short-bank and long-bank budgets as CURE."
  "New examples enter the short bank, and short-bank overflow candidates are
   inserted into the long bank."
  "When the long bank exceeds its budget, DualFIFO selects the most represented
   class" "and removes the oldest long-bank item from that class."
This matches Dual-FIFO of Lourenco, Gama, Xing & Marreiros (KDD 2026,
arXiv:2502.16840). It is NOT a per-class FIFO: it is one recent FIFO bank plus
one long bank with class-aware oldest-first removal.

The official CURE repository (commit f7c6b2f) does not ship a DualFIFO
implementation; the tie-break for the most represented class (largest label
value) is copied from the official CURE code and is an ASSUMPTION for DualFIFO.

Interface identical to cure.CUREPolicy.update. No entropy is used; the scorer
is never called. Deterministic; no randomness.
"""

from __future__ import annotations

from typing import Optional, Sequence

import pandas as pd

try:  # package import (bai1_protocol/replay/)
    from .cure import (
        ARRIVAL_COL,
        _Store,
        feature_columns,
        majority_class,
        split_capacity,
    )
except ImportError:  # flat import (tests next to the files)
    from cure import (  # type: ignore
        ARRIVAL_COL,
        _Store,
        feature_columns,
        majority_class,
        split_capacity,
    )


class DualFIFOPolicy:
    """Short FIFO bank (B_S) + long bank (B_L) with majority-class oldest-first eviction."""

    name = "dualfifo"

    def __init__(
        self,
        k: int = 1000,
        short_ratio: float = 0.75,
        seed: int = 0,
        feature_cols: Optional[Sequence[str]] = None,
    ) -> None:
        self.k = int(k)
        self.short_ratio = float(short_ratio)
        self.short_capacity, self.long_capacity = split_capacity(self.k, self.short_ratio)
        self.seed = int(seed)  # recorded only
        self.feature_cols = list(feature_cols) if feature_cols is not None else None
        self._n_seen = 0
        self.last_events: list[dict] = []

    def update(
        self,
        context: Optional[pd.DataFrame],
        new_labelled_rows: pd.DataFrame,
        unlabelled_stream=None,
        scorer=None,
    ) -> pd.DataFrame:
        del unlabelled_stream, scorer  # not used by DualFIFO
        fcols = feature_columns(new_labelled_rows, self.feature_cols)
        st = _Store.from_frame(context, fcols)
        if context is not None and len(context) > 0:
            self._n_seen = max(self._n_seen, int(context[ARRIVAL_COL].max()) + 1)
        Xn = new_labelled_rows[fcols].to_numpy(dtype="float32")
        yn = new_labelled_rows["y"].tolist()
        rn = new_labelled_rows["row_id"].tolist()
        self.last_events = []
        for i in range(len(new_labelled_rows)):
            t = self._n_seen
            self._n_seen += 1
            st.append(Xn[i], yn[i], rn[i], t, 0.0)
            # short-bank overflow: oldest short item always moves to the long bank
            while st.short_size() > self.short_capacity:
                idx = st.oldest_short()
                st.is_short[idx] = False
                self.last_events.append({"event": "promote", "row_id": st.rid[idx]})
            # long-bank overflow: oldest long item of the most represented class is removed
            while st.long_size() > self.long_capacity:
                long_idx = [j for j, s in enumerate(st.is_short) if not s]
                c_max = majority_class([st.y[j] for j in long_idx])
                cand = [j for j in long_idx if st.y[j] == c_max]
                idx = min(cand, key=lambda j: (st.t[j], j))
                self.last_events.append({"event": "evict", "row_id": st.rid[idx]})
                st.drop(idx)
        return st.to_frame(fcols, new_labelled_rows)


__all__ = ["DualFIFOPolicy"]
