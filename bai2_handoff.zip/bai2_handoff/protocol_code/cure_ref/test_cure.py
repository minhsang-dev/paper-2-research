"""pytest suite for cure.py and dualfifo.py (synthetic data only)."""

from __future__ import annotations

import os
import sys
from collections import deque

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from cure import (  # noqa: E402
    ARRIVAL_COL,
    BANK_COL,
    ENTROPY_COL,
    CUREPolicy,
    normalized_entropy,
    split_capacity,
)
from dualfifo import DualFIFOPolicy  # noqa: E402

FEATS = ["f0", "f1", "f2"]


def make_rows(start_id, n, rng, n_classes=3, h=None):
    X = rng.normal(size=(n, len(FEATS)))
    df = pd.DataFrame(X, columns=FEATS)
    df["y"] = rng.integers(0, n_classes, size=n)
    df["row_id"] = np.arange(start_id, start_id + n)
    if h is not None:
        df[ENTROPY_COL] = h
    return df


def row(rid, x, y, h=None):
    d = {f: [v] for f, v in zip(FEATS, x)}
    d["y"] = [y]
    d["row_id"] = [rid]
    if h is not None:
        d[ENTROPY_COL] = [h]
    return pd.DataFrame(d)


def ctx_frame(rows):
    """rows: list of (row_id, x, y, bank, h, arrival)."""
    return pd.DataFrame(
        {
            **{f: [r[1][i] for r in rows] for i, f in enumerate(FEATS)},
            "y": [r[2] for r in rows],
            "row_id": [r[0] for r in rows],
            BANK_COL: [r[3] for r in rows],
            ENTROPY_COL: [r[4] for r in rows],
            ARRIVAL_COL: [r[5] for r in rows],
        }
    )


def random_scorer(seed):
    rng = np.random.default_rng(seed)

    def scorer(X):
        logits = rng.normal(scale=2.0, size=(X.shape[0], 3))
        e = np.exp(logits - logits.max(axis=1, keepdims=True))
        return e / e.sum(axis=1, keepdims=True)

    return scorer


# ----------------------------------------------------------------- capacity
def test_split_capacity():
    assert split_capacity(1000, 0.75) == (750, 250)
    assert split_capacity(20, 0.75) == (15, 5)
    assert split_capacity(4, 0.9) == (3, 1)  # capped so that B_S + B_L <= B


@pytest.mark.parametrize("batch", [1, 7])
@pytest.mark.parametrize("Policy", [CUREPolicy, DualFIFOPolicy])
def test_capacity_respected(Policy, batch):
    rng = np.random.default_rng(0)
    kw = dict(k=20, short_ratio=0.75)
    if Policy is CUREPolicy:
        kw.update(tau=0.3, warmup_steps=0)
    pol = Policy(**kw)
    ctx = None
    scorer = random_scorer(1)
    rid = 0
    for _ in range(300 // batch):
        new = make_rows(rid, batch, rng)
        rid += batch
        ctx = pol.update(ctx, new, None, scorer)
        assert len(ctx) <= 20
        assert (ctx[BANK_COL] == "S").sum() <= 15
        assert (ctx[BANK_COL] == "L").sum() <= 5
        assert ctx["row_id"].is_unique
    # short bank is always the most recent B_S rows (FIFO)
    s_ids = sorted(ctx.loc[ctx[BANK_COL] == "S", "row_id"])
    assert s_ids == list(range(rid - 15, rid))


def test_tau_zero_fills_to_budget():
    rng = np.random.default_rng(3)
    pol = CUREPolicy(k=20, short_ratio=0.75, tau=0.0, warmup_steps=0)
    ctx = None
    for i in range(100):
        ctx = pol.update(ctx, make_rows(i, 1, rng, h=0.0), None, None)
    assert len(ctx) == 20


# ---------------------------------------------------------------- entropy
def test_normalized_entropy():
    p = np.array([[1 / 3, 1 / 3, 1 / 3], [1.0, 0.0, 0.0], [0.5, 0.5, 0.0]])
    h = normalized_entropy(p)
    assert h[0] == pytest.approx(1.0)
    assert h[1] == pytest.approx(0.0, abs=1e-9)
    assert h[2] == pytest.approx(np.log(2) / np.log(3), rel=1e-6)
    assert normalized_entropy(np.array([[1.0]]))[0] == 0.0


def test_scorer_entropy_is_stored_and_needs_two_classes():
    pol = CUREPolicy(k=10, short_ratio=0.5, tau=0.5, warmup_steps=0)
    uniform = lambda X: np.full((X.shape[0], 4), 0.25)  # noqa: E731
    ctx = pol.update(None, row(0, [0, 0, 0], 0), None, uniform)
    assert ctx[ENTROPY_COL].iloc[0] == 0.0  # empty context -> no prediction -> h = 0
    ctx = pol.update(ctx, row(1, [1, 0, 0], 0), None, uniform)
    assert ctx[ENTROPY_COL].iloc[1] == 0.0  # one class in context -> no prediction
    ctx = pol.update(ctx, row(2, [2, 0, 0], 1), None, uniform)
    assert ctx[ENTROPY_COL].iloc[2] == 0.0  # context {0,0}: still one class
    ctx = pol.update(ctx, row(3, [3, 0, 0], 1), None, uniform)
    assert ctx[ENTROPY_COL].iloc[3] == pytest.approx(1.0)


def test_warmup_rows_get_zero_entropy():
    pol = CUREPolicy(k=10, short_ratio=0.5, tau=0.5, warmup_steps=3)
    ctx = None
    for i in range(5):
        ctx = pol.update(ctx, row(i, [i, 0, 0], i % 2, h=0.9), None, None)
    assert ctx[ENTROPY_COL].tolist() == [0.0, 0.0, 0.0, 0.9, 0.9]


# -------------------------------------------------------------- admission
def test_admission_prefers_high_entropy():
    # B=8, rho=0.5 -> B_S=4, B_L=4, tau=0.5
    pol = CUREPolicy(k=8, short_ratio=0.5, tau=0.5, warmup_steps=0)
    ctx = None
    rid = 0
    # 8 low-entropy rows: the first 4 overflow S and are warm-filled into L regardless of h
    for _ in range(8):
        ctx = pol.update(ctx, row(rid, [rid, 0, 0], rid % 2, h=0.0), None, None)
        rid += 1
    assert sorted(ctx.loc[ctx[BANK_COL] == "L", "row_id"]) == [0, 1, 2, 3]
    high, low = [], []
    for j in range(20):
        h = 0.9 if j % 2 == 0 else 0.1
        (high if h > 0.5 else low).append(rid)
        ctx = pol.update(ctx, row(rid, [rid, j % 3, 0], rid % 2, h=h), None, None)
        for ev in pol.last_events:
            if ev["event"] in ("admit", "reject"):
                assert (ev["event"] == "admit") == (ev["h"] >= 0.5)
        rid += 1
    L_ids = set(ctx.loc[ctx[BANK_COL] == "L", "row_id"])
    S_ids = set(ctx.loc[ctx[BANK_COL] == "S", "row_id"])
    # no low-entropy row that left S is still in the context
    assert not ({r for r in low if r not in S_ids} & set(ctx["row_id"]))
    assert L_ids <= set(high) | {0, 1, 2, 3}
    assert len(L_ids & set(high)) >= 1


def test_admission_threshold_is_inclusive():
    pol = CUREPolicy(k=4, short_ratio=0.5, tau=0.4, warmup_steps=0)  # B_S=2, B_L=2
    ctx = None
    for i in range(4):
        ctx = pol.update(ctx, row(i, [i, 0, 0], 0, h=0.0), None, None)  # L warm-filled by 0,1
    ctx = pol.update(ctx, row(4, [4, 0, 0], 1, h=0.0), None, None)  # row 2 overflows, h=0 < tau
    assert pol.last_events[0] == {"event": "reject", "row_id": 2, "h": 0.0}
    # give the next overflow candidate (row 3) h == tau by rewriting its stored entropy
    ctx.loc[ctx["row_id"] == 3, ENTROPY_COL] = 0.4
    ctx = pol.update(ctx, row(5, [5, 0, 0], 1, h=0.0), None, None)
    assert pol.last_events[0]["event"] == "admit" and pol.last_events[0]["row_id"] == 3


# --------------------------------------------------------------- eviction
def _eviction_case(short_x):
    # B=8, rho=0.5 -> B_S=4, B_L=4. L is full: class 1 = {A, B (near pair), C}, class 0 = {D}.
    rows = [
        (100, [0.0, 0.0, 0.0], 1, "L", 0.9, 0),  # A
        (101, [0.1, 0.0, 0.0], 1, "L", 0.9, 1),  # B (nearest to A)
        (102, [5.0, 5.0, 1.0], 1, "L", 0.9, 2),  # C
        (103, [-5.0, 5.0, -1.0], 0, "L", 0.9, 3),  # D
        (104, [3.0, 3.0, 3.0], 0, "S", 0.9, 4),  # oldest S, class 0, will be admitted
    ] + [(105 + i, short_x, 1, "S", 0.9, 5 + i) for i in range(3)]
    return ctx_frame(rows)


def test_eviction_removes_endpoint_farther_from_recent_centroid():
    pol = CUREPolicy(k=8, short_ratio=0.5, tau=0.5, warmup_steps=0)
    # recent class-1 centroid on the +x side -> A (x=0) is the farther endpoint
    ctx = pol.update(_eviction_case([10.0, 0.0, 0.0]), row(200, [9, 0, 0], 1, h=0.9), None, None)
    assert [e["row_id"] for e in pol.last_events if e["event"] == "evict"] == [100]
    assert len(ctx) == 8 and 104 in set(ctx.loc[ctx[BANK_COL] == "L", "row_id"])
    # recent class-1 centroid on the -x side -> B (x=0.1) is farther
    pol = CUREPolicy(k=8, short_ratio=0.5, tau=0.5, warmup_steps=0)
    pol.update(_eviction_case([-10.0, 0.0, 0.0]), row(200, [-9, 0, 0], 1, h=0.9), None, None)
    assert [e["row_id"] for e in pol.last_events if e["event"] == "evict"] == [101]


def test_eviction_targets_most_represented_class_and_tiebreak():
    # L after admission: class 0 x2, class 5 x2 (tie) + class 1 x1 -> evict from class 5 (largest label)
    rows = [
        (1, [0.0, 0.0, 0.0], 0, "L", 0.9, 0),
        (2, [0.01, 0.0, 0.0], 0, "L", 0.9, 1),  # class-0 pair is the globally nearest pair
        (3, [4.0, 0.0, 0.0], 5, "L", 0.9, 2),
        (4, [1.0, 9.0, 0.0], 1, "L", 0.9, 3),
        (5, [6.0, 0.0, 0.0], 5, "S", 0.9, 4),  # admitted -> class 5 count 2
        (6, [7.0, 0.0, 0.0], 5, "S", 0.9, 5),
        (7, [7.0, 0.0, 0.0], 5, "S", 0.9, 6),
        (8, [7.0, 0.0, 0.0], 5, "S", 0.9, 7),
    ]
    pol = CUREPolicy(k=8, short_ratio=0.5, tau=0.5, warmup_steps=0)
    pol.update(ctx_frame(rows), row(9, [7, 0, 0], 5, h=0.9), None, None)
    ev = [e["row_id"] for e in pol.last_events if e["event"] == "evict"]
    assert ev == [3]  # class 5 pair (3,5); centroid of recent class 5 at x=7 -> row 3 farther


def test_eviction_centroid_fallback_when_no_recent_same_class():
    rows = [
        (1, [0.0, 0.0, 0.0], 1, "L", 0.9, 0),
        (2, [0.1, 0.0, 0.0], 1, "L", 0.9, 1),
        (3, [9.0, 9.0, 9.0], 1, "L", 0.9, 2),
        (4, [5.0, 5.0, 5.0], 0, "L", 0.9, 3),
        (5, [3.0, 3.0, 3.0], 1, "S", 0.9, 4),  # admitted -> class 1 has 4 in L
        (6, [-10.0, 0.0, 0.0], 0, "S", 0.9, 5),
        (7, [-10.0, 0.0, 0.0], 0, "S", 0.9, 6),
        (8, [-10.0, 0.0, 0.0], 0, "S", 0.9, 7),
    ]
    pol = CUREPolicy(k=8, short_ratio=0.5, tau=0.5, warmup_steps=0)
    pol.update(ctx_frame(rows), row(9, [-10, 0, 0], 0, h=0.9), None, None)
    # no class-1 rows in S -> centroid of all S (x=-10) -> B (x=0.1) is farther
    assert [e["row_id"] for e in pol.last_events if e["event"] == "evict"] == [2]


# --------------------------------------------------------------- DualFIFO
def _dualfifo_oracle(stream_labels, b_s, b_l):
    S, L = deque(), []  # items: (arrival, label)
    for t, y in enumerate(stream_labels):
        S.append((t, y))
        while len(S) > b_s:
            L.append(S.popleft())
        while len(L) > b_l:
            labs = [lab for _, lab in L]
            counts = {c: labs.count(c) for c in set(labs)}
            c_max = max(counts.items(), key=lambda kv: (kv[1], kv[0]))[0]
            victim = min((it for it in L if it[1] == c_max), key=lambda it: it[0])
            L.remove(victim)
    return sorted(t for t, _ in S), sorted(t for t, _ in L)


def test_dualfifo_matches_definition():
    rng = np.random.default_rng(7)
    pol = DualFIFOPolicy(k=12, short_ratio=0.5)
    ctx = None
    labels = []
    for i in range(150):
        new = make_rows(i, 1, rng, n_classes=3)
        labels.append(int(new["y"].iloc[0]))
        ctx = pol.update(ctx, new, None, None)
    s_exp, l_exp = _dualfifo_oracle(labels, 6, 6)
    assert sorted(ctx.loc[ctx[BANK_COL] == "S", "row_id"]) == s_exp
    assert sorted(ctx.loc[ctx[BANK_COL] == "L", "row_id"]) == l_exp


def test_dualfifo_handcrafted():
    pol = DualFIFOPolicy(k=4, short_ratio=0.5)  # B_S=2, B_L=2
    ctx = None
    for i, y in enumerate([0, 0, 1, 1, 1]):
        ctx = pol.update(ctx, row(i, [i, 0, 0], y), None, None)
    # t=3: row1 -> L, L={0,1}; t=4: row2 -> L={0,1,2} -> class 0 majority -> evict oldest (row 0)
    assert pol.last_events == [{"event": "promote", "row_id": 2}, {"event": "evict", "row_id": 0}]
    assert sorted(ctx.loc[ctx[BANK_COL] == "L", "row_id"]) == [1, 2]
    assert sorted(ctx.loc[ctx[BANK_COL] == "S", "row_id"]) == [3, 4]


def test_dualfifo_never_calls_scorer():
    def boom(X):
        raise AssertionError("scorer must not be called")

    pol = DualFIFOPolicy(k=6, short_ratio=0.5)
    rng = np.random.default_rng(0)
    ctx = None
    for i in range(20):
        ctx = pol.update(ctx, make_rows(i, 1, rng), None, boom)


# ------------------------------------------------------------ determinism
@pytest.mark.parametrize("Policy", [CUREPolicy, DualFIFOPolicy])
def test_determinism(Policy):
    def run():
        rng = np.random.default_rng(11)
        kw = dict(k=30, short_ratio=0.75, seed=123)
        if Policy is CUREPolicy:
            kw.update(tau=0.4, warmup_steps=5)
        pol = Policy(**kw)
        scorer = random_scorer(5)
        ctx = None
        for i in range(0, 400, 4):
            ctx = pol.update(ctx, make_rows(i, 4, rng), None, scorer)
        return ctx

    a, b = run(), run()
    pd.testing.assert_frame_equal(a, b)


def test_batch_equals_sequential_with_precomputed_entropy():
    rng = np.random.default_rng(2)
    data = make_rows(0, 200, rng)
    data[ENTROPY_COL] = rng.uniform(size=200)
    p1 = CUREPolicy(k=25, short_ratio=0.6, tau=0.5, warmup_steps=0)
    p2 = CUREPolicy(k=25, short_ratio=0.6, tau=0.5, warmup_steps=0)
    c1 = c2 = None
    for i in range(200):
        c1 = p1.update(c1, data.iloc[[i]].reset_index(drop=True), None, None)
    for i in range(0, 200, 10):
        c2 = p2.update(c2, data.iloc[i : i + 10].reset_index(drop=True), None, None)
    pd.testing.assert_frame_equal(c1, c2)
