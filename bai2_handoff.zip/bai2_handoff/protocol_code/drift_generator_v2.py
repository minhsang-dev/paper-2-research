"""Controlled drift generator v2 (Step B). Development data only (NF-ToN-IoT-v3, NF-CICIDS2018-v3).

v2 replaces v1 (superseded_gen_v1/, see DEVIATIONS.md DEV-001). Drift kinds, parameters, grids, the maximum of
MAX_PER_KIND scenarios per kind per root day, and the scenario ids/seeds are exactly those of v1.

What is new: every root day is split ONCE (seed fixed by dataset + day, stratified by attack family) into
  EVAL_POOL    rows the evaluation sample of a scenario day is drawn from (only these);
  STREAM_POOL  rows that may be queried, enter a context or enter D_cal (only these), itself split into
    POLICY_POOL  rows labelled for the policy,
    CAL_POOL     rows labelled for D_cal (share ETA of STREAM_POOL, ETA = the replay's eta).
The three pools are disjoint, so a row can never be an evaluation row and a labelled row (I1), nor reserved for D_cal
and given to the policy (I3), whatever the resampling does. Rare families (< 1% of the day's attack flows) are split
50/50 between EVAL_POOL and STREAM_POOL; every other family goes EVAL_FRACTION to EVAL_POOL. EVAL_FRACTION is the
smallest multiple of 0.05 that gives the smallest root day an EVAL_POOL of at least EVAL_TARGET rows (the largest
evaluation sample of Step D); the manifest reports the pool sizes and flags any root day where EVAL_TARGET is not met.

A scenario is a short synthetic day sequence built from ONE root day. A synthetic day has three parts: `eval`
(EVAL_DAY_SIZE rows from EVAL_POOL), `policy` and `cal` (day_size rows in total, ETA of them from CAL_POOL), each a
seeded weighted resample (with replacement) from its own pool with the day's drift weights. The manifest stores
parameters and seeds only; `materialize` rebuilds the positions. Nothing here looks at model output.

Kinds: feature / prior / recurring, as in v1 (see the constants). Root days = days with at least one attack flow.
"""
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "replay"))

from data import CACHE_DIR, DEV_DATASETS, rare_families, seed_of  # noqa: E402

# --- unchanged from v1
N_PRE, N_POST, N_REINTRO = 2, 3, 2
DAY_SIZE = 200_000
MAX_PER_KIND = 10
FEATURE_SET_SIZES = (1, 2, 3)
FEATURE_BETAS = (0.5, 1.0, 2.0, 3.0)
PRIOR_ODDS = (0.125, 0.25, 0.5, 2.0, 4.0, 8.0)
PRIOR_TEMPER = (0.0, 0.5)
RECUR_DAYS = (3, 4, 5)
MIN_FAMILY_FLOWS = 1000
ELIG_SAMPLE, ELIG_MIN_DISTINCT = 100_000, 20
KINDS = ("feature", "prior", "recurring")
# --- new in v2
EVAL_TARGET = 100_000        # largest evaluation sample of Step D
EVAL_FRACTION = 0.35         # smallest multiple of 0.05 with 0.35 * 329,487 (smallest root day) >= EVAL_TARGET
RARE_EVAL_FRACTION = 0.5     # rare families: 50/50 between EVAL_POOL and STREAM_POOL
ETA = 0.2                    # share of STREAM_POOL that is CAL_POOL; must equal the replay's eta
EVAL_DAY_SIZE = 200_000
DESIGN_KEYS = ("N_PRE", "N_POST", "N_REINTRO", "DAY_SIZE", "MAX_PER_KIND", "FEATURE_SET_SIZES", "FEATURE_BETAS",
               "PRIOR_ODDS", "PRIOR_TEMPER", "RECUR_DAYS", "MIN_FAMILY_FLOWS", "ELIG_SAMPLE", "ELIG_MIN_DISTINCT",
               "EVAL_TARGET", "EVAL_FRACTION", "RARE_EVAL_FRACTION", "ETA", "EVAL_DAY_SIZE")
V1_GENERATOR_SHA256 = "acfa0fd106cd489f30ec20a2f464211e57671e2f7a72beb065db37f8fc7a4812"
V1_MANIFEST_SHA256 = "9aa6c05a99ad4aa9ca477ebe3e4ff99b7226b971fdaa339acfb372ed66c750a4"


def design():
    return {k: globals()[k] for k in DESIGN_KEYS} | {"KINDS": list(KINDS)}


# ---------------------------------------------------------------- pools

def split_root_day(dataset, day_name, y, fam):
    """Disjoint sorted position arrays {'eval','policy','cal'} covering the whole root day. Stratified by
    (label, family); the shuffle seed depends on dataset + day + stratum only."""
    rare = set(rare_families(fam, y).tolist())
    base = seed_of(dataset, day_name, "pools")
    parts = {"eval": [], "policy": [], "cal": []}
    key = y.astype(np.int64) * 100_000 + fam.astype(np.int64)
    for s in np.unique(key):
        idx = np.flatnonzero(key == s)
        perm = np.random.default_rng(seed_of(base, "stratum", int(s))).permutation(idx)
        is_rare = bool(y[idx[0]] == 1 and int(fam[idx[0]]) in rare)
        n_e = int(round((RARE_EVAL_FRACTION if is_rare else EVAL_FRACTION) * len(idx)))
        if len(idx) >= 2:
            n_e = min(max(n_e, 1), len(idx) - 1)
        ev, st = perm[:n_e], perm[n_e:]
        n_c = int(round(ETA * len(st)))
        parts["eval"].append(ev)
        parts["cal"].append(st[:n_c])
        parts["policy"].append(st[n_c:])
    return {k: np.sort(np.concatenate(v)).astype(np.int64) for k, v in parts.items()}


def _sha(a):
    return hashlib.sha256(np.ascontiguousarray(a, dtype=np.int64).tobytes()).hexdigest()


def pool_report(day_name, y, fam, pools):
    n = len(y)
    rare = rare_families(fam, y)
    rare_split = {}
    for f in rare.tolist():
        m = (y == 1) & (fam == f)
        rare_split[int(f)] = {k: int(m[pools[k]].sum()) for k in ("eval", "policy", "cal")}
    issues = [f"{k}: no {lab} rows" for k in pools for lab, v in (("attack", 1), ("benign", 0))
              if not (y[pools[k]] == v).any()]
    n_stream = len(pools["policy"]) + len(pools["cal"])
    return {"day": day_name, "n_root": int(n), "n_eval_pool": int(len(pools["eval"])), "n_stream_pool": int(n_stream),
            "n_policy_pool": int(len(pools["policy"])), "n_cal_pool": int(len(pools["cal"])),
            "eval_pool_meets_target": bool(len(pools["eval"]) >= EVAL_TARGET),
            "attack_flows": {k: int(y[pools[k]].sum()) for k in pools}, "rare_family_split": rare_split,
            "pool_issues": issues, "sha256": {k: _sha(pools[k]) for k in pools}}


# ---------------------------------------------------------------- manifest (scenarios identical to v1)

def _select(cells, rng):
    if len(cells) <= MAX_PER_KIND:
        return list(cells)
    return [cells[i] for i in sorted(rng.choice(len(cells), MAX_PER_KIND, replace=False))]


def _days(roles, seed):
    return [{"role": r, "seed": seed_of(seed, "day", j)} for j, r in enumerate(roles)]


def eligible_feature_idx(X):
    return [j for j in range(X.shape[1]) if len(np.unique(X[:, j])) >= ELIG_MIN_DISTINCT]


def scenarios_for_root(ds, root_name, root_idx, y, fam, X_sample, feature_names, attack_names):
    out = []
    n_att = int((y == 1).sum())
    fams, counts = np.unique(fam[y == 1], return_counts=True)
    p0 = n_att / len(y)
    m = min(DAY_SIZE, len(y))
    n_cal = int(round(ETA * m))

    def mk(kind, idx, params, roles):
        seed = seed_of(ds, root_name, kind, idx)
        return {"id": f"{ds}|{root_name}|{kind}|{idx}", "dataset": ds, "root_day": root_name, "root_index": root_idx,
                "kind": kind, "params": params, "seed": seed, "day_size": m, "eval_day_size": EVAL_DAY_SIZE,
                "policy_size": m - n_cal, "cal_size": n_cal, "days": _days(roles, seed)}

    elig = eligible_feature_idx(X_sample)
    cells = [(s, b) for s in FEATURE_SET_SIZES if s <= len(elig) for b in FEATURE_BETAS]
    rng = np.random.default_rng(seed_of(ds, root_name, "feature", "select"))
    for idx, (s, b) in enumerate(_select(cells, rng)):
        r = np.random.default_rng(seed_of(ds, root_name, "feature", idx, "features"))
        J = sorted(int(j) for j in r.choice(elig, s, replace=False))
        signs = [int(v) for v in r.choice([-1, 1], s)]
        out.append(mk("feature", idx, {"feature_index": J, "features": [feature_names[j] for j in J],
                                       "signs": signs, "beta": b, "n_eligible_features": len(elig)},
                      ["pre"] * N_PRE + ["drift"] * N_POST))
    cells = [(lam, t) for lam in PRIOR_ODDS for t in PRIOR_TEMPER if t == 0.0 or len(fams) >= 2]
    rng = np.random.default_rng(seed_of(ds, root_name, "prior", "select"))
    for idx, (lam, t) in enumerate(_select(cells, rng)):
        target = lam * p0 / (1 - p0 + lam * p0)
        out.append(mk("prior", idx, {"odds_factor": lam, "family_temper": t, "root_attack_share": p0,
                                     "target_attack_share": target}, ["pre"] * N_PRE + ["drift"] * N_POST))
    big = [(int(f), int(c)) for f, c in zip(fams, counts) if c >= MIN_FAMILY_FLOWS]
    eligible = [(f, c) for f, c in big if len(big) >= 2]
    cells = [(f, c, d) for f, c in eligible for d in RECUR_DAYS]
    rng = np.random.default_rng(seed_of(ds, root_name, "recurring", "select"))
    for idx, (f, c, d) in enumerate(_select(cells, rng)):
        total = int(counts.sum())
        out.append(mk("recurring", idx, {"family_id": f, "family": attack_names[f], "absent_days": d,
                                         "family_flows": c, "family_share_of_attack_flows": c / total,
                                         "rare": bool(c / total < 0.01)},
                      ["pre"] * N_PRE + ["absent"] * d + ["reintro"] * N_REINTRO))
    return out


def build_manifest(streams, feature_names, generator_sha256=None):
    scenarios, roots = [], {}
    for ds, s in streams.items():
        all_days, root_list, pools_rep = [], [], []
        for i, name in enumerate(s.names):
            y, fam = s.labels(i), s.families(i)
            n_att = int((y == 1).sum())
            all_days.append({"day": name, "flows": int(len(y)), "attack_flows": n_att})
            if n_att == 0:
                continue
            pools_rep.append(pool_report(name, y, fam, split_root_day(ds, name, y, fam)))
            pos = np.sort(np.random.default_rng(seed_of(ds, name, "elig")).choice(
                len(y), min(ELIG_SAMPLE, len(y)), replace=False))
            scenarios += scenarios_for_root(ds, name, i, y, fam, s.get(i, pos).X, feature_names[ds], s.attack_names)
            root_list.append(name)
        roots[ds] = {"valid_days": all_days, "root_days": root_list, "pools": pools_rep,
                     "excluded_as_root": [d["day"] for d in all_days if d["attack_flows"] == 0]}
    counts = {ds: {k: sum(1 for x in scenarios if x["dataset"] == ds and x["kind"] == k) for k in KINDS}
              for ds in streams}
    root_counts = {ds: {k: len({x["root_day"] for x in scenarios if x["dataset"] == ds and x["kind"] == k})
                        for k in KINDS} for ds in streams}
    return {"version": 2, "supersedes": {"generator_sha256": V1_GENERATOR_SHA256,
                                         "manifest_sha256": V1_MANIFEST_SHA256, "deviation": "DEV-001"},
            "design": design(), "generator_sha256": generator_sha256, "datasets": roots,
            "n_scenarios": counts, "n_root_days_with_scenarios": root_counts,
            "n_root_days": {ds: len(r["root_days"]) for ds, r in roots.items()}, "scenarios": scenarios}


# ---------------------------------------------------------------- materialization (used at run time)

def _z(col):
    s = np.sort(col)
    r = (np.searchsorted(s, col, "left") + np.searchsorted(s, col, "right")) / 2.0 / len(col)
    return 2.0 * r - 1.0


def _weights(scn, role, y, fam, col):
    n = len(y)
    p = scn["params"]
    if role in ("pre", "reintro"):
        return np.ones(n)
    if role == "absent":
        return (fam != p["family_id"]).astype(float)
    if scn["kind"] == "feature":
        s = np.mean([sg * _z(np.asarray(col(j), dtype=np.float64)) for j, sg in zip(p["feature_index"], p["signs"])],
                    axis=0)
        return np.exp(p["beta"] * s)
    att = y == 1                                   # prior shift
    f, c = np.unique(fam[att], return_counts=True)
    cnt = dict(zip(f.tolist(), c.tolist()))
    u = np.zeros(n)
    u[att] = np.array([cnt[v] for v in fam[att].tolist()], dtype=float) ** (-p["family_temper"])
    w = np.zeros(n)
    w[att] = p["target_attack_share"] * u[att] / u[att].sum()
    w[~att] = (1 - p["target_attack_share"]) / (~att).sum()
    return w


def materialize(scn, y, fam, col, pools):
    """One dict {'eval','policy','cal'} per synthetic day: sorted ROOT-day positions drawn with replacement, each
    part only from its own pool and with the day's drift weights computed inside that pool.
    col(j) returns the root day's column j (only called for feature scenarios)."""
    sizes = {"eval": scn["eval_day_size"], "policy": scn["policy_size"], "cal": scn["cal_size"]}
    out = []
    for d in scn["days"]:
        day = {}
        for part in ("eval", "policy", "cal"):
            pool = pools[part]
            w = _weights(scn, d["role"], y[pool], fam[pool], lambda j, pool=pool: np.asarray(col(j))[pool])
            c = np.cumsum(w)
            u = np.random.default_rng(seed_of(d["seed"], part)).random(sizes[part]) * c[-1]
            day[part] = np.sort(pool[np.minimum(np.searchsorted(c, u, side="right"), len(pool) - 1)])
        out.append(day)
    return out


# ---------------------------------------------------------------- main

def main():
    from data import DayStream
    streams, names = {}, {}
    for ds in DEV_DATASETS:
        streams[ds] = DayStream(ds)
        names[ds] = json.loads((CACHE_DIR / ds / "meta.json").read_text(encoding="utf-8"))["feature_columns"]
    sha = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    man = build_manifest(streams, names, sha)
    (HERE / "scenario_manifest.json").write_text(json.dumps(man, indent=1, sort_keys=True), encoding="utf-8")
    print(json.dumps({k: man[k] for k in ("n_scenarios", "n_root_days_with_scenarios", "n_root_days")}, indent=1))
    for ds, r in man["datasets"].items():
        for p in r["pools"]:
            print(ds, p["day"], p["n_root"], p["n_eval_pool"], p["n_stream_pool"], p["n_policy_pool"], p["n_cal_pool"],
                  p["eval_pool_meets_target"], p["pool_issues"])


if __name__ == "__main__":
    main()
