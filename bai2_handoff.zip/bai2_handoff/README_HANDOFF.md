# Bài 2 handoff bundle (code and context only; no data)

The thesis plan (outline v14.3, submitted; it cannot be changed for 6 months) puts RQ2 and RQ3 in Bài 2:
- RQ2: a three-compartment context policy by attack family, with Proposition 1 (Mệnh đề 1);
- RQ3: label selection by expected error reduction.

This bundle supports the **RQ2 phase**. Read `context/outline_v14_3_RQ_excerpt.txt` (Vietnamese) for the exact plan.

## Contents
| Path | What |
|---|---|
| protocol_code/replay/ | Bài 1 replay harness, locked as L5. Policy interface: `update(context, new_labelled_rows, unlabelled_stream) -> context`, with \|context\| ≤ k. Policies FIFO, DualFIFO, CBRS, CBRS-family, CURE, plus Rows, models and data. Tests are in replay/tests. |
| protocol_code/cure_ref, cbrs_ref | Reference implementations and reproduction reports used in Bài 1 |
| protocol_code/drift_generator_v2.py, scenario_manifest.json | Controlled-drift generator (feature, prior and recurring-family scenarios) and its hashed manifest |
| protocol_code/main_h1/analysis_h1.py | Locked statistics: exact HL / Wilcoxon inversion, moving-block bootstrap |
| cache_meta/*/meta.json | Structure of the two development caches (rows, features, attack names). **No data rows.** |
| context/bai1_manuscript_v3.md | Bài 1 manuscript: protocol, results and limitations |
| context/numbers*.json, table*.md | Bài 1 result tables: root-day outcomes, per-family AUPRC_w, random split vs chronological |
| context/cidds_untrainable_table.md | Bài 1 finding: the FIFO context became one-class after attack-free days on CIDDS-001 |

## Binding rules for every task
1. **No data.** No dataset is in this bundle. Do not download NetFlow, UGR'16, CIDDS-001 or any other dataset, and do
   not ask for one. Test with synthetic streams only. DS1 (campus log) must never be used.
2. **Locked files are read-only.** Do not edit `protocol_code/`. New code goes in your task output folder. To change
   behaviour, subclass or wrap; never patch the harness.
3. **No invented numbers.** Every number in a report comes from a script in your output folder, from a cited source
   (with link), or from this bundle (name the file). Mark anything unverified as `[VERIFY]`.
4. **Hashing.** Hash all delivered files: `SHA256SUMS` in the output folder.
5. **No cloud resources.** Do not create, resize or delete any cloud resource. Do not use GPUs.
6. **Ending.** Finish with `REPORT.md`, under 400 words: what was done, open questions, and decisions needed from the
   NCS. Then stop.
